export const environment = {
  production: true,
  API_URL: 'http://3.85.159.45:8042/',
};
