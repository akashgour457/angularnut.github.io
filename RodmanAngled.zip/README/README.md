# RodmanMedia

Clone the Beanstalk repository:
git clone https://rodpub.git.beanstalkapp.com/rodmanangled.git
Once cloned install node_modules
npm install

You will need to build the Core Library if dist folder is not cloned.
**Run these in the order. You can not build RodmanMedia first, it depends on RodmanORM.**
ng build RodmanORM
ng build RodmanMedia


The Main portion of the project is inside the RodmanCore Library.
`If you make any changes in that library, you need to build it`
ng build RodmanCore
ng build RodmanORM

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.
`ng serve`
You can run individual projects like this:
`ng serve --project=PEN --port=4201` #because 4200 is already in used by default.
`ng serve --project=CW --port=4202`
`ng serve --project=ODT --port=4202`



