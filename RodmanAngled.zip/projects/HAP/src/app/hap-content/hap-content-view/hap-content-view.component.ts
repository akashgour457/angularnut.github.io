import { Component, OnInit } from '@angular/core';
import { Router ,NavigationEnd } from '@angular/router'; 
import { environment } from '../../../environments/environment';
@Component({
  selector: 'hap-hap-content-view',
  templateUrl: './hap-content-view.component.html',
  styleUrls: ['./hap-content-view.component.css']
})
export class HapContentViewComponent implements OnInit {

 
  contentPageUrl : any ;
  public magazineId :any;
  constructor(private router:Router) {
    this.magazineId = environment.magazineId ;
       router.events.subscribe(event => {
        if (event instanceof NavigationEnd ) {
          this.contentPageUrl = event.url;         
        }
      });


   }

  ngOnInit() {
  }

}
