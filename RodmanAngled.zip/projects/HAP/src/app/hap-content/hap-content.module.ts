import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HapContentRoutingModule } from './hap-content-routing.module';
import { HapContentListComponent } from './hap-content-list/hap-content-list.component';
import { ContentsModule ,HomeModule,SitesModule,AdsModule,HeapsModule} from 'rodman-core';
import { DfpModule } from 'ngx-dfp';


@NgModule({
  declarations: [HapContentListComponent],
  imports: [
    CommonModule,
    HapContentRoutingModule, 
    ContentsModule,
    HomeModule,
    SitesModule,
    AdsModule,
    HeapsModule,    
    DfpModule.forRoot({
      idleLoad: true,
      enableVideoAds: true,
      personalizedAds: true, // Request personalized ads by default
      singleRequestMode: true, // Only applies to initial refresh
      onSameNavigation: 'refresh',
      globalTargeting: {
        // food: ['NUT', 'HOME']
      }
    }) 
  ]
})
export class HapContentModule { }
