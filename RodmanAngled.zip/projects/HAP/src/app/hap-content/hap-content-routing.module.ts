import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {HapContentListComponent} from './hap-content-list/hap-content-list.component';


const routes: Routes = [
  { path : "", component: HapContentListComponent  },
  { path : ":any", component: HapContentListComponent  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HapContentRoutingModule { }
