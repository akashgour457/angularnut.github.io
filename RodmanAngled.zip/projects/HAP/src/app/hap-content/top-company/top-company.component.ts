import { Component, OnInit } from '@angular/core';
import { Router ,NavigationEnd } from '@angular/router'; 
import { environment } from '../../../environments/environment';
@Component({
  selector: 'hap-top-company',
  templateUrl: './top-company.component.html',
  styleUrls: ['./top-company.component.css']
})
export class TopCompanyComponent implements OnInit {

  contentPageUrl : any ;
  public magazineId :any;
  constructor(private router:Router) {
    this.magazineId = environment.magazineId ;
       router.events.subscribe(event => {
        if (event instanceof NavigationEnd ) {
          this.contentPageUrl = event.url;         
        }
      });
     
   }

  ngOnInit() {
  }

}
