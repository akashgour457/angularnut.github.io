import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { HttpClientModule } from '@angular/common/http';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';
import {HomeModule,SitesModule,ContentsModule,UsersModule,TaxonomiesModule,AdsModule,DirectorySectionModule,HeapsModule} from 'rodman-core';  // import { BuyerGuideModule } from "rodman-core";
import { ContentSearchComponent } from '../../../rodman-core/src/lib/contents/content-search/content-search.component';
import { NotFoundComponent } from '../../../rodman-core/src/lib/sites/components/not-found/not-found.component';
import { UserProfileComponent } from '../../../rodman-core/src/lib/users/Components/user-profile/user-profile.component';
import { StaticContentComponent } from "../../../rodman-core/src/lib/contents/static-content/static-content.component";
import { ContentGlossaryComponent } from "../../../rodman-core/src/lib/contents/content-glossary/content-glossary.component";
import { ContentIssueComponent } from "../../../rodman-core/src/lib/contents/content-issue/content-issue.component";
import { ContentRssFeedsComponent } from "../../../rodman-core/src/lib/contents/content-rss-feeds/content-rss-feeds.component";
import { DirectoryHomePageComponent } from '../../../rodman-core/src/lib/directory-section/directory-home-page/directory-home-page.component';
import { ContentInfographicsComponent } from "../../../rodman-core/src/lib/contents/content-infographics/content-infographics.component";
import { ContentsWebinarComponent } from '../../../rodman-core/src/lib/contents/contents-webinar/contents-webinar.component';
import {TopCompanyComponent} from './hap-content/top-company/top-company.component';
import {HapContentViewComponent} from './hap-content/hap-content-view/hap-content-view.component';
@NgModule({
  declarations: [
    AppComponent,
    NotFoundComponent,    
    ContentSearchComponent,          
    UserProfileComponent,
    StaticContentComponent,
    ContentGlossaryComponent,
    ContentIssueComponent,
    ContentRssFeedsComponent,
    DirectoryHomePageComponent,
    ContentInfographicsComponent,
    ContentsWebinarComponent,
    TopCompanyComponent,
    HapContentViewComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    Ng4LoadingSpinnerModule.forRoot(),
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    DirectorySectionModule,
    AngularFontAwesomeModule,
    HomeModule,
    SitesModule,
    HeapsModule,
    ContentsModule,    
    UsersModule,
    TaxonomiesModule,
    AdsModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
