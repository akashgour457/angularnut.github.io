import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HapTaxonomyRoutingModule } from './hap-taxonomy-routing.module';
import { HapTaxonomyListComponent } from './hap-taxonomy-list/hap-taxonomy-list.component';
import { ContentsModule ,AdsModule ,TaxonomiesModule } from 'rodman-core';
import { DfpModule } from 'ngx-dfp';

@NgModule({
  declarations: [HapTaxonomyListComponent],
  imports: [
    CommonModule,
    HapTaxonomyRoutingModule,
    TaxonomiesModule,
    ContentsModule,
    AdsModule,
    DfpModule.forRoot({
      idleLoad: true,
      enableVideoAds: true,
      personalizedAds: true, // Request personalized ads by default
      singleRequestMode: true, // Only applies to initial refresh
      onSameNavigation: 'refresh',
      globalTargeting: {
        // food: ['NUT', 'HOME']
      }
    }) 
  ]
})
export class HapTaxonomyModule { }
