import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute ,NavigationEnd } from '@angular/router'; 
import{ environment } from '../../../environments/environment';
import { RodmanCoreService } from '../../../../../rodman-core/src/lib/rodman-core.service';
@Component({
  selector: 'hap-hap-taxonomy-list',
  templateUrl: './hap-taxonomy-list.component.html',
  styleUrls: ['./hap-taxonomy-list.component.css']
})
export class HapTaxonomyListComponent implements OnInit {

 
  public magazineId;
  currentURL : any ;
  getAllAd:any=[];
  TabOne;
  TabTwo;
  viewAdRender:number;
  constructor(private router:Router,public RodmanCoreService:RodmanCoreService) {
       this.magazineId = environment.magazineId;   
       this.TabOne = environment.TabOne;
       this.TabTwo = environment.TabTwo;
       router.events.subscribe(event => {
        if (event instanceof NavigationEnd ) {
          this.currentURL = event.url; 
        }
      });
  
      this.RodmanCoreService.getAllAdst(this.magazineId).subscribe((data =>{
        this.getAllAd = data;
        this.viewAdRender = 1;
     }))
   }

  ngOnInit() {
  }

}
