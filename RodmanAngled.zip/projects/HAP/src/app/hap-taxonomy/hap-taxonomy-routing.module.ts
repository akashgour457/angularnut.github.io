import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {HapTaxonomyListComponent} from './hap-taxonomy-list/hap-taxonomy-list.component';


const routes: Routes = [
  { path : "", component: HapTaxonomyListComponent  },
  { path : ":any", component: HapTaxonomyListComponent  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HapTaxonomyRoutingModule { }
