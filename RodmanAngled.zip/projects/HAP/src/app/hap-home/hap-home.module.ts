import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HapHomeRoutingModule } from './hap-home-routing.module';
import { HapHomeComponent } from './hap-home/hap-home.component';

import { HttpClientModule } from '@angular/common/http';
import {HomeModule,SitesModule,ContentsModule,AdsModule} from 'rodman-core';
import { DfpModule } from 'ngx-dfp';

@NgModule({
  declarations: [HapHomeComponent],
  imports: [
    CommonModule,
    HapHomeRoutingModule,
    HttpClientModule,
    HomeModule,SitesModule,ContentsModule,AdsModule,
    DfpModule.forRoot({
      idleLoad: true,
      enableVideoAds: true,
      personalizedAds: true, // Request personalized ads by default
      singleRequestMode: true, // Only applies to initial refresh
      onSameNavigation: 'refresh',
      globalTargeting: {
      }
    }),
  ]
})
export class HapHomeModule { }
