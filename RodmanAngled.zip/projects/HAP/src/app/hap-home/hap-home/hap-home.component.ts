import { Component, OnInit } from '@angular/core';
import { environment} from '../../../environments/environment';
import { RodmanCoreService } from '../../../../../rodman-core/src/lib/rodman-core.service';
@Component({
  selector: 'hap-hap-home',
  templateUrl: './hap-home.component.html',
  styleUrls: ['./hap-home.component.css']
})
export class HapHomeComponent implements OnInit {

  magazineId;
  homeBoxId;
  viewAdRender:number;
  getAllAd:any=[];
  tabOne;
  tabTwo;
  
  constructor(public RodmanCoreService:RodmanCoreService) { 
    this.magazineId = environment.magazineId;
    this.homeBoxId = environment.homeBoxId;
    this.tabOne = environment.TabOne;
    this.tabTwo = environment.TabTwo;
    this.RodmanCoreService.getAllAdst(this.magazineId).subscribe((data =>{
      this.getAllAd = data;
      this.viewAdRender = 1;
   }))

  }
  ngOnInit() {
  }

}
