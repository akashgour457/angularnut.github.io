import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { environment } from '../environments/environment';

// Rodman Core Import
import { ContentSearchComponent } from '../../../rodman-core/src/lib/contents/content-search/content-search.component';
import { NotFoundComponent } from '../../../rodman-core/src/lib/sites/components/not-found/not-found.component';
import { UserProfileComponent } from '../../../rodman-core/src/lib/users/Components/user-profile/user-profile.component';
import { StaticContentComponent } from "../../../rodman-core/src/lib/contents/static-content/static-content.component";
import { ContentGlossaryComponent } from "../../../rodman-core/src/lib/contents/content-glossary/content-glossary.component";
import { ContentIssueComponent } from "../../../rodman-core/src/lib/contents/content-issue/content-issue.component";
import { ContentRssFeedsComponent } from "../../../rodman-core/src/lib/contents/content-rss-feeds/content-rss-feeds.component";
import { DirectoryHomePageComponent } from '../../../rodman-core/src/lib/directory-section/directory-home-page/directory-home-page.component';
import { ContentInfographicsComponent } from "../../../rodman-core/src/lib/contents/content-infographics/content-infographics.component";
import { ContentsWebinarComponent } from '../../../rodman-core/src/lib/contents/contents-webinar/contents-webinar.component';

import { TopCompanyComponent } from './hap-content/top-company/top-company.component';

import {HapContentViewComponent} from './hap-content/hap-content-view/hap-content-view.component';

const routes: Routes = [
  {path: "", pathMatch: 'full' , loadChildren: () =>import('./hap-home/hap-home.module').then (m=>m.HapHomeModule)},
  // Search Content   
    {path:  'contents/list_webinars', component:ContentsWebinarComponent,data: {magazineId: environment.magazineId }},
    {path:  'contents/list_infographics',component:ContentInfographicsComponent,data: {magazineId: environment.magazineId }},  
    {path:  'contents/list_industry-events', component:ContentInfographicsComponent,data: {magazineId: environment.magazineId }},
    {path:  'contents/searchcontent/:any/:slug', component:ContentSearchComponent,data: {magazineId: environment.magazineId }},
    {path:  'contents/searchcontent/:any', component:ContentSearchComponent,data: {magazineId: environment.magazineId }},
    {path:  'contents/searchcontent', component:ContentSearchComponent,data: {magazineId: environment.magazineId }},
  
  //View Page Content    
    {path:  'contents/:any/:any/:any', component:HapContentViewComponent,data: {magazineId: environment.magazineId }},
    {path:  'issues/:any/:any/:any', component:HapContentViewComponent,data: {magazineId: environment.magazineId }},   
  //Taxonomy
    {path:  'formulary', loadChildren: () =>import('./hap-taxonomy/hap-taxonomy.module').then (m=>m.HapTaxonomyModule)},
    {path:  'formulary/:any', loadChildren: () =>import('./hap-taxonomy/hap-taxonomy.module').then (m=>m.HapTaxonomyModule)},
    // {path:  'knowledge-base', loadChildren: () =>import('./hap-taxonomy/hap-taxonomy.module').then (m=>m.HapTaxonomyModule)},
    {path:  'knowledge-base/:any', loadChildren: () =>import('./hap-taxonomy/hap-taxonomy.module').then (m=>m.HapTaxonomyModule)},
    {path:  'knowledge-base/:any/:any', loadChildren: () =>import('./hap-taxonomy/hap-taxonomy.module').then (m=>m.HapTaxonomyModule)},
    {path:  'contract-manufacturing-private-label-directory', loadChildren: () =>import('./hap-taxonomy/hap-taxonomy.module').then (m=>m.HapTaxonomyModule)},
    {path:  'contract-manufacturing-private-label-directory/:any', loadChildren: () =>import('./hap-taxonomy/hap-taxonomy.module').then (m=>m.HapTaxonomyModule)},
    {path:  'salary-survey', loadChildren: () =>import('./hap-taxonomy/hap-taxonomy.module').then (m=>m.HapTaxonomyModule)},
    {path:  'salary-survey/:any', loadChildren: () =>import('./hap-taxonomy/hap-taxonomy.module').then (m=>m.HapTaxonomyModule)},
    {path:  'columns', loadChildren: () =>import('./hap-taxonomy/hap-taxonomy.module').then (m=>m.HapTaxonomyModule)},
    {path:  'columns/:any', loadChildren: () =>import('./hap-taxonomy/hap-taxonomy.module').then (m=>m.HapTaxonomyModule)},
    {path:  'podcast-series', loadChildren: () =>import('./hap-taxonomy/hap-taxonomy.module').then (m=>m.HapTaxonomyModule)},
    {path:  'podcast-series/:any', loadChildren: () =>import('./hap-taxonomy/hap-taxonomy.module').then (m=>m.HapTaxonomyModule)},
    {path:  'breaking-news', loadChildren: () =>import('./hap-taxonomy/hap-taxonomy.module').then (m=>m.HapTaxonomyModule)},
    {path:  'breaking-news/:any', loadChildren: () =>import('./hap-taxonomy/hap-taxonomy.module').then (m=>m.HapTaxonomyModule)},
    {path:  'live-from-shows', loadChildren: () =>import('./hap-taxonomy/hap-taxonomy.module').then (m=>m.HapTaxonomyModule)},
  
  //Contents
  
    // {path:  'glossary', component:ContentGlossaryComponent,data: {magazineId: environment.magazineId }},
    {path:  'contents/viewwebsite/:any', component : NotFoundComponent},
    {path:  'contents/2487', component : NotFoundComponent},
    {path:  'contents/2543', component : NotFoundComponent},
    {path:  'contents/:any',loadChildren: () =>import('./hap-content/hap-content.module').then (m=>m.HapContentModule)},
    
    // {path: 'profile',component : UserProfileComponent,data: {magazineId: environment.magazineId }},
    // {path: 'user/verifyUser/:token/:email',component:UserMailVerifyComponent},
  
   
  // BuyerGuide Case 
    // {path:  'csd',component : DirectoryHomePageComponent,data: {magazineId: environment.magazineId }},
    // {path:  'csd/contract-services-directory',component : DirectoryHomePageComponent,data: {magazineId: environment.magazineId }},
  
  
  // OtherCase Static Content
    {path: 'subscribe-now', component : StaticContentComponent,data: {magazineId: environment.magazineId }},
    {path: 'advertise-with-us',component : StaticContentComponent,data: {magazineId: environment.magazineId }},
    {path: 'enewsletter-archive',component : StaticContentComponent,data: {magazineId: environment.magazineId }},
    {path: 'staff',component : StaticContentComponent,data: {magazineId: environment.magazineId }},
    {path: 'editorial-guidelines',component : StaticContentComponent,data: {magazineId: environment.magazineId }},
    {path: 'terms-and-conditions',component : StaticContentComponent,data: {magazineId: environment.magazineId }},
    {path: 'privacy-policy',component : StaticContentComponent,data: {magazineId: environment.magazineId }},
    {path: 'about-us', component : StaticContentComponent,data: {magazineId: environment.magazineId }},
    {path: 'contact-us', component : StaticContentComponent,data: {magazineId: environment.magazineId }},
  
  //Rss
    {path: 'rssfeeds', component : ContentRssFeedsComponent,data: {magazineId: environment.magazineId }},
    {path:  'issues/:slug',component : ContentIssueComponent,data: {magazineId: environment.magazineId }},
    {path:  'heaps/view/:any',component : TopCompanyComponent,data: {magazineId: environment.magazineId }},
    {path:  'heaps/view/:any/:any',component : TopCompanyComponent,data: {magazineId: environment.magazineId }},
    {path:  'heaps/view/:any/:any/:any',component : TopCompanyComponent,data: {magazineId: environment.magazineId }},
    {path:  "**", component : NotFoundComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
