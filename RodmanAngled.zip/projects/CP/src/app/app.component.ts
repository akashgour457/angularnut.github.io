import { Component ,OnInit} from '@angular/core';
import { Router, NavigationEnd,ActivatedRoute } from '@angular/router';
import { environment } from '../environments/environment';
import { RodmanCoreService } from '../../../rodman-core/src/lib/rodman-core.service';

@Component({
  selector: 'CP-root',
  templateUrl: './app.component.html',
  styles: []
})
export class AppComponent implements OnInit {
  title = 'CP';
  magazineId ;
  magazineName;
  currentURL;
  getAllAd = [];
  viewAdRender : number;
  
  constructor (public Router : Router ,public ActivatedRoute:ActivatedRoute,public RodmanCoreService : RodmanCoreService){
    Router.events.subscribe(event => {
      if (event instanceof NavigationEnd ) {
        this.currentURL = event.url; 
      }
    });

    Router.events.subscribe((ev) => {
        // this.spinner();
    });
    this.magazineId= environment.magazineId;
    this.magazineName = environment.magazineName;
    // this.RodmanCoreService.getAllAdst(this.magazineId).subscribe((data =>{
    //   this.getAllAd = data;
    //   this.viewAdRender = 1;
    // }))
  }

  ngOnInit() {
    this.ActivatedRoute.url.subscribe(url =>{ 
      this.currentURL = url[0].path;

    });
  }

  
  ngOnChanges (){
    
  }



}