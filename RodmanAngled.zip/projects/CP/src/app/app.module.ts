import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';



// Rodman Core Import
import {HomeModule,SitesModule,ContentsModule,UsersModule,TaxonomiesModule,AdsModule,DirectorySectionModule,HeapsModule} from 'rodman-core';  // import { BuyerGuideModule } from "rodman-core";

  import { ContentSearchComponent } from '../../../rodman-core/src/lib/contents/content-search/content-search.component';
  import { NotFoundComponent } from '../../../rodman-core/src/lib/sites/components/not-found/not-found.component';
  import { UserProfileComponent } from '../../../rodman-core/src/lib/users/Components/user-profile/user-profile.component';
  import { StaticContentComponent } from "../../../rodman-core/src/lib/contents/static-content/static-content.component";
  import { ContentGlossaryComponent } from "../../../rodman-core/src/lib/contents/content-glossary/content-glossary.component";
  import { ContentIssueComponent } from "../../../rodman-core/src/lib/contents/content-issue/content-issue.component";
  import { ContentRssFeedsComponent } from "../../../rodman-core/src/lib/contents/content-rss-feeds/content-rss-feeds.component";
  import { UserMailVerifyComponent } from './cp-user/components/user-mail-verify/user-mail-verify.component';
  import { ContentViewComponent } from './cp-content/content-view/content-view.component';
  import { DirectoryHomePageComponent } from '../../../rodman-core/src/lib/directory-section/directory-home-page/directory-home-page.component';
  import { ContentInfographicsComponent } from "../../../rodman-core/src/lib/contents/content-infographics/content-infographics.component";
  import { ContentsWebinarComponent } from '../../../rodman-core/src/lib/contents/contents-webinar/contents-webinar.component';
  import { ContentTopCompanyComponent } from '../app/cp-content/content-top-company/content-top-company.component';



@NgModule({
  declarations: [
    AppComponent,
    NotFoundComponent,    
    ContentSearchComponent,          
    UserProfileComponent,
    StaticContentComponent,
    UserMailVerifyComponent,
    ContentViewComponent,
    ContentGlossaryComponent,
    ContentIssueComponent,
    ContentRssFeedsComponent,
    UserMailVerifyComponent,
    DirectoryHomePageComponent,
    ContentInfographicsComponent,
    ContentsWebinarComponent,
    ContentTopCompanyComponent
  ],
  imports: [
    Ng4LoadingSpinnerModule.forRoot(),
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    DirectorySectionModule,
    AngularFontAwesomeModule,
    HomeModule,
    SitesModule,
    HeapsModule,
    ContentsModule,    
    UsersModule,
    TaxonomiesModule,
    AdsModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
