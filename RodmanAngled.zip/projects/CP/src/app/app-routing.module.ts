import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
// import { ViewContentComponent } from './view-content/view-content.component';
import { environment } from '../environments/environment';
import { UserMailVerifyComponent } from './cp-user/components/user-mail-verify/user-mail-verify.component';
import { ContentViewComponent } from './cp-content/content-view/content-view.component';
import { ContentTopCompanyComponent } from '../app/cp-content/content-top-company/content-top-company.component';





// Rodman Core Import
import { ContentSearchComponent } from '../../../rodman-core/src/lib/contents/content-search/content-search.component';
import { NotFoundComponent } from '../../../rodman-core/src/lib/sites/components/not-found/not-found.component';
import { UserProfileComponent } from '../../../rodman-core/src/lib/users/Components/user-profile/user-profile.component';
import { StaticContentComponent } from "../../../rodman-core/src/lib/contents/static-content/static-content.component";
import { ContentGlossaryComponent } from "../../../rodman-core/src/lib/contents/content-glossary/content-glossary.component";
import { ContentIssueComponent } from "../../../rodman-core/src/lib/contents/content-issue/content-issue.component";
import { ContentRssFeedsComponent } from "../../../rodman-core/src/lib/contents/content-rss-feeds/content-rss-feeds.component";
import { DirectoryHomePageComponent } from '../../../rodman-core/src/lib/directory-section/directory-home-page/directory-home-page.component';
import { ContentInfographicsComponent } from "../../../rodman-core/src/lib/contents/content-infographics/content-infographics.component";
import { ContentsWebinarComponent } from '../../../rodman-core/src/lib/contents/contents-webinar/contents-webinar.component';


const routes: Routes = [
  {path: "", pathMatch: 'full' , loadChildren: () =>import('./cp-home/cp-home.module').then (m=>m.CpHomeModule)},
  // Search Content   
    {path:  'contents/list_webinars', component:ContentsWebinarComponent,data: {magazineId: environment.magazineId }},
    {path:  'contents/list_infographics',component:ContentInfographicsComponent,data: {magazineId: environment.magazineId }},  
    {path:  'contents/list_industry-events', component:ContentInfographicsComponent,data: {magazineId: environment.magazineId }},
    {path:  'contents/searchcontent/:any/:slug', component:ContentSearchComponent,data: {magazineId: environment.magazineId }},
    {path:  'contents/searchcontent/:any', component:ContentSearchComponent,data: {magazineId: environment.magazineId }},
    {path:  'contents/searchcontent', component:ContentSearchComponent,data: {magazineId: environment.magazineId }},
  
  //View Page Content    
    {path:  'contents/:any/:any/:any', component:ContentViewComponent,data: {magazineId: environment.magazineId }},
    {path:  'issues/:any/:any/:any', component:ContentViewComponent,data: {magazineId: environment.magazineId }},   
  //Taxonomy
    // {path:  'formulary/:any', loadChildren: () =>import('./cp-taxonomy/cp-taxonomy.module').then (m=>m.CpTaxonomyModule)},
    {path:  'news/:any', loadChildren: () =>import('./cp-taxonomy/cp-taxonomy.module').then (m=>m.CpTaxonomyModule)},
    {path:  'blog/:any', loadChildren: () =>import('./cp-taxonomy/cp-taxonomy.module').then (m=>m.CpTaxonomyModule)},


    {path:  'topics', loadChildren: () =>import('./cp-taxonomy/cp-taxonomy.module').then (m=>m.CpTaxonomyModule)},
    {path:  'topics/:any', loadChildren: () =>import('./cp-taxonomy/cp-taxonomy.module').then (m=>m.CpTaxonomyModule)},  
    {path:  'contract-manufacturing', loadChildren: () =>import('./cp-taxonomy/cp-taxonomy.module').then (m=>m.CpTaxonomyModule)},
    {path:  'contract-manufacturing/:any', loadChildren: () =>import('./cp-taxonomy/cp-taxonomy.module').then (m=>m.CpTaxonomyModule)},  
    {path:  'drug-discovery-and-development', loadChildren: () =>import('./cp-taxonomy/cp-taxonomy.module').then (m=>m.CpTaxonomyModule)},
    {path:  'drug-discovery-and-development/:any', loadChildren: () =>import('./cp-taxonomy/cp-taxonomy.module').then (m=>m.CpTaxonomyModule)},
    {path:  'packaging', loadChildren: () =>import('./cp-taxonomy/cp-taxonomy.module').then (m=>m.CpTaxonomyModule)},  
    {path:  'packaging/:any', loadChildren: () =>import('./cp-taxonomy/cp-taxonomy.module').then (m=>m.CpTaxonomyModule)}, 
    {path:  'compliance', loadChildren: () =>import('./cp-taxonomy/cp-taxonomy.module').then (m=>m.CpTaxonomyModule)},
    {path:  'compliance/:any', loadChildren: () =>import('./cp-taxonomy/cp-taxonomy.module').then (m=>m.CpTaxonomyModule)},  
    {path:  'columns',  loadChildren: () =>import('./cp-taxonomy/cp-taxonomy.module').then (m=>m.CpTaxonomyModule)},
    {path:  'columns/:any',  loadChildren: () =>import('./cp-taxonomy/cp-taxonomy.module').then (m=>m.CpTaxonomyModule)},
    {path:  'knowledge-center/:any', loadChildren: () =>import('./cp-taxonomy/cp-taxonomy.module').then (m=>m.CpTaxonomyModule)},
    // {path:  'salary-survey/:any', loadChildren: () =>import('./cp-taxonomy/cp-taxonomy.module').then (m=>m.CpTaxonomyModule)},
    // {path:  'breaking-news/:any', loadChildren: () =>import('./cp-taxonomy/cp-taxonomy.module').then (m=>m.CpTaxonomyModule)},
    {path:  'live-from-shows', loadChildren: () =>import('./cp-taxonomy/cp-taxonomy.module').then (m=>m.CpTaxonomyModule)},
    
  
  //Contents
  
    // {path:  'glossary', component:ContentGlossaryComponent,data: {magazineId: environment.magazineId }},
    {path:  'contents/viewwebsite/:any', component : NotFoundComponent},
    {path:  'contents/2487', component : NotFoundComponent},
    {path:  'contents/2543', component : NotFoundComponent},
    {path:  'contents/:any',loadChildren: () =>import('./cp-content/cp-content.module').then (m=>m.CpContentModule)},
    
    {path:'resources',loadChildren: () =>import('./cp-content/cp-content.module').then (m=>m.CpContentModule)},
    {path: 'profile',component : UserProfileComponent,data: {magazineId: environment.magazineId }},
    {path: 'user/verifyUser/:token/:email',component:UserMailVerifyComponent},
  
   
  // BuyerGuide Case 
    {path:  'csd',component : DirectoryHomePageComponent,data: {magazineId: environment.magazineId }},
    {path:  'csd/contract-services-directory',component : DirectoryHomePageComponent,data: {magazineId: environment.magazineId }},
  
  
  // OtherCase Static Content
    {path: 'subscribe-now', component : StaticContentComponent,data: {magazineId: environment.magazineId }},
    {path: 'advertise-with-us',component : StaticContentComponent,data: {magazineId: environment.magazineId }},
    {path: 'enewsletter-archive',component : StaticContentComponent,data: {magazineId: environment.magazineId }},
    {path: 'staff',component : StaticContentComponent,data: {magazineId: environment.magazineId }},
    {path: 'editorial-guidelines',component : StaticContentComponent,data: {magazineId: environment.magazineId }},
    {path: 'terms-and-conditions',component : StaticContentComponent,data: {magazineId: environment.magazineId }},
    {path: 'privacy-policy',component : StaticContentComponent,data: {magazineId: environment.magazineId }},
    {path: 'about-us', component : StaticContentComponent,data: {magazineId: environment.magazineId }},
    {path: 'contact-us', component : StaticContentComponent,data: {magazineId: environment.magazineId }},
  
  //Rss
    {path: 'rssfeeds', component : ContentRssFeedsComponent,data: {magazineId: environment.magazineId }},
    {path:  'issues/:slug',component : ContentIssueComponent,data: {magazineId: environment.magazineId }},
    {path:  'heaps/view/:any',component : ContentTopCompanyComponent,data: {magazineId: environment.magazineId }},
    {path:  'heaps/view/:any/:any',component : ContentTopCompanyComponent,data: {magazineId: environment.magazineId }},
    {path:  'heaps/view/:any/:any/:any',component : ContentTopCompanyComponent,data: {magazineId: environment.magazineId }},
    {path:  "**", component : NotFoundComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
