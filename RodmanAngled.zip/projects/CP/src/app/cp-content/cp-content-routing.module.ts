import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ContentListComponent } from './content-list/content-list.component';



const routes: Routes = [
  { path : "", component: ContentListComponent  },
  { path : ":any", component: ContentListComponent  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CpContentRoutingModule { }
