import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TaxonomyListComponent } from './taxonomy-list/taxonomy-list.component';



const routes: Routes = [
  { path : "", component: TaxonomyListComponent  },
  { path : ":any", component: TaxonomyListComponent  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CpTaxonomyRoutingModule { }
