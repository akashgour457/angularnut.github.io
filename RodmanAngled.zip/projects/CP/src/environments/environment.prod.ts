export const environment = {
  production: true,
  API_URL :'http://3.85.159.45:8042/' ,
  magazineId:'7',
  magazineName:'CP',
  homeBoxId:"24975,5",
  breakingNews:'2487',
  TabOne:"2487,5", 
  TabTwo:"2486,5",
  feature:'2486'
};
