import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminHomeRoutingModule } from './admin-home-routing.module';
import { HomePageComponent } from './components/home-page/home-page.component';
import {HomeModule} from 'rodman-core';
import {SitesModule} from 'rodman-core';
import {NavComponent} from '../admin-sites/components/nav/nav.component';


@NgModule({
  declarations: [HomePageComponent,NavComponent],
  imports: [
    CommonModule,
    AdminHomeRoutingModule,
    HomeModule,
    SitesModule,
  ]
})
export class AdminHomeModule { }
