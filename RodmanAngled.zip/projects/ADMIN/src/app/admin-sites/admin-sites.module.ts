import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminSitesRoutingModule } from './admin-sites-routing.module';
import { NavComponent } from './components/nav/nav.component';


@NgModule({
  declarations: [NavComponent],
  imports: [
    CommonModule,
    AdminSitesRoutingModule
  ],
  exports: [NavComponent]
})
export class AdminSitesModule { }
