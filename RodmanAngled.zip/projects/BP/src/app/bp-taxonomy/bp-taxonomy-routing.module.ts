import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {BpTaxonomyListComponent} from './bp-taxonomy-list/bp-taxonomy-list.component';

const routes: Routes = [
  { path : "", component: BpTaxonomyListComponent  },
  { path : ":any", component: BpTaxonomyListComponent  },
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BpTaxonomyRoutingModule { }
