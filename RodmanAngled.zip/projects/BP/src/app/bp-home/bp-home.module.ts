import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BpHomeRoutingModule } from './bp-home-routing.module';
import { BpHomeComponent } from './bp-home/bp-home.component';
import { HttpClientModule } from '@angular/common/http';
import {HomeModule,SitesModule,ContentsModule,AdsModule} from 'rodman-core';
import { DfpModule } from 'ngx-dfp';

@NgModule({
  declarations: [BpHomeComponent],
  imports: [
    CommonModule,
    HttpClientModule,
    HomeModule,SitesModule,ContentsModule,AdsModule,
    DfpModule.forRoot({
      idleLoad: true,
      enableVideoAds: true,
      personalizedAds: true, // Request personalized ads by default
      singleRequestMode: true, // Only applies to initial refresh
      onSameNavigation: 'refresh',
      globalTargeting: {
      }
    }),
    BpHomeRoutingModule
  ]
})
export class BpHomeModule { }
