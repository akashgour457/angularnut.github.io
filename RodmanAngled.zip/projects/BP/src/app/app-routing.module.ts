import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { environment } from '../environments/environment';

// Rodman Core Import
import { ContentSearchComponent } from '../../../rodman-core/src/lib/contents/content-search/content-search.component';
import { NotFoundComponent } from '../../../rodman-core/src/lib/sites/components/not-found/not-found.component';
import { UserProfileComponent } from '../../../rodman-core/src/lib/users/Components/user-profile/user-profile.component';
import { StaticContentComponent } from "../../../rodman-core/src/lib/contents/static-content/static-content.component";
import { ContentGlossaryComponent } from "../../../rodman-core/src/lib/contents/content-glossary/content-glossary.component";
import { ContentIssueComponent } from "../../../rodman-core/src/lib/contents/content-issue/content-issue.component";
import { ContentRssFeedsComponent } from "../../../rodman-core/src/lib/contents/content-rss-feeds/content-rss-feeds.component";
import { DirectoryHomePageComponent } from '../../../rodman-core/src/lib/directory-section/directory-home-page/directory-home-page.component';
import { ContentInfographicsComponent } from "../../../rodman-core/src/lib/contents/content-infographics/content-infographics.component";
import { ContentsWebinarComponent } from '../../../rodman-core/src/lib/contents/contents-webinar/contents-webinar.component';
import {BpContentViewComponent} from './bp-contant/bp-content-view/bp-content-view.component';
import {BpTopCompanyComponent} from './bp-contant/bp-top-company/bp-top-company.component';

const routes: Routes = [
  {path: "", pathMatch: 'full' , loadChildren: () =>import('./bp-home/bp-home.module').then (m=>m.BpHomeModule)},
// Search Content   
  {path:  'contents/list_webinars', component:ContentsWebinarComponent,data: {magazineId: environment.magazineId }},
  {path:  'contents/list_infographics',component:ContentInfographicsComponent,data: {magazineId: environment.magazineId }},  
  {path:  'contents/list_industry-events', component:ContentInfographicsComponent,data: {magazineId: environment.magazineId }},
  {path:  'contents/searchcontent/:any/:slug', component:ContentSearchComponent,data: {magazineId: environment.magazineId }},
  {path:  'contents/searchcontent/:any', component:ContentSearchComponent,data: {magazineId: environment.magazineId }},
  {path:  'contents/searchcontent', component:ContentSearchComponent,data: {magazineId: environment.magazineId }},

//View Page Content    
  {path:  'contents/:any/:any/:any', component:BpContentViewComponent,data: {magazineId: environment.magazineId }},
  {path:  'issues/:any/:any/:any', component:BpContentViewComponent,data: {magazineId: environment.magazineId }},   
//Taxonomy
  // {path:  'formulary/:any', loadChildren: () =>import('./bp-taxonomy/bp-taxonomy.module').then (m=>m.BpTaxonomyModule)},
  {path:  'news/:any', loadChildren: () =>import('./bp-taxonomy/bp-taxonomy.module').then (m=>m.BpTaxonomyModule)},
 // {path:  'blog/:any', loadChildren: () =>import('./bp-taxonomy/bp-taxonomy.module').then (m=>m.BpTaxonomyModule)},


  {path:  'markets', loadChildren: () =>import('./bp-taxonomy/bp-taxonomy.module').then (m=>m.BpTaxonomyModule)},
  {path:  'markets/:any', loadChildren: () =>import('./bp-taxonomy/bp-taxonomy.module').then (m=>m.BpTaxonomyModule)},  
  {path:  'materials', loadChildren: () =>import('./bp-taxonomy/bp-taxonomy.module').then (m=>m.BpTaxonomyModule)},
  {path:  'materials/:any', loadChildren: () =>import('./bp-taxonomy/bp-taxonomy.module').then (m=>m.BpTaxonomyModule)},  
  {path:  'solutions', loadChildren: () =>import('./bp-taxonomy/bp-taxonomy.module').then (m=>m.BpTaxonomyModule)},
  {path:  'solutions/:any', loadChildren: () =>import('./bp-taxonomy/bp-taxonomy.module').then (m=>m.BpTaxonomyModule)},
  {path:  'events', loadChildren: () =>import('./bp-taxonomy/bp-taxonomy.module').then (m=>m.BpTaxonomyModule)},  
  {path:  'events/:any', loadChildren: () =>import('./bp-taxonomy/bp-taxonomy.module').then (m=>m.BpTaxonomyModule)}, 
  {path:  'departments', loadChildren: () =>import('./bp-taxonomy/bp-taxonomy.module').then (m=>m.BpTaxonomyModule)},
  {path:  'departments/:any', loadChildren: () =>import('./bp-taxonomy/bp-taxonomy.module').then (m=>m.BpTaxonomyModule)},  
  {path:  'classifieds',  loadChildren: () =>import('./bp-taxonomy/bp-taxonomy.module').then (m=>m.BpTaxonomyModule)},
  {path:  'classifieds/:any',  loadChildren: () =>import('./bp-taxonomy/bp-taxonomy.module').then (m=>m.BpTaxonomyModule)},
  {path:  'knowledge-center', loadChildren: () =>import('./bp-taxonomy/bp-taxonomy.module').then (m=>m.BpTaxonomyModule)},
  {path:  'knowledge-center/:any', loadChildren: () =>import('./bp-taxonomy/bp-taxonomy.module').then (m=>m.BpTaxonomyModule)},
  {path:  'live-from-shows', loadChildren: () =>import('./bp-taxonomy/bp-taxonomy.module').then (m=>m.BpTaxonomyModule)},
  {path:'resources',loadChildren: () =>import('./bp-taxonomy/bp-taxonomy.module').then (m=>m.BpTaxonomyModule)},
  {path:'topics',loadChildren: () =>import('./bp-taxonomy/bp-taxonomy.module').then (m=>m.BpTaxonomyModule)},
  {path:'topics/:any',loadChildren: () =>import('./bp-taxonomy/bp-taxonomy.module').then (m=>m.BpTaxonomyModule)},
  {path:'print-columns',loadChildren: () =>import('./bp-taxonomy/bp-taxonomy.module').then (m=>m.BpTaxonomyModule)},
  {path:'print-columns/:any',loadChildren: () =>import('./bp-taxonomy/bp-taxonomy.module').then (m=>m.BpTaxonomyModule)},
  {path:'brandssuppliers',loadChildren: () =>import('./bp-taxonomy/bp-taxonomy.module').then (m=>m.BpTaxonomyModule)},
  {path:'brandssuppliers/:any',loadChildren: () =>import('./bp-taxonomy/bp-taxonomy.module').then (m=>m.BpTaxonomyModule)},
  {path:'showcases',loadChildren: () =>import('./bp-taxonomy/bp-taxonomy.module').then (m=>m.BpTaxonomyModule)},
  {path:'showcases/:any',loadChildren: () =>import('./bp-taxonomy/bp-taxonomy.module').then (m=>m.BpTaxonomyModule)},
  {path:'components',loadChildren: () =>import('./bp-taxonomy/bp-taxonomy.module').then (m=>m.BpTaxonomyModule)},
  {path:'components/:any',loadChildren: () =>import('./bp-taxonomy/bp-taxonomy.module').then (m=>m.BpTaxonomyModule)},


//Contents

  // {path:  'glossary', component:ContentGlossaryComponent,data: {magazineId: environment.magazineId }},
  {path:  'contents/viewwebsite/:any', component : NotFoundComponent},
  {path:  'contents/2487', component : NotFoundComponent},
  {path:  'contents/2543', component : NotFoundComponent},
   {path:  'contents/:any',loadChildren: () =>import('./bp-contant/bp-contant.module').then (m=>m.BpContantModule)},
  
  // {path: 'profile',component : UserProfileComponent,data: {magazineId: environment.magazineId }},
  // {path: 'user/verifyUser/:token/:email',component:UserMailVerifyComponent},

 
// BuyerGuide Case 
  {path:  'csd',component : DirectoryHomePageComponent,data: {magazineId: environment.magazineId }},
  {path:  'csd/contract-services-directory',component : DirectoryHomePageComponent,data: {magazineId: environment.magazineId }},


// OtherCase Static Content
  {path: 'subscribe-now', component : StaticContentComponent,data: {magazineId: environment.magazineId }},
  {path: 'advertise-with-us',component : StaticContentComponent,data: {magazineId: environment.magazineId }},
  {path: 'enewsletter-archive',component : StaticContentComponent,data: {magazineId: environment.magazineId }},
  {path: 'staff',component : StaticContentComponent,data: {magazineId: environment.magazineId }},
  {path: 'editorial-guidelines',component : StaticContentComponent,data: {magazineId: environment.magazineId }},
  {path: 'terms-and-conditions',component : StaticContentComponent,data: {magazineId: environment.magazineId }},
  {path: 'privacy-policy',component : StaticContentComponent,data: {magazineId: environment.magazineId }},
  {path: 'about-us', component : StaticContentComponent,data: {magazineId: environment.magazineId }},
  {path: 'contact-us', component : StaticContentComponent,data: {magazineId: environment.magazineId }},

//Rss
  {path: 'rssfeeds', component : ContentRssFeedsComponent,data: {magazineId: environment.magazineId }},
  {path:  'issues/:slug',component : ContentIssueComponent,data: {magazineId: environment.magazineId }},
  {path:  'heaps/view/:any',component : BpTopCompanyComponent,data: {magazineId: environment.magazineId }},
  {path:  'heaps/view/:any/:any',component : BpTopCompanyComponent,data: {magazineId: environment.magazineId }},
  {path:  'heaps/view/:any/:any/:any',component : BpTopCompanyComponent,data: {magazineId: environment.magazineId }},
  {path:  "**", component : NotFoundComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
