import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BpContantRoutingModule } from './bp-contant-routing.module';
import { BpContentListComponent } from './bp-content-list/bp-content-list.component';
import { ContentsModule ,HomeModule,SitesModule,AdsModule,HeapsModule} from 'rodman-core';
import { DfpModule } from 'ngx-dfp';

@NgModule({
  declarations: [BpContentListComponent],
  imports: [
    CommonModule,
    BpContantRoutingModule,   
    ContentsModule,
    HomeModule,
    SitesModule,
    AdsModule,
    HeapsModule,    
    DfpModule.forRoot({
      idleLoad: true,
      enableVideoAds: true,
      personalizedAds: true, // Request personalized ads by default
      singleRequestMode: true, // Only applies to initial refresh
      onSameNavigation: 'refresh',
      globalTargeting: {
        // food: ['NUT', 'HOME']
      }
    }) 
  ]
})
export class BpContantModule { }
