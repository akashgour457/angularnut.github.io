import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {BpContentListComponent} from './bp-content-list/bp-content-list.component';

const routes: Routes = [
  { path : "", component: BpContentListComponent  },
  { path : ":any", component: BpContentListComponent  },
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BpContantRoutingModule { }
