import { Component, OnInit } from '@angular/core';
import { Router ,NavigationEnd } from '@angular/router'; 
import { environment } from '../../../environments/environment';
@Component({
  selector: 'BP-bp-top-company',
  templateUrl: './bp-top-company.component.html',
  styleUrls: ['./bp-top-company.component.css']
})
export class BpTopCompanyComponent implements OnInit {

  contentPageUrl : any ;
  public magazineId :any;
  constructor(private router:Router) {
    this.magazineId = environment.magazineId ;
       router.events.subscribe(event => {
        if (event instanceof NavigationEnd ) {
          this.contentPageUrl = event.url;         
        }
      });
     
   }
  ngOnInit() {
  }

}
