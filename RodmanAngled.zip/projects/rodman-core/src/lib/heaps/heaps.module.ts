import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeapsRoutingModule } from './heaps-routing.module';

import { NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { CarouselModule } from 'ngx-bootstrap';
import { AdsModule} from '../ads/ads.module';
import { ContentsModule } from '../contents/contents.module';
import { TopCompanyHomePageSliderComponent } from './top-company-home-page-slider/top-company-home-page-slider.component';
import { TopCompanyHomePageComponent } from './top-company-home-page/top-company-home-page.component';


@NgModule({
  declarations: [TopCompanyHomePageComponent, TopCompanyHomePageSliderComponent],
  imports: [
    CommonModule,
    HeapsRoutingModule,
    AdsModule,
    ContentsModule,
    NgbModule,
    CarouselModule.forRoot()
  ],
  exports:[ TopCompanyHomePageComponent,TopCompanyHomePageSliderComponent ],
  providers: [{ provide: NgbModule} ],
})
export class HeapsModule { }
