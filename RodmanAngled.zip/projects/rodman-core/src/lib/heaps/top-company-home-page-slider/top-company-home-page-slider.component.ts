import { Component, OnInit,Input } from '@angular/core';
import { NgbModule,NgbCarouselConfig } from '@ng-bootstrap/ng-bootstrap';
import { RodmanCoreService } from '../../rodman-core.service';
import { TopCompanyHomePageSliderService } from './top-company-home-page-slider.service';

@Component({
  selector: 'CoreLib-top-company-home-page-slider',
  templateUrl: './top-company-home-page-slider.component.html',
  styleUrls: ['./top-company-home-page-slider.component.css'],
  providers: [NgbModule,NgbCarouselConfig],
})
export class TopCompanyHomePageSliderComponent implements OnInit {
  @Input() currentURL:any;
  @Input() magazineId:any;
  @Input() urlId:any;
  showNavigationArrows = true;
  showNavigationIndicators = true;
  sliderData:any=[];

  constructor(config: NgbCarouselConfig, public RodmanCoreService:RodmanCoreService,public TopCompanySliderService:TopCompanyHomePageSliderService) { 
    // config.interval = 3000;
    // config.showNavigationArrows = false;
    // config.showNavigationIndicators = false;
  }

  ngOnInit() {
    this.getTopCompinesSliderData();
  }

  getTopCompinesSliderData(){
    this.TopCompanySliderService.getTopCompinesSliderData(this.currentURL,this.magazineId).subscribe((data =>{
      this.sliderData = data['data'];
   }))
  }

  getImage(imageId){
    return this.RodmanCoreService.displayImageUrl(imageId);
  }

  safeHtmlReplace(data){
    return this.RodmanCoreService.safeHtmlReplace(data);
  }
}