import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { throwError, from } from 'rxjs';
import { catchError } from 'rxjs/operators';
import * as configVar from '../../rodman-core.service';
import { RodmanCoreService } from '../../rodman-core.service';

@Injectable({
  providedIn: 'root'
})
export class TopCompanyHomePageSliderService {
  constructor(private HttpClient: HttpClient,private RodmanCoreService:RodmanCoreService ) { }

   getTopCompinesSliderData(pageUrl,magazineId) {
    return this.HttpClient.post<any>(configVar.apiURL+'heapsController/getHeapContent',{pageUrl:pageUrl,magazineId:magazineId,pageNumber:0,limit:0,types:'slider'}, configVar.httpOptions).pipe(
      catchError(this.RodmanCoreService.handleError)
    );
  }
}