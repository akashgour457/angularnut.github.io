import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { throwError, from } from 'rxjs';
import { catchError } from 'rxjs/operators';
import * as configVar from '../../rodman-core.service';
import { RodmanCoreService } from '../../rodman-core.service';

@Injectable({
  providedIn: 'root'
})
export class TopCompanyHomePageService {

  constructor(private HttpClient: HttpClient,private RodmanCoreService:RodmanCoreService ) { }

  getTopCompinesTab(pageUrl,magazineId) {
     return this.HttpClient.post<any>(configVar.apiURL+'heapsController/heapScroller',{pageUrl:pageUrl,magazineId:magazineId}, configVar.httpOptions).pipe(
       catchError(this.RodmanCoreService.handleError)
     );
  }

  getTopCompinesContent(pageUrl,magazineId,pageNumber,limit) {
    return this.HttpClient.post<any>(configVar.apiURL+'heapsController/getHeapContent',{pageUrl:pageUrl,magazineId:magazineId,pageNumber:pageNumber,limit:limit,types:""}, configVar.httpOptions).pipe(
      catchError(this.RodmanCoreService.handleError)
    );
  }
}