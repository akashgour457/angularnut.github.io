import { Component, OnInit ,Input} from '@angular/core';
import {RodmanCoreService} from '../../rodman-core.service';
import {TopCompanyHomePageService} from './top-company-home-page.service';

@Component({
  selector: 'CoreLib-top-company-home-page',
  templateUrl: './top-company-home-page.component.html',
  styleUrls: ['./top-company-home-page.component.css']
})
export class TopCompanyHomePageComponent implements OnInit {
  @Input() currentURL:any;
  @Input() magazineId:any;
  getAllAd = [];
  tabData : any;
  datas = [];
  contentData : any=[];
  viewAdRender:number;
  limit=5;
  page=0;
  loading=true;
  selectedTab:any;
  constructor(public RodmanCoreService : RodmanCoreService,  public TopHomepageService : TopCompanyHomePageService) { 
  }

  ngOnInit() {
  }
   
  ngOnChanges(){
    this.currentURL = this.currentURL.replace('/', '');
    this.selectedTab = this.currentURL.split('/');
    this.selectedTab = this.selectedTab[2];
    this.loading= true;
    this.page=0;
    this.getAllAd = [];
    this.tabData = [];
    this.datas = [];
    this.contentData = [];
    this.viewAdRender=0;
    this.page=0;
    this.getTopCompinesTab();
    this.getTopCompinesContent();
    this.getads();
  } 

  getads(){
    this.RodmanCoreService.getAllAdst(this.magazineId).subscribe((data =>{
      this.getAllAd = data;
      this.viewAdRender = 1;
    }))
  }

  getTopCompinesTab(){
    this.TopHomepageService.getTopCompinesTab(this.currentURL,this.magazineId).subscribe((data =>{
      this.tabData = data['data'];
    }))
  }

  getTopCompinesContent(){
    this.TopHomepageService.getTopCompinesContent(this.currentURL,this.magazineId,this.page,this.limit).subscribe((data =>{
    this.datas = data['data'];
      this.page = data['page']+1;
      for(let content of this.datas){
        this.contentData.push(content);  
      } 
      this.loading = false;
    }))
  }

  loadMoreData(){
    this.loading = true;
    this.getTopCompinesContent();    
  }

  getImage(imageId){
    return this.RodmanCoreService.displayImageUrl(imageId);
  }

  extractNameFromJson(data){
    return this.RodmanCoreService.extractNameFromJson(data);
  }

  safeHtmlReplace(data){
    return this.RodmanCoreService.safeHtmlReplace(data)
  }
}
