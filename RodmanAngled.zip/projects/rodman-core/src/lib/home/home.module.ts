import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { HomeRoutingModule } from './home-routing.module';
import { FeaturedContentComponent } from './components/featured-content/featured-content.component';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { HomeSliderComponent } from './components/home-slider/home-slider.component';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { AdsModule } from '../ads/ads.module';

  


@NgModule({
  declarations: [FeaturedContentComponent, HomeSliderComponent],
  imports: [
    NgbModule,
    AdsModule,
    CommonModule,
    AngularFontAwesomeModule,
    HomeRoutingModule,
    HttpClientModule
  ],
  exports: [FeaturedContentComponent,HomeSliderComponent]
})
export class HomeModule { }
