import { Component, OnInit } from '@angular/core';
import {NgbModule,NgbCarouselConfig , NgbCarousel, NgbSlideEvent, NgbSlideEventSource } from '@ng-bootstrap/ng-bootstrap';
import { HomeSliderService } from './home-slider.service';
import * as configVar from '../../../rodman-core.service';
import { RodmanCoreService } from '../../../rodman-core.service';

@Component({
  inputs: ['magazineId','homeBoxId'],
  selector: 'CoreLib-home-slider',
  templateUrl: './home-slider.component.html',
  styleUrls: ['./home-slider.component.css'],
  providers: [NgbModule,NgbCarouselConfig],
})
export class HomeSliderComponent implements OnInit {
  magazineId;
  homeBoxId;
  sliderData;
  homeSliderData;
  loading= true;
  constructor(private HomeSliderService: HomeSliderService,config: NgbCarouselConfig,public RodmanCoreService:RodmanCoreService) { 
    config.interval = 3000;
    // config.showNavigationArrows = false;
    // config.showNavigationIndicators = false;
  }

  ngOnInit() {
    this.HomeSliderService.getHomeSlider(this.magazineId,this.homeBoxId).subscribe((data)=>{
      this.homeSliderData = data['data'];
      this.loading=false;
    }); 
  }

  getImage(imageId){
    return this.RodmanCoreService.displayImageUrl(imageId);
  }

  safeHtmlReplace(data){
    return this.RodmanCoreService.safeHtmlReplace(data);
  }

}
