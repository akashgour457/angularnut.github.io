import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { RodmanCoreService } from '../../../rodman-core.service';
import {FormGroup, FormControl, Validators} from "@angular/forms";
import * as configVar from '../../../rodman-core.service';

@Injectable({
  providedIn: 'root'
})
export class FeatureContentService {
  errorData: {};

  constructor(private HttpClient: HttpClient,private RodmanCoreService: RodmanCoreService) { }

  getfetureData(magazineId,id) {
    return this.HttpClient.post<any>(configVar.apiURL+'contentscontroller/getBoxContent',{magazineId:magazineId,id:id}, configVar.httpOptions).pipe(
      catchError(this.RodmanCoreService.handleError)
    );
  }
}
