import { Component, OnInit, Input } from '@angular/core';
import { FeatureContentService } from './feature-content.service';
import { RodmanCoreService } from '../../../rodman-core.service';  
import * as configVar from '../../../rodman-core.service';


@Component({
  inputs: ['magazineId','featured_content_section'],
  selector: 'CoreLib-featured-content',
  templateUrl: './featured-content.component.html',
  styleUrls: ['./featured-content.component.css']
})

export class FeaturedContentComponent implements OnInit {
  @Input() getAllAd:any;
  @Input() location:string;
  viewAdRender:number;
  featuredContentData;
  featuredContentHeading;
  magazineId;
  featured_content_section;
  constructor(private FeatureContentService: FeatureContentService,public RodmanCoreService:RodmanCoreService) { }

  ngOnInit() {
    this.FeatureContentService.getfetureData(this.magazineId,this.featured_content_section).subscribe((data)=>{
      this.featuredContentData = data['data'];
      this.featuredContentHeading = data['contentType'];
      this.viewAdRender = 1;
    }); 
  }

  getImage(imageId){
    return this.RodmanCoreService.displayImageUrl(imageId);
  }

  extractNameFromJson(data){
    return this.RodmanCoreService.extractNameFromJson(data);
  }

  safeHtmlReplace(data){
    return this.RodmanCoreService.safeHtmlReplace(data);
  }

}
