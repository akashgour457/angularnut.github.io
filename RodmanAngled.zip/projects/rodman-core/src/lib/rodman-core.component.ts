import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'CoreLib-RodmanCore',
  template: `
    <p>
      rodman-core works!
    </p>
  `,
  styles: []
})
export class RodmanCoreComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
