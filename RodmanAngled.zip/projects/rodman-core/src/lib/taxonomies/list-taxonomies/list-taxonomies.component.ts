import { Component, OnInit ,HostListener} from '@angular/core';
import { ListTaxonomiesService } from '../list-taxonomies/list-taxonomies.service';
import { Router, RouterModule ,NavigationEnd } from '@angular/router';
import * as configVar from '../../rodman-core.service';
import { RodmanCoreService } from '../../rodman-core.service';
import { Observable} from 'rxjs'; 



@Component({
  selector: 'CoreLib-list-taxonomies',
  inputs: ['routeUrl','magazineId',] ,
  templateUrl: './list-taxonomies.component.html',
  styleUrls: ['./list-taxonomies.component.css']
})
export class ListTaxonomiesComponent implements OnInit {
  routeUrl;
  magazineId;
  taxonomyData=[];
  listTaxonomyData:any; 
  test:any; 
  slugHeading;
  limit=10;
  page=0;
  contentType='';
  contentTaxonomy;
  taxonomyUrl;
  taxonomyUrlTo;
  loading=true;
  currentURL;
  sliderData=[];
  staticUrl= '/';
  tagTaxonomy = [];
  all:any =[];

  constructor(public Router:Router,public RouterModule:RouterModule, private ListTaxonomiesService: ListTaxonomiesService,public RodmanCoreService:RodmanCoreService) { 
    Router.events.subscribe(event => {
      if (event instanceof NavigationEnd ) {
        this.currentURL = event.url; 
      }
    });
  }


  ngOnInit() {
    if((this.magazineId ==1) ||  (this.magazineId ==5)){
      this.staticUrl = '/knowledge-center/'; 
    }
    if((this.magazineId ==9)){
      this.staticUrl = '/knowledge-base/'; 
    }
  }

  ngOnChanges(){  
    this.loading= true;
    this.page=0;
    this.all=[];
    this.slugHeading;
    this.taxonomyData=[];
    this.sliderData=[];
    this.contentTaxonomy=[];
    this.getTaxonomyData();
  }

  getTaxonomyData(){
    this.taxonomyUrl = this.routeUrl.split('/');  
    this.taxonomyUrlTo = this.taxonomyUrl[1];
    let cleanUrl  = this.routeUrl.replace('/',"");
    
    if(this.page==0){ 
      this.slugHeading = this.titleHeading();
      this.ListTaxonomiesService.getContentTopTaxonomy(cleanUrl,this.magazineId).subscribe((data)=>{
        this.contentTaxonomy = data['CONTENT_TAXONOMYS']; 
        this.all = data['all'];       
      });        
    } 
    

    this.ListTaxonomiesService.getContent(cleanUrl,this.magazineId,this.limit,this.page,this.contentType).subscribe((data)=>{
      this.listTaxonomyData = data['data'];
      if(this.page==0){ 
        // this.slugHeading = data['contentTypeName'];
        this.sliderData.push(this.listTaxonomyData);  
      } 
      this.page = data['page']+1;
      for(let taxonomy of this.listTaxonomyData){
        this.taxonomyData.push(taxonomy);  
      }
      this.loading= false;
    }); 
  }

  titleHeading(){
    let tempUrl = this.returnUrl();
    let tempArray = [];
    if(tempUrl.includes('view_')) { 
      tempArray = tempUrl.split('view_');
      this.slugHeading = tempArray[tempArray.length-1];
    }else{
      tempArray = tempUrl.split('/');
      this.slugHeading = tempArray[tempArray.length-1].replace('--',' & ');
    }    
    return this.slugHeading;
  }

  // routing(slug){
  //   this.Router.navigateByUrl(this.taxonomyUrlTo+'/'+slug);
  // }

  safeHtml(data){
    return this.RodmanCoreService.safeHtmlReplace(data);
  }  
   
  bodyCharacterLength(data){
    return this.RodmanCoreService.bodyCharacterLength(data); 
  }

  getImage(imageId){
    return this.RodmanCoreService.displayImageUrl(imageId);
  }



  loadMoreData(){
    this.loading= true;
    this.getTaxonomyData();
  }

  extractNameFromJson(data){
    return this.RodmanCoreService.extractNameFromJson(data);
  }

  returnUrl(){
    return this.RodmanCoreService.returnUrl();
  }

  activeTaxonomy(slug){
    let activeUrl = this.returnUrl();
    if (activeUrl.includes(slug)) { 
      return "bg-primary active";
    }
    return true;

  }


}