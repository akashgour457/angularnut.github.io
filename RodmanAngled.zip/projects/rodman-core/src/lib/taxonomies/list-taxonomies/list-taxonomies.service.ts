import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { throwError, from } from 'rxjs';
import { catchError } from 'rxjs/operators';
import * as configVar from '../../rodman-core.service';
import { RodmanCoreService } from '../../rodman-core.service';
import { Observable} from 'rxjs'; 

@Injectable({
  providedIn: 'root'
})
export class ListTaxonomiesService {
  
  constructor(private HttpClient: HttpClient,private RodmanCoreService:RodmanCoreService ) { }

  getContent(slug,magazineId,limit,page,contentType) {
     return this.HttpClient.post<any>(configVar.apiURL+'taxonomysController/getContentTaxonomys',{pageUrl:slug,magazineId:magazineId,limit:limit,page:page,contentType:contentType}, configVar.httpOptions).pipe(
       catchError(this.RodmanCoreService.handleError)
     );
   }

  getContentTopTaxonomy(slug,magazineId) {
    return this.HttpClient.post<any>(configVar.apiURL+'taxonomysController/getTopTaxonomys',{pageUrl:slug,magazineId:magazineId}, configVar.httpOptions).pipe(
      catchError(this.RodmanCoreService.handleError)
    );
  }
  
  // Content Tagged Taxonomy via Content Id
  getContentTaxonomy(contentId,magazineId) {
    return this.HttpClient.post<any>(configVar.apiURL+'taxonomysController/getContentTaxonomyTagged',{contentId:contentId,magazineId:magazineId}, configVar.httpOptions).pipe(
      catchError(this.RodmanCoreService.handleError)
    );
  }
 }