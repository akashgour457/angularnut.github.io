import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import  {  FormsModule,  ReactiveFormsModule  }  from  '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { AdsModule } from '../ads/ads.module';
import { SitesModule } from '../sites/sites.module';

import { TaxonomiesRoutingModule } from './taxonomies-routing.module';
import { ListTaxonomiesComponent } from './list-taxonomies/list-taxonomies.component';


@NgModule({
  declarations: [ListTaxonomiesComponent],
  imports: [
    CommonModule,
    AdsModule,
    SitesModule,
    TaxonomiesRoutingModule,
    HttpClientModule,FormsModule,  ReactiveFormsModule ,RouterModule
  ],
  exports: [ListTaxonomiesComponent,RouterModule]
})
export class TaxonomiesModule { }
