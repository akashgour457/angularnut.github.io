import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
// import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import  {  FormsModule,  ReactiveFormsModule  }  from  '@angular/forms';

import { SitesRoutingModule } from './sites-routing.module';
import { NavComponent } from './components/nav/nav.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { AngularFontAwesomeModule } from 'angular-font-awesome';


import {RodmanORMModule} from 'rodman-orm';
import { FootersliderComponent } from './components/footerslider/footerslider.component';
import { AuthenticationComponent } from '../users/authentication/authentication.component';
import { ModalModule } from 'ngx-bootstrap/modal';
import { CookieService } from 'ngx-cookie-service';
import { NotFoundComponent } from './components/not-found/not-found.component';
import { AdsModule } from "../ads/ads.module";
import { SliderComponent } from './components/slider/slider.component';




@NgModule({
  declarations: [NavComponent,AuthenticationComponent, HeaderComponent, FooterComponent, FootersliderComponent, NotFoundComponent, SliderComponent],
  imports: [
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    HttpClientModule,
    // HttpClient,    
    SitesRoutingModule,
    NgbModule,
    AngularFontAwesomeModule,
    RodmanORMModule,
    ModalModule.forRoot(),
    AdsModule
  ],
  providers: [CookieService],
  exports: [NavComponent,HeaderComponent,FooterComponent,NotFoundComponent,AuthenticationComponent,SliderComponent]
})
export class SitesModule { }
