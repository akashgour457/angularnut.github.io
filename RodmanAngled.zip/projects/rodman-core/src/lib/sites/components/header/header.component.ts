import { Component, OnInit } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { Router,NavigationEnd, RouterModule } from '@angular/router';
import { RodmanCoreService } from '../../../rodman-core.service';
import * as configVar from '../../../rodman-core.service';


@Component({
  selector: 'CoreLib-header',
  inputs: ['magazineId','magazineName','menuId','groupId' ,'fieldId', 'formId'],
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  public isCollapsed = true;
  magazineId;
  magazineName;
  menuId;
  groupId;
  fieldId;
  formId;
  isOverlayCookie;
  overlayCookie = false;
  Url;
  searchContent:string;


  constructor(public CookieService:CookieService,public Router:Router,public RodmanCoreService:RodmanCoreService) {
    this.Url = configVar.apiURL;
   }
    
  ngOnInit() {     
    // this.isOverlayCookie = this.CookieService.get('overlay_'+this.magazineId);
    // if(this.isOverlayCookie===''){
    //   const dateNow = new Date();
    //   dateNow.setMinutes(dateNow.getMinutes() + 30);
    //   this.CookieService.set('overlay_'+this.magazineId, 'Overlay' ,dateNow,'/',"");
    //   this.overlayCookie = true;   
    // }else{
    //   // console.log('Cookie Set_'+this.magazineId)
    // }
  }


  search(){    
    if(this.searchContent){
      this.Router.navigateByUrl('/contents/searchcontent/all/'+this.searchContent);
    }
  }

}
