import { Component, OnInit,Input } from '@angular/core';
import {NgbModule,NgbCarouselConfig , NgbCarousel, NgbSlideEvent, NgbSlideEventSource } from '@ng-bootstrap/ng-bootstrap';
import * as configVar from '../../../rodman-core.service';
import { RodmanCoreService } from '../../../rodman-core.service';


@Component({
  selector: 'CoreLib-slider',
  templateUrl: './slider.component.html',
  styleUrls: ['./slider.component.css'],
  providers: [NgbModule,NgbCarouselConfig],
})
export class SliderComponent implements OnInit {
  @Input() data:any;

  showNavigationArrows = false;
  showNavigationIndicators = false;
  constructor(config: NgbCarouselConfig,public RodmanCoreService:RodmanCoreService) { 
    config.interval = 2000;
    config.showNavigationArrows = true;
    config.showNavigationIndicators = true;
  }

  ngOnInit() {

  }

  getImage(imageId){
    return this.RodmanCoreService.displayImageUrl(imageId);
  }
  safeHtmlReplace(data){
    return this.RodmanCoreService.safeHtmlReplace(data);
  }

}