import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { RodmanCoreService } from '../../../rodman-core.service';
import * as configVar from '../../../rodman-core.service';

@Injectable({
  providedIn: 'root'
})
export class NavService {

  constructor(private HttpClient: HttpClient,private RodmanCoreService : RodmanCoreService ) { }

  getHeaderMenu(magazineId,menuId) {
    return this.HttpClient.post<any>(configVar.apiURL+'menuscontroller/displayMenu',{magazineId:magazineId,id:menuId},configVar.httpOptions ).pipe(
      catchError(this.RodmanCoreService.handleError)
    );
  }



  currentIssue(magazineId) {
    return this.HttpClient.post<any>(configVar.apiURL+'issuescontroller/latestIssueURL',{magazineId:magazineId},configVar.httpOptions ).pipe(
      catchError(this.RodmanCoreService.handleError)
    );
  }
}
