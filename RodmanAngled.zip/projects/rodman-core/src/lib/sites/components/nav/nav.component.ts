import { Component, OnInit } from '@angular/core';
import { NavService } from './nav.service';
import {Router} from "@angular/router";
import { RodmanCoreService } from '../../../rodman-core.service';

@Component({
  selector: 'CoreLib-nav',
  inputs: ['magazineId','menuId'],
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit {
  error: {};
  articles;
  magazineId;
  menuId;
  hoverIndex:number = -1;
  issueUrl;

  onHover(i:number){
    this.hoverIndex = i;
  }
  onHoverOut(i:number){
    this.hoverIndex = -1;
  } 

  constructor( private NavService: NavService,public RodmanCoreService:RodmanCoreService) { 
  }

  ngOnInit() {   
    // Header Main And Submenu api Call 
    this.NavService.getHeaderMenu(this.magazineId,this.menuId).subscribe((data)=>{
      this.articles = data['data'];
    });  
    // this.currentIssue();
  }

  currentIssue(){
    this.NavService.currentIssue(this.magazineId).subscribe((data)=>{
       this.issueUrl = data.issueUrl;
    });   
  } 

  validateUrl(str)
  {
      var httpCheck = str;
      if (httpCheck.indexOf("http://") == 0 || httpCheck.indexOf("https://") == 0) {
          return true;
      }
      return false;
  }

  safeHtmlReplace(data){
    return this.RodmanCoreService.safeHtmlReplace(data);
  }

}
