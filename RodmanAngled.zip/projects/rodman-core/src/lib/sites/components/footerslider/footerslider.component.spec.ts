import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FootersliderComponent } from './footerslider.component';

describe('FootersliderComponent', () => {
  let component: FootersliderComponent;
  let fixture: ComponentFixture<FootersliderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FootersliderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FootersliderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
