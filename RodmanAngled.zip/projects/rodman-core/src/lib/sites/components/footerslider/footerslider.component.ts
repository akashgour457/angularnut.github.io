import { Component, OnInit } from '@angular/core';
import {NgbModule,NgbCarouselConfig , NgbCarousel, NgbSlideEvent, NgbSlideEventSource } from '@ng-bootstrap/ng-bootstrap';
import { FootersliderService } from './footerslider.service';


@Component({
  inputs: ['magazineId'],
  selector: 'CoreLib-footerslider',
  templateUrl: './footerslider.component.html',
  styleUrls: ['./footerslider.component.css'],
  providers: [NgbModule,NgbCarouselConfig],
})
export class FootersliderComponent implements OnInit {
  magazineId;
  sliderData;
  showNavigationArrows = false;
  showNavigationIndicators = false;
  constructor(private FootersliderService: FootersliderService,config: NgbCarouselConfig) { 
    config.interval = 2000;
    config.showNavigationArrows = false;
    config.showNavigationIndicators = false;
  }

  ngOnInit() {
    // Footer Slider Api Call 
    this.FootersliderService.getFooterData(this.magazineId).subscribe((data)=>{
      this.sliderData = data['data'];
    }); 
  }

}
