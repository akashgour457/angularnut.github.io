import { Component, OnInit } from '@angular/core';
import {Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import * as configVar from '../../../rodman-core.service';
import { RodmanCoreService } from '../../../rodman-core.service';

@Component({
  selector: 'CoreLib-footer',
  inputs: ['magazineId'],
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {
  currentYear:number;
  magazineId;
  footerData;
  arrBirds: string [];
  footerSocialLink = [     
                      {'15':{                      
                              'facebook':  'https://www.facebook.com/pages/Printed-Electronics-Now/135384279809061',
                              'linkedin' : 'http://www.linkedin.com/groups/Printed-Electronics-Now-2079630/about',
                              'rss'     : '/rssfeeds/',
                              // 'google'  : '/contents/list_blog/'
                             } 
                       },
                       {'14':{'facebook': 'http://www.facebook.com/pages/Orthopedic-Design-Technology/132780940069550',   
                              'linkedin': 'http://www.linkedin.com/groups?about=&amp;gid=2079574&amp;trk=anet_ug_grppro',
                              'twitter' : 'https://twitter.com/odtmagazine',
                    
                             }
                       },  
                       {'13':{'facebook': 'http://www.facebook.com/pages/Nonwovens-Industry-Magazine/129247883774669',   
                              'linkedin': 'http://www.linkedin.com/groups?about=&amp;gid=1775410&amp;trk=anet_ug_grppro',
                              'twitter' : 'http://twitter.com/NonwovensMag',
                              'rss'     : '/rssfeeds/'             
                              },
                       },  
                       {'11':{'facebook': 'http://www.facebook.com/pages/Label-And-Narrow-Web/124971914208037',
                              'linkedin' : 'http://www.linkedin.com/groups?gid=2079407&amp;about=',
                              'twitter' : 'http://www.twitter.com/labelandnarrow',
                              'pinterest':'https://www.pinterest.com/lnwmagazine/',
                              'rss'      :'/rssfeeds/'
                            } 
                       },
                       {'10':{'facebook': 'https://www.facebook.com/pages/Ink-World/101479703238099',
                              'linkedin' : 'http://www.linkedin.com/groups?gid=2079359',
                              'twitter' : 'http://twitter.com/inkworldmag',
                              'rss'     : '/rssfeeds/',
                              'google'  : 'https://plus.google.com/+Inkworldmagazine1/posts',
                              'instagram':'https://www.instagram.com/inkworldmag/'
                            } 
                       },
                       {'9':{ 'facebook':'https://www.facebook.com/HappiMagazine/',
                              'linkedin':'https://www.linkedin.com/groups/2079173/profile',
                              'twitter' :'https://twitter.com/happimagazine',
                              'instagram':'https://www.instagram.com/happimagazine/',
                              'pinterest':'https://www.pinterest.com/happimagazine/',
                              'rss'      :'/rssfeeds/'
                            } 
                       },                       
                       {'8':{ 'facebook':'https://www.facebook.com/pages/Beauty-Packaging/124945340875475',
                              'linkedin':'https://www.linkedin.com/groups?about=&amp;gid=1775357',
                              'twitter' :'https://twitter.com/beautypackaging',
                              'pinterest':'https://www.pinterest.com/beautypackaging/',
                              'rss'      :'/rssfeeds/'
                            } 
                       }, 
                       {'7':{ 'facebook':'http://www.facebook.com/contractpharma',
                              'linkedin':'http://www.linkedin.com/groups?about=&amp;gid=1775433&amp;trk=anet_ug_grppro',
                              'twitter' :'http://twitter.com/contractpharma',
                              'rss'     :'/rssfeeds/'
                            } 
                       },                        
                       {'6':{ 'facebook':'https://www.facebook.com/pages/Medical-Product-Outsourcing/105425076171700',
                              'linkedin':'http://www.linkedin.com/groups?gid=2079433&amp;trk=myg_ugrp_ovr',
                              'twitter':'https://twitter.com/mpomagazine',
                              'rss'    :'/rssfeeds/'
                            } 
                       },   
                       {'5':{ 'facebook':'http://www.facebook.com/pages/Coatings-World/111797362200467',
                              'linkedin':'http://www.linkedin.com/groups?gid=2079298&amp;about=e',
                              'twitter' :'http://www.twitter.com/coatingsworld',
                              'rss'     :'/rssfeeds/'
                            } 
                       },        
                       {'1':{'facebook':'https://www.facebook.com/pages/Nutraceuticals-World/135318976481526',
                             'linkedin':'https://www.linkedin.com/groups/Nutraceuticals-World-2079225/about',
                             'twitter' :'https://twitter.com/nutworld',
                             'instagram':'https://instagram.com/nutraceuticalsworld/',
                             'pinterest':'https://www.pinterest.com/nutraworld/',
                             'rss'      :'/rssfeeds/'
                            } 
                       },                                         
                    ];
  Url;
  constructor( public Router:Router,private httpService: HttpClient,public RodmanCoreService:RodmanCoreService) { 
    this.Url = configVar.apiURL;
  }
  
  ngOnInit() {
    this.currentYear = new Date().getFullYear();  
  }
}
