import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { throwError, from } from 'rxjs';
import { catchError } from 'rxjs/operators';
import * as configVar from '../../rodman-core.service';
import { RodmanCoreService } from '../../rodman-core.service';

@Injectable({
  providedIn: 'root'
})
export class DirectoryHomePageService {

  constructor(private HttpClient: HttpClient,private RodmanCoreService:RodmanCoreService ) { }

  buyerGuideCompany(magazineId,slug) {
     return this.HttpClient.post<any>(configVar.apiURL+'taxonomysController/buyersguideSearchDirectory',{magazineId:magazineId,slug:slug}, configVar.httpOptions).pipe(
       catchError(this.RodmanCoreService.handleError)
     );
  }
  buyersguideCategory(magazineId,slug){
    return this.HttpClient.post<any>(configVar.apiURL+'taxonomysController/buyersguideCategory',{magazineId:magazineId,slug:slug}, configVar.httpOptions).pipe(
      catchError(this.RodmanCoreService.handleError)
    );
  }
  buyersguideCountry(magazineId,slug){
    return this.HttpClient.post<any>(configVar.apiURL+'taxonomysController/buyersguideCountry',{magazineId:magazineId,slug:slug}, configVar.httpOptions).pipe(
      catchError(this.RodmanCoreService.handleError)
    );
  }

}
