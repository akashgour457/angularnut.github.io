import { Component, OnInit } from '@angular/core';
import { DirectoryHomePageService } from './directory-home-page.service';
import { RodmanCoreService } from '../../rodman-core.service';
import { Router, RouterModule,ActivatedRoute,NavigationEnd } from '@angular/router';

@Component({
  selector: 'CoreLib-directory-home-page',
  templateUrl: './directory-home-page.component.html',
  styleUrls: ['./directory-home-page.component.css']
})
export class DirectoryHomePageComponent implements OnInit {
  viewAdRender:number;
  getAllAd:any=[];
  alphabet=[];
  magazineId;
  data;
  loading=true;
  current_letter='';
  currentURL;
  buyersGuideCategoryData;
  buyersguideCountryData;  
  titleCheck:any;

  companiesTitleArray={
      '1':{ '0':'Featured Supplier Showcase Companies'   ,'1':'Supplier Showcase Companies',   '2':'Featured Companies'},
      '5':{ '0':'Featured Company Capabilities Microsite','1':'Company Capabilities Microsite','2':'Featured Companies'},
      '6':{ '0':'Featured Company Profiles Microsite'    ,'1':'Company Profiles Microsite',    '2':'Featured Companies'},
      '7':{ '0':'Featured Microsite Companies'           ,'1':'Microsite Companies',           '2':'Featured Companies'},
      '8':{ '0':'Featured Company Profiles Microsite'    ,'1':'Company Profiles Microsite',    '2':'Featured Companies'},
      '9':{ '0':'Featured Corporate Profile Microsite'   ,'1':'Corporate Profile Microsite',   '2':'Featured Companies'},
      '10':{ '0':'Featured Technical Profile Microsite'  ,'1':'Technical Profile Microsite',   '2':'Featured Companies'},
      '11':{ '0':'Featured Microsite Companies'          ,'1':'Microsite Companies',           '2':'Featured Companies'},
      '12':{ '0':'Featured Microsite Companies'          ,'1':'Microsite Companies',           '2':'Featured Companies'},
      '13':{ '0':'Company Profile MicrositePLUS'         ,'1':'Company Profile Microsite',     '2':'Featured Companies'},
      '14':{ '0':'Featured Microsite Companies'          ,'1':'Microsite Companies',           '2':'Featured Companies'},
      '15':{ '0':'Featured Technical Profile Microsite'  ,'1':'Technical Profile Microsite',   '2':'Featured Companies'},
  };

  featuredmicrositeCompanies = [];
  micrositeCompanies = [] ;
  featuredBgCompanies = [];


  constructor(public ActivatedRoute:ActivatedRoute, public DirectoryHomePageService:DirectoryHomePageService,public RodmanCoreService:RodmanCoreService,public Router:Router) { 
    Router.events.subscribe(event => {
      if (event instanceof NavigationEnd ) {
        this.currentURL = event.url; 
      }
    });
  }

  ngOnInit() {
    this.ActivatedRoute.data.subscribe(data => {
      this.magazineId=data.magazineId;
    });
    this.getPageAd();
    this.buyersguideCategory();
    this.buyerGuideCompany();
    this.buyersguideCountry();
    
  }
  
  getPageAd(){
    this.RodmanCoreService.getAllAdst(this.magazineId).subscribe((data =>{
      this.getAllAd = data;
      this.viewAdRender = 1;
    }))
  }

  buyerGuideCompany(){    
    this.DirectoryHomePageService.buyerGuideCompany(this.magazineId,this.currentURL).subscribe((data)=>{
      this.data = data['data'];
      for(let compnayCheck of this.data){
        if((compnayCheck.has_microsite_listing == 1 ) && (compnayCheck.has_priority_listing == 1) && (compnayCheck.has_featured_mircosite_listing == 1) ){
            this.featuredmicrositeCompanies.push(compnayCheck);                   
        }else if((compnayCheck.has_microsite_listing == 1 ) && (compnayCheck.has_priority_listing == 1) && (compnayCheck.has_featured_mircosite_listing == 0) ){
            this.micrositeCompanies.push(compnayCheck); 
        }else if((compnayCheck.has_microsite_listing == 0 ) && (compnayCheck.has_priority_listing == 1) && (compnayCheck.has_featured_mircosite_listing == 0) ){
          this.featuredBgCompanies.push(compnayCheck); 
          // let checkCompanyTitle = compnayCheck.content_type_id;
          // if(checkCompanyTitle != this.titleCheck ){}
        }      
        if(compnayCheck.title.charAt(0).toUpperCase() != this.current_letter){
          this.current_letter = compnayCheck.title.charAt(0).toUpperCase();
          this.alphabet.push(compnayCheck.title.charAt(0).toUpperCase());
        }       
      }      
      this.loading=false;
    }); 
  }

  buyersguideCategory(){
    this.DirectoryHomePageService.buyersguideCategory(this.magazineId,this.currentURL).subscribe((data)=>{
      this.buyersGuideCategoryData = data['data'];
    });
  }

  buyersguideCountry(){
    this.DirectoryHomePageService.buyersguideCountry(this.magazineId,this.currentURL).subscribe((data)=>{
      this.buyersguideCountryData = data['country'];
    });
  }

  matchCharacter(current,pre){
    if(current.charAt(0).toUpperCase() != pre){
      this.current_letter = current.charAt(0);
      return true;
    }
    return false;
  }

  safeHtml(data){
    // return data.replace(/[^a-zA-Z0-9.()'"$@&!?:, ]/g, "")
    return this.RodmanCoreService.safeHtmlReplace(data);

  }

}
