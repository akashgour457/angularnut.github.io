import { Component, OnInit ,Input } from '@angular/core';
import { RodmanCoreService } from '../../rodman-core.service';

@Component({
  selector: 'CoreLib-directory-search-box',
  templateUrl: './directory-search-box.component.html',
  styleUrls: ['./directory-search-box.component.css']
})
export class DirectorySearchBoxComponent implements OnInit {
  @Input() title:any; 
  @Input() magazineId:any; 
  @Input() data:any;
  @Input() boxNo:any;

  constructor(public RodmanCoreService: RodmanCoreService) { }

  ngOnInit() {
  }

  safeHtml(data){
    // return data.replace(/[^a-zA-Z0-9.()'"$@&!?:, ]/g, "")
    return this.RodmanCoreService.safeHtmlReplace(data);

  }

}
