import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DirectorySectionRoutingModule } from './directory-section-routing.module';
import { DirectoryHomePageComponent } from './directory-home-page/directory-home-page.component';
import { AdsModule } from '../ads/ads.module';
import { ContentsModule } from '../contents/contents.module';
import { DirectorySearchBoxComponent } from './directory-search-box/directory-search-box.component';
import { DirectoryBasicCompanyListingComponent } from './directory-basic-company-listing/directory-basic-company-listing.component';


@NgModule({
  declarations: [DirectoryHomePageComponent, DirectorySearchBoxComponent, DirectoryBasicCompanyListingComponent],
  imports: [
    CommonModule,
    AdsModule,
    ContentsModule,
    DirectorySectionRoutingModule
  ],
  exports:[DirectoryHomePageComponent,DirectorySearchBoxComponent]
})
export class DirectorySectionModule { }
