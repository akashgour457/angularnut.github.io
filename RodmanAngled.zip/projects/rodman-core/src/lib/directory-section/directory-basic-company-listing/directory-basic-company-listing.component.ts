import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'CoreLib-directory-basic-company-listing',
  templateUrl: './directory-basic-company-listing.component.html',
  styleUrls: ['./directory-basic-company-listing.component.css']
})
export class DirectoryBasicCompanyListingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
