import { Component, OnInit, ViewChild,AfterViewInit,ElementRef,Input } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { BsModalService, BsModalRef ,ModalDirective} from 'ngx-bootstrap/modal';  
import { DomSanitizer, SafeResourceUrl, SafeUrl} from '@angular/platform-browser';
import { CookieService } from 'ngx-cookie-service';



@Component({
  selector: 'CoreLib-ads-overlay',
  templateUrl: './ads-overlay.component.html',
  styleUrls: ['./ads-overlay.component.css']
})
export class AdsOverlayComponent implements OnInit {
  bsModal: BsModalRef;
  isModalShown = false;
  @Input() ads:any;
  @Input() location:any;
  @Input() magazineName:any;
  
  magazine =  { 
                'NUT':{ id:'1'  ,name:'Nutraceuticals world'} , 
                'CW' :{ id:'5'  ,name:'Coating World'},
                'MPO':{ id:'6'  ,name:'Medical Product Outsourcing'},
                'CP' :{ id:'7'  ,name:'Contract Pharma'}, 
                'BP' :{ id:'8'  ,name:'Beauty Packaging'},
                'HAP':{ id:'9'  ,name:'Happi'},
                'INK':{ id:'10' ,name:'Ink World'},
                'LNW':{ id:'11' ,name:'Label & Narrow Web'},
                'NON':{ id:'13' ,name:'Nonwovens Industry'},                
                'ODT':{ id:'14' ,name:'Orthopedic Design & Technology'}, 
                'PEN':{ id:'15' ,name:'Printed Electronics Now'},               
              };

  @ViewChild('autoShownModal', { static: false }) public autoShownModal: ModalDirective;

  constructor(public BsModalService:BsModalService,public sanitizer: DomSanitizer,public CookieService:CookieService) { }

  ngOnInit() {
    this.isModalShown = true;
    setTimeout(function(){
    },15000);
  }


  showModal(): void {
    this.isModalShown = true;
  }
 
  hideModal(): void {
    this.autoShownModal.hide();
  }
 
  onHidden(): void {
    this.isModalShown = false;
  }


}
