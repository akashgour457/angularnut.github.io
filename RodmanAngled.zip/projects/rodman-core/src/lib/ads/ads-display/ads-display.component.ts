import { Input,Component, OnInit, ViewChild, ElementRef, EventEmitter, Output } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { Event,NavigationEnd,Router} from '@angular/router';    
import { RodmanCoreService } from '../../rodman-core.service';
import { Ng2DeviceService } from 'ng2-device-detector';




@Component({
  selector: 'CoreLib-ads-display',
  templateUrl: './ads-display.component.html',
  styleUrls: ['./ads-display.component.css']
})
export class AdsDisplayComponent implements OnInit {
  @Input() ads: any;
  @Input() location: any='HOME';
  @Input() footerData:any;
  deviceInfo = null;
  // @Input() magazineId: any;
  collectoionAds:any=[];
  dataArray:any;
  sizeVariable:any;
  isOverlayCookie;
  overlayShow = true;
  overlayAdsData:any;
  footerAds:any;
  Url;
  footerCookieCheck:any;
  showFooterAds:boolean = false;
  // arrayCheck:number;
  // slots;
  finalSlots;
  constructor(public CookieService:CookieService , public RodmanCoreService:RodmanCoreService,private deviceService: Ng2DeviceService) { 
    this.screenDetect();
  }

  ngOnInit() {
    this.dataArray  =  this.getAdsFilter(this.ads);
   
  }

  getAdsFilter(data){ 
    for(let filterData of data['data']){    
      // if(filterData.type == 'doubleclick'){ 
        this.isOverlayCookie = this.CookieService.get('overlay_'+filterData.id);
        if(this.isOverlayCookie){    
            this.overlayShow = false;
        }else if( (!(this.isOverlayCookie)) && (filterData.type=='overlay') ){
            const dateNow = new Date();
            dateNow.setMinutes(dateNow.getMinutes() + 30);
            this.CookieService.set('overlay_'+filterData.id, 'Overlay' ,dateNow,'/',"");
        }

        this.collectoionAds[filterData.location.replace('-',"_").replace('-',"_")] = 
                                                                                      {
                                                                                        id:filterData.id,
                                                                                        code:this.getAdcode(filterData.code),
                                                                                        type:filterData.type,
                                                                                        ad_type:filterData.location.replace('-',"_").replace('-',"_").replace('-',"_")
                                                                                      };
        if(filterData.type=='overlay'){
          this.overlayAdsData = {
                                  id:filterData.id,
                                  code:this.getAdcode(filterData.code),
                                  type:filterData.type,
                                  ad_type:filterData.location.replace('-',"_").replace('-',"_").replace('-',"_")
                                };
        }
        
        if((filterData.type=='doubleclick') && ('footer_1'==filterData.location.replace('-',"_").replace('-',"_").replace('-',"_")) ){
          this.footerAds = {
                              id:filterData.id,
                              code:this.getAdcode(filterData.code),
                              type:filterData.type,
                              ad_type:filterData.location.replace('-',"_").replace('-',"_").replace('-',"_")
                            };
        }   
      // }        
    }
    // this.finalSlots =  this.arrayConvet(this.collectoionAds[this.location].code.sizes);   
    // this.arrayCheck=1;
    // this.collectoionAds[this.location].code.value = ((this.collectoionAds[this.location].code.value=='') && (this.collectoionAds[this.location].code.value=='ome')) ? 'HOME' : this.collectoionAds[this.location].code.value ;
    return  this.collectoionAds[this.location];
  }


  arrayConvet(data){
    var sizes = data.split(']');
      var finalsize = [];
      for(let size in sizes){
          if(sizes[size].indexOf('[') >= 0){
              var singleSize = sizes[size].substring(sizes[size].indexOf('[') + 1).split(',');
              finalsize.push({width:(singleSize[0].replace(/\s/g, "")).toString(),height:(singleSize[1].replace(/\s/g, "")).toString()})
          }
      }
    return finalsize;
  }

  getAdcode(str){
    str = str.replace(/\'/g,'');
    str = str.replace(/\\/g,'');
    var firstIndex = str.indexOf("script") + 10;
    var lastIndex = str.indexOf("/script>");
    str = str.substring(firstIndex,lastIndex);
    if(str.indexOf('defineSlot') < 0)
        return false;
    var slot = str.substring(str.indexOf("defineSlot(")+11,  str.indexOf(").addService"));
    var slotvalue = slot.split(',')[0]
    var code = {
        slot: slotvalue,
        // sizes: str.substring( str.lastIndexOf("[[")+1,  str.lastIndexOf("]]")+1 ),
        key: str.substring( str.lastIndexOf('setTargeting("')+14,  str.lastIndexOf('",') ),
        value : str.substring( str.lastIndexOf('",[')+4,  str.lastIndexOf('])') )
    }
    return code
  }

  screenDetect() {
    this.deviceInfo = this.deviceService.getDeviceInfo();
    // console.log(this.deviceInfo);
  }

}
