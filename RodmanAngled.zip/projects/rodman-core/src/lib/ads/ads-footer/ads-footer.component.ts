import { Component, OnInit , Input } from '@angular/core';
import { RodmanCoreService } from '../../rodman-core.service';
import { Event,NavigationEnd,Router,ActivatedRoute} from '@angular/router';    
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'CoreLib-ads-footer',
  templateUrl: './ads-footer.component.html',
  styleUrls: ['./ads-footer.component.css']
})
export class AdsFooterComponent implements OnInit {
  @Input() ads:any;
  @Input() magazineName:any;
  Url;
  footerCookieCheck:any;
  showAds:boolean = false;

  constructor(public RodmanCoreService:RodmanCoreService,public Router:Router,public CookieService:CookieService) {

  }

  ngOnInit() {
  }

}
