import { Component, OnInit ,Input } from '@angular/core';
import { RodmanCoreService } from '../../rodman-core.service';
import * as configVar from '../../rodman-core.service';
import { Event,NavigationEnd,Router} from '@angular/router';    

@Component({
  selector: 'CoreLib-ads-double-click',
  templateUrl: './ads-double-click.component.html',
  styleUrls: ['./ads-double-click.component.css']
})
export class AdsDoubleClickComponent implements OnInit {
  @Input() magazineId:any; 
  @Input() location:any; 
  @Input() no:any; 
  @Input() screenSize:any;   // Optinal 
  device ='website';
  currentURL;
  loading = false;
  // target;
  target='HOME';
  name;

  constructor(public RodmanCoreService:RodmanCoreService,public Router:Router) {
    Router.events.subscribe(event => {
      if (event instanceof NavigationEnd ) {
        this.currentURL = event.url; 
      }
    });

   }

  ngOnInit() {
    this.name = configVar.magazineIds[this.magazineId].id
    // this.target = this.currentURL.toString().split('/').join(',');
    if(this.currentURL != ''){
      this.target = this.location.toString().split('/').join(',');
    }
    
    this.loading = true;


  }

}
