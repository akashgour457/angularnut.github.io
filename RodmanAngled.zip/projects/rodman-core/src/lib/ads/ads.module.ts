import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdsRoutingModule } from './ads-routing.module';
import { AdsDisplayComponent } from './ads-display/ads-display.component';
import { Ng2DeviceDetectorModule } from 'ng2-device-detector';
import { DfpModule } from 'ngx-dfp';
import { AdsOverlayComponent } from './ads-overlay/ads-overlay.component';
import { ModalModule } from 'ngx-bootstrap/modal';
import {RodmanORMModule} from 'rodman-orm';
import { CookieService } from 'ngx-cookie-service';
import { AdsFooterComponent } from './ads-footer/ads-footer.component';
import { AdsDoubleClickComponent } from './ads-double-click/ads-double-click.component';
import { AdsHomeWidgetComponent } from './ads-home-widget/ads-home-widget.component';





@NgModule({
  declarations: [  AdsDisplayComponent, AdsOverlayComponent, AdsFooterComponent, AdsDoubleClickComponent, AdsHomeWidgetComponent],
  imports: [
    CommonModule,
    ModalModule,
    RodmanORMModule,
    AdsRoutingModule,
    Ng2DeviceDetectorModule.forRoot(),
    DfpModule.forRoot({
      idleLoad: true,
      enableVideoAds: true,
      personalizedAds: true, // Request personalized ads by default
      singleRequestMode: true, // Only applies to initial refresh
      onSameNavigation: 'refresh',
      globalTargeting: {
        // food: ['NUT', 'HOME']
      }
    })  ,
  ],
  providers:[CookieService] , 
  exports:[  AdsDisplayComponent,AdsOverlayComponent,AdsFooterComponent,AdsDoubleClickComponent,AdsHomeWidgetComponent]
})
export class AdsModule { }
