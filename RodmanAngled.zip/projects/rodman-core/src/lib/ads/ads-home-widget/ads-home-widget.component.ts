import { Component, OnInit ,Input } from '@angular/core';
import { RodmanCoreService } from '../../rodman-core.service';
import * as configVar from '../../rodman-core.service';
import { Event,NavigationEnd,Router} from '@angular/router';    


@Component({
  selector: 'CoreLib-ads-home-widget',
  templateUrl: './ads-home-widget.component.html',
  styleUrls: ['./ads-home-widget.component.css']
})
export class AdsHomeWidgetComponent implements OnInit {
  @Input() magazineId:any; 
  @Input() location:any; 
  @Input() no:any; 
  device ='website';
  @Input() target:any;
  currentURL;
  loading = false;
  name;

  constructor(public RodmanCoreService:RodmanCoreService,public Router:Router) {
    Router.events.subscribe(event => {
      if (event instanceof NavigationEnd ) {
        this.currentURL = event.url; 
      }
    });

   }

  ngOnInit() {
    this.name = configVar.magazineIds[this.magazineId].id
    // this.target = this.currentURL.toString().split('/').join(',');
    if(this.currentURL != ''){
      // this.target = this.location.toString().split('/').join(',');
    }    
    this.loading = true;
  }

}
