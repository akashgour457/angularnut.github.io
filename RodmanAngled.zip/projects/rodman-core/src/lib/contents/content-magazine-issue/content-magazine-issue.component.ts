import { Component, OnInit,Input } from '@angular/core';
import {NgbModule,NgbCarouselConfig , NgbCarousel, NgbSlideEvent, NgbSlideEventSource } from '@ng-bootstrap/ng-bootstrap';
import { ContentIssueService } from '../content-issue/content-issue.service';
import { Router, RouterModule ,ActivatedRoute , Event,NavigationEnd,NavigationStart} from '@angular/router';
import { RodmanCoreService } from '../../rodman-core.service';
import * as configVar from '../../rodman-core.service';

@Component({
  selector: 'CoreLib-content-magazine-issue',
  templateUrl: './content-magazine-issue.component.html',
  styleUrls: ['./content-magazine-issue.component.css'],
  providers: [NgbModule,NgbCarouselConfig],

})
export class ContentMagazineIssueComponent implements OnInit {
  @Input() url:any;
  @Input() magazineId:any;

  slug;
  issueData:any=[];
  sliderData:any=[];
  loading=true;
  currentURL;
  lastSlug;
  name;
  nextIssue;
  page =0;
  ptintTittle =false;  
  routeChange:boolean=true;   
  getAllAd:any=[];
  viewAdRender:number;

  constructor(public RodmanCoreService:RodmanCoreService, public ActivatedRoute:ActivatedRoute, public Router:Router,public ContentIssueService:ContentIssueService){ }

  ngOnInit(){
  }

  ngOnChanges(){      
    this.name = configVar.magazineIds[this.magazineId].name; 
    this.issueData=[];
    this.sliderData=[];
    this.getAllAd=[];
    this.viewAdRender=0;
    this.getIssue(this.url);
    this.getads();
  }

  getIssue(url){
    this.loading=true;
    this.ContentIssueService.getIssue(this.magazineId,url).subscribe((data)=>{
      let collectData = data['data'];
      // if(this.page==0)  {
        this.sliderData = data['issue'];
        this.page = 1;
      // }      

      this.nextIssue = data['nextIssue'];
      for(let data of collectData){
        this.issueData.push(data);
      }
      this.loading=false;
    });
  }

  getads(){
    this.RodmanCoreService.getAllAdst(this.magazineId).subscribe((data =>{
      this.getAllAd = data;
      this.viewAdRender = 1;
    }))
  }

  loadMoreData(slug){
    this.loading=true;
    this.issueData.push({'id':"",'primary_image':"",'title':"",'summary':"",'publish_date':"",'viewUrl':"",'issue_title':"",'nextTag':this.nextIssue.issue_title});
    this.getIssue(slug);
  }

  safeHtml(data){
    return this.RodmanCoreService.safeHtmlReplace(data);
  }

  titlePrint(title){
    return (title == 1) ?  true  : false ;
  }


}
