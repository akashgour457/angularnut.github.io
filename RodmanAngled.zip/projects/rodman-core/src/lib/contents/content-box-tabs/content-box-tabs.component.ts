import { Component, OnInit,Input } from '@angular/core';
import { ContentBoxTabsService } from './content-box-tabs.service';
import { Event,NavigationEnd,Router} from '@angular/router';  
import { RodmanCoreService } from '../../rodman-core.service'; 

@Component({
  selector: 'CoreLib-content-box-tabs',
  inputs: ['magazineId','TabOne','TabTwo'],
  templateUrl: './content-box-tabs.component.html',
  styleUrls: ['./content-box-tabs.component.css']
})
export class ContentBoxTabsComponent implements OnInit {
  @Input() showAds:any;
  magazineId;
  currentJustify = 'justified';
  contentBoxTabOne;tabOneHeading;
  contentBoxTabTwo;tabTwoheading;
  TabOne;
  TabTwo;
  loading=true;
  currentURL;
  constructor(private ContentBoxTabsService: ContentBoxTabsService,public Router:Router,public RodmanCoreService:RodmanCoreService) { 
    Router.events.subscribe(event => {
      if (event instanceof NavigationEnd ) {
        this.currentURL = event.url; 
      }
    });
  }

  ngOnInit() {
    this.ContentBoxTabsService.getTopRightWidget(this.magazineId,this.TabOne).subscribe((data)=>{
      this.contentBoxTabOne = data['data'];
      this.tabOneHeading = data['contentType'];
    }); 

    this.ContentBoxTabsService.getTopRightWidget(this.magazineId,this.TabTwo).subscribe((data)=>{
      this.contentBoxTabTwo = data['data'];
      this.tabTwoheading = data['contentType'];
      this.loading=false;

    });
  }

  extractNameFromJson(data){
    return this.RodmanCoreService.extractNameFromJson(data);
  }

  safeHtmlReplace(data){
    return this.RodmanCoreService.safeHtmlReplace(data);
  }


}