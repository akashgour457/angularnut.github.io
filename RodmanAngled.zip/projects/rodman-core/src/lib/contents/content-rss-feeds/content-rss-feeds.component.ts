import { Component, OnInit } from '@angular/core';
import { RodmanCoreService } from '../../rodman-core.service';
import { Router, RouterModule ,ActivatedRoute } from '@angular/router';
import { ContentRssFeedsService } from './content-rss-feeds.service';
import * as configVar from '../../rodman-core.service';


@Component({
  selector: 'CoreLib-content-rss-feeds',
  templateUrl: './content-rss-feeds.component.html',
  styleUrls: ['./content-rss-feeds.component.css']
})
export class ContentRssFeedsComponent implements OnInit {
  loading = true;
  magazineId;
  getAllAd:any=[];
  viewAdRender:number;
  rssData:any;
  baseUrl;

  constructor(public ActivatedRoute:ActivatedRoute, public Router:Router,public RodmanCoreService:RodmanCoreService,public ContentRssFeedsService:ContentRssFeedsService ) { 
    this.baseUrl = configVar.apiURL;
  }

  ngOnInit() {
    this.ActivatedRoute.data.subscribe(data => {
      this.magazineId=data.magazineId;
    })

    this.rssDataMethod();

    this.RodmanCoreService.getAllAdst(this.magazineId).subscribe((data =>{
      this.getAllAd = data;
      this.viewAdRender= 1;
    }))  


  }

  rssDataMethod(){
    this.ContentRssFeedsService.rssFeeds(this.magazineId).subscribe((data)=>{
      this.rssData = data['country'];     
      this.loading =false;
    }); 
  }
  

}
