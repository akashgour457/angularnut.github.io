import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { throwError, from } from 'rxjs';
import { catchError } from 'rxjs/operators';
import * as configVar from '../../rodman-core.service';
import { RodmanCoreService } from '../../rodman-core.service';

@Injectable({
  providedIn: 'root'
})
export class ContentRssFeedsService {

  constructor(private HttpClient: HttpClient,private RodmanCoreService:RodmanCoreService ) { }

  rssFeeds(magazineId) {
     return this.HttpClient.post<any>(configVar.apiURL+'contentsController/getContentType',{magazineId:magazineId}, configVar.httpOptions).pipe(
       catchError(this.RodmanCoreService.handleError)
     );
   }
}
