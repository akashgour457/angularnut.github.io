import { Component, OnInit,Input } from '@angular/core';
import { ContentRelatedService } from './content-related.service';
import { RodmanCoreService } from '../../rodman-core.service';

@Component({
  selector: 'CoreLib-content-related',
  inputs:['magazineId','contentId'],
  templateUrl: './content-related.component.html',
  styleUrls: ['./content-related.component.css']
})
export class ContentRelatedComponent implements OnInit {
  magazineId;contentId;
  @Input() heading:any;
  relatedContentData;
  constructor(public ContentRelatedService:ContentRelatedService,public RodmanCoreService:RodmanCoreService ) { }

  ngOnInit() {
    this.ContentRelatedService.getRelatedContent(this.magazineId,this.contentId).subscribe((data)=>{
      this.relatedContentData = data['data'];
      this.relatedContentData = this.relatedContentData.slice(0, 5)
    });
  }

  safeHtmlReplace(data){
    return this.RodmanCoreService.safeHtmlReplace(data);
  }
  

}
