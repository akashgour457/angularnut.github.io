import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { throwError, from } from 'rxjs';
import { catchError } from 'rxjs/operators';
import * as configVar from '../../rodman-core.service';
import { RodmanCoreService } from '../../rodman-core.service';


@Injectable({
  providedIn: 'root'
})
export class ContentRelatedService {
  constructor(private HttpClient: HttpClient,private RodmanCoreService:RodmanCoreService ) { }

    getRelatedContent(magazineId,contentId) {
     return this.HttpClient.post<any>(configVar.apiURL+'taxonomysController/getReleatedContent',{magazineId:magazineId,contentId:contentId}, configVar.httpOptions).pipe(
       catchError(this.RodmanCoreService.handleError)
     );
   }

}   