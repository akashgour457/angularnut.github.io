import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { throwError, from } from 'rxjs';
import { catchError } from 'rxjs/operators';
import * as configVar from '../../rodman-core.service';
import { RodmanCoreService } from '../../rodman-core.service';

@Injectable({
  providedIn: 'root'
})
export class ListContentService {

  constructor(private HttpClient: HttpClient,private RodmanCoreService:RodmanCoreService ) { }

  getContent(slug,magazineId,limit,page,contentType) {
     return this.HttpClient.post<any>(configVar.apiURL+'taxonomysController/getContentTypeContent',{pageUrl:slug,magazineId:magazineId,limit:limit,page:page,contentType:contentType}, configVar.httpOptions).pipe(
       catchError(this.RodmanCoreService.handleError)
     );
   }

  getContentTopTaxonomy(slug,magazineId) {
    return this.HttpClient.post<any>(configVar.apiURL+'taxonomysController/getContentTypeTopTaxonomy',{pageUrl:slug,magazineId:magazineId}, configVar.httpOptions).pipe(
      catchError(this.RodmanCoreService.handleError)
    );
   }
 }
