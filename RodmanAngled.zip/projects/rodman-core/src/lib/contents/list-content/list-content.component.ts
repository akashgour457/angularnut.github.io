import { Component, OnInit } from '@angular/core';
import { ListContentService } from '../list-content/list-content.service';
import { RodmanCoreService } from '../../rodman-core.service';
import { NavigationEnd,Router} from '@angular/router';   
import * as configVar from '../../rodman-core.service';

@Component({
  selector: 'CoreLib-lists-contents',
  inputs: ['routeUrl','magazineId','contentType'] ,
  templateUrl: './list-content.component.html',
  styleUrls: ['./list-content.component.css']
})
export class ListContentComponent implements OnInit {
  routeUrl;
  magazineId;
  listContentData=[]; 
  contentData:any;
  slugHeading;
  limit=10;
  page=0;
  contentType='';
  contentTaxonomy;
  taxonomyUrl;
  taxonomyUrlTo;
  loading= true;
  staticUrl='/';
  sliderData=[];
  counterAd=1;
  currentURL;
  all:any=[]; 
  constructor(public Router:Router,private ListContentService: ListContentService,public RodmanCoreService:RodmanCoreService ) { 
    Router.events.subscribe(event => {
      if (event instanceof NavigationEnd ) {
        this.currentURL = event.url; 
      }
    });
  }
  ngOnInit() {
    // this.getContentData();
  }

  ngOnChanges(){  

    if((this.magazineId ==1) || (this.magazineId ==5)  ){
      this.staticUrl = '/knowledge-center/'; 
    }
    if((this.magazineId ==9)){
      console.log(this.magazineId);
      this.staticUrl = '/knowledge-base/'; 
    }
    console.log(this.staticUrl);
    this.loading= true;
    this.page=0;
    this.slugHeading;
    this.all=[];
    this.sliderData=[];
    this.listContentData=[];
    this.contentTaxonomy=[];
    this.getContentData();
  }
  
  safeHtml(data){
    return this.RodmanCoreService.safeHtmlReplace(data);
  }  

  getImage(imageId){
     return this.RodmanCoreService.displayImageUrl(imageId);
  }
  
  getContentData(){ 
    
    this.taxonomyUrl = this.routeUrl.split('/');  
    this.taxonomyUrl = (this.taxonomyUrl[this.taxonomyUrl.length-1]);
    let url =this.taxonomyUrl.split('_');  
    this.taxonomyUrlTo = url[1];


    if(this.page==0){ 
      this.ListContentService.getContentTopTaxonomy(this.routeUrl,this.magazineId).subscribe((data)=>{
        // this.slugHeading = data['contentTypeName'];
        this.contentTaxonomy = data['CONTENT_TAXONOMYS'];
        this.all = data['all'];    
      });        
    } 
    this.ListContentService.getContent(this.routeUrl,this.magazineId,this.limit,this.page,this.contentType).subscribe((data)=>{
      this.contentData = data['data'];
      if(this.page==0){ 
        this.slugHeading = data['contentTypeName'];
        // this.contentTaxonomy = data['CONTENT_TAXONOMYS'];
        this.sliderData.push(this.contentData);  
      } 
      this.page = data['page']+1;
      for(let content of this.contentData){
        this.listContentData.push(content);  
      } 
      this.loading =false;
    }); 
  }
  
  loadMoreData(){
    this.loading =true;
    this.getContentData();
  }

  removeContentType(){
    this.contentType='';
  }
  
  extractNameFromJson(data){
    return this.RodmanCoreService.extractNameFromJson(data);
  }

  bodyCharacterLength(data){
    return this.RodmanCoreService.bodyCharacterLength(data);
  }


}
