import { Component, OnInit } from '@angular/core';
import {NgbModule,NgbCarouselConfig , NgbCarousel, NgbSlideEvent, NgbSlideEventSource } from '@ng-bootstrap/ng-bootstrap';
import { ContentIssueService } from './content-issue.service';
import { Router, RouterModule ,ActivatedRoute , Event,NavigationEnd,NavigationStart} from '@angular/router';

import { RodmanCoreService } from '../../rodman-core.service';
import * as configVar from '../../rodman-core.service';



@Component({
  selector: 'CoreLib-content-issue',
  templateUrl: './content-issue.component.html',
  styleUrls: ['./content-issue.component.css'],
  providers: [NgbModule,NgbCarouselConfig],
})
export class ContentIssueComponent implements OnInit {
  magazineId;
  checker:any;
  
  constructor(public RodmanCoreService:RodmanCoreService, public ActivatedRoute:ActivatedRoute, public Router:Router,public ContentIssueService:ContentIssueService) { 
    Router.events.subscribe(event => {
      if (event instanceof NavigationEnd ) {
        let data = event.url.split('/');
        this.checker = data[data.length-1];    
      }
    });  
  }

  ngOnInit() {
    this.ActivatedRoute.data.subscribe(data => {
      this.magazineId=data.magazineId;
    })       
  }


}
