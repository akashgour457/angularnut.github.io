import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { throwError, from } from 'rxjs';
import { catchError } from 'rxjs/operators';
import * as configVar from '../../rodman-core.service';
import { RodmanCoreService } from '../../rodman-core.service';


@Injectable({
  providedIn: 'root'
})
export class ContentIssueService {

  constructor(private HttpClient: HttpClient,private RodmanCoreService:RodmanCoreService ) { }

  getIssue(magazineId,slug) {
     return this.HttpClient.post<any>(configVar.apiURL+'issuescontroller/getIssues',{magazineId:magazineId,slug:slug}, configVar.httpOptions).pipe(
       catchError(this.RodmanCoreService.handleError)
     );
   }
}
