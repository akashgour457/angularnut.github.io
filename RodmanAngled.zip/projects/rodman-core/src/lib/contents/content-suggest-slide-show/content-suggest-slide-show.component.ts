import { Component, OnInit ,Input } from '@angular/core';
import {NgbModule,NgbCarouselConfig  } from '@ng-bootstrap/ng-bootstrap';
import { ContentRelatedService } from '../content-related/content-related.service';
import { Router } from '@angular/router';
import { RodmanCoreService } from '../../rodman-core.service';

@Component({
  selector: 'CoreLib-content-suggest-slide-show',
  inputs:['magazineId','contentId'],
  templateUrl: './content-suggest-slide-show.component.html',
  styleUrls: ['./content-suggest-slide-show.component.css'],
  providers: [NgbModule,NgbCarouselConfig],
})
export class ContentSuggestSlideShowComponent implements OnInit {
  magazineId;contentId;
  @Input() ads:any;
  showNavigationArrows = false;
  showNavigationIndicators = true;
  SlideShowData;
  loading=true;
  constructor(public RodmanCoreService:RodmanCoreService,public Router:Router, config: NgbCarouselConfig,public ContentRelatedService:ContentRelatedService) { 
    config.interval = 3000;
    config.showNavigationArrows = false;
    config.showNavigationIndicators = true;
  }

  ngOnInit() {
    this.ContentRelatedService.getRelatedContent(this.magazineId,this.contentId).subscribe((data)=>{
       this.SlideShowData = data['data'];
       this.loading=false;
    });
  }

  safeHtmlReplace(data){
    return this.RodmanCoreService.safeHtmlReplace(data);
  }
  
  getImageUrl(imageId){
    return this.RodmanCoreService.displayImageUrl(imageId);
  }

}
