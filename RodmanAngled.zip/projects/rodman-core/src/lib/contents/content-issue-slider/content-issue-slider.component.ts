import { Component, OnInit,Input} from '@angular/core';
import {NgbModule,NgbCarouselConfig , NgbCarousel, NgbSlideEvent, NgbSlideEventSource } from '@ng-bootstrap/ng-bootstrap';
import { RodmanCoreService } from '../../rodman-core.service'

@Component({
  selector: 'CoreLib-content-issue-slider',
  templateUrl: './content-issue-slider.component.html',
  styleUrls: ['./content-issue-slider.component.css'],
  providers: [NgbModule,NgbCarouselConfig],
})
export class ContentIssueSliderComponent implements OnInit {
  @Input() sliderData:any;

  showNavigationArrows = true;
  showNavigationIndicators = true;

  constructor(config: NgbCarouselConfig,public RodmanCoreService:RodmanCoreService) { 
    // config.interval = 3000;
    // config.showNavigationArrows = false;
    // config.showNavigationIndicators = false;
  }

  ngOnInit() {
  }

  getImage(imageId){
    return this.RodmanCoreService.displayImageUrl(imageId);
  }

  safeHtmlReplace(data){
    return this.RodmanCoreService.safeHtmlReplace(data);
  }

}
