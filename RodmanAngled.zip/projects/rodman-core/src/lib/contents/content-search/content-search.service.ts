import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { throwError, from } from 'rxjs';
import { catchError } from 'rxjs/operators';
import * as configVar from '../../rodman-core.service';
import { RodmanCoreService } from '../../rodman-core.service';

@Injectable({
  providedIn: 'root'
})
export class ContentSearchService {

  constructor(private HttpClient: HttpClient,private RodmanCoreService:RodmanCoreService ) { }

  refineContentList(magazineId) {
     return this.HttpClient.post<any>(configVar.apiURL+'contentsController/getContentType',{magazineId:magazineId}, configVar.httpOptions).pipe(
       catchError(this.RodmanCoreService.handleError)
     );
   }

  SearchContent(search,page,limit,magazineId,searchDateFrom,searchDateTo,contentTypeId) {
    return this.HttpClient.post<any>(configVar.apiURL+'contentsController/getSearchContent',{search:search,page:page,limit:limit,magazineId:magazineId,searchDateFrom:searchDateFrom,searchDateTo:searchDateTo,contentTypeId:contentTypeId}, configVar.httpOptions).pipe(
      catchError(this.RodmanCoreService.handleError)
    );
  }

  SearchCompany(search,page,limit,magazineId,searchDateFrom,searchDateTo,contentTypeId) {
    return this.HttpClient.post<any>(configVar.apiURL+'contentsController/getSearchBgCompanies',{search:search,page:page,limit:limit,magazineId:magazineId,searchDateFrom:searchDateFrom,searchDateTo:searchDateTo,contentTypeId:contentTypeId}, configVar.httpOptions).pipe(
      catchError(this.RodmanCoreService.handleError)
    );
  }
}
