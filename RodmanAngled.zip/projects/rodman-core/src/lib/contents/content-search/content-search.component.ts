import { Component, OnInit } from '@angular/core';
import { Router, RouterModule , ActivatedRoute ,NavigationEnd} from '@angular/router';
import { ContentSearchService } from './content-search.service';
import { RodmanCoreService } from '../../rodman-core.service';
import { FormGroup, FormBuilder,Validators } from  '@angular/forms';
import {NgbDate, NgbCalendar} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'CoreLib-content-search',
  templateUrl: './content-search.component.html',
  styleUrls: ['./content-search.component.css'],
  
})
export class ContentSearchComponent implements OnInit {
  hoveredDate: NgbDate;

  fromDate: NgbDate;
  toDate: NgbDate;

  search;page=0;limit=10;magazineId;searchDateFrom;searchDateTo;contentTypeId;
  refineContentList;
  routeUrl;
  anySlug='';
  searchSlug;
  slugCheck = false;
  micrositeCompany:any;
  featuredComapny :any;
  comapnyCategory :any;
  contentList :any=[];
  putContentList:any;
  storeSlug:any;
  
  getAllAd:any=[];
  viewAdRender:number;
  loading1 = true;
  loading2 = true;
  loadMoreCheck =true;

  searchFiled='all';
  dateFrom;
  dateTo;
  selectedProduct='all';
  staticUrl; 
  companyDataList;

  constructor(public calendar: NgbCalendar,public RodmanCoreService:RodmanCoreService,public Router:Router,public ContentSearchService:ContentSearchService,public ActivatedRoute:ActivatedRoute) {
    this.fromDate = calendar.getToday();
    this.toDate = calendar.getNext(calendar.getToday(), 'd', 10);
    Router.events.subscribe(event => {
      if (event instanceof NavigationEnd ) {
        this.routeUrl = event.url;  
        this.contentList=[];
        this.ActivatedRoute.params.subscribe(params => {
          this.page=0;
          this.anySlug = params['any'];
          this.searchSlug = params['slug'];          
       });
        this.getSearchData();
        
      }
    });

    this.ActivatedRoute.data.subscribe(data => {
      this.magazineId=data.magazineId;
    });


  }

  ngOnInit() {
    if(this.magazineId ==1 ){
      this.staticUrl = 'knowledge-center/'; 
    }
    this.getRefineData();
    this.getPageAds();
  //   this.ActivatedRoute.params.subscribe(params => {
  //     this.page=0;
  //     this.anySlug = params['any'];
  //     this.searchSlug = params['slug'];   
  //  });
  //  this.getSearchData();
  //  this.getRefineData();  

    
  }
  
  selectData(){
    if(this.refineContentList){
      this.getRefineData();
    }
  }
  

  getRefineData(){ 
    this.ContentSearchService.refineContentList(this.magazineId).subscribe((data)=>{
        this.refineContentList = data['country'];
    }); 
  }

  searchSelectFilter(){   
      // this.searchFiled=(this.searchSlug!='') ? this.searchSlug : 'all' ;
      // if(this.searchFiled==='undefined' || this.searchFiled==''){
      //   this.searchFiled=this.searchSlug;
      // }
      this.page=0;
      if((this.selectedProduct==='undefined' || this.selectedProduct=='')){
        this.selectedProduct="all";        
      }
      this.Router.navigateByUrl('/contents/searchcontent/'+this.selectedProduct+'/'+this.searchFiled);     
      // this.getSearchData();
  }

  searchDateFilter(){    
     this.page=0;
     this.getSearchData();
  }

  searchTextFilter(){
    this.page=0;
    if(this.searchFiled==='undefined' || this.searchFiled==''){
      this.searchFiled=this.searchSlug;
      this.anySlug = 'all';
    }
    this.Router.navigateByUrl('/contents/searchcontent/'+this.anySlug+'/'+this.searchFiled);
  }
  
  getSearchData(){

    if(this.loadMoreCheck){
      this.ContentSearchService.SearchCompany(this.searchSlug,this.page,this.limit,this.magazineId,this.dateFrom,this.dateTo,this.selectedProduct).subscribe((data)=>{
          this.companyDataList = data['bgTopCompanies'];
          this.comapnyCategory = data['bgCategories'];
          this.micrositeCompany = this.companyDataList.filter(function(map) {
            return map.has_featured_mircosite_listing == 1;
          });
          this.featuredComapny = this.companyDataList.filter(function(map) {
            return map.has_featured_mircosite_listing == 0;
          });
      }); 
    this.loading2 = false; 
    }  

    this.selectedProduct=(this.selectedProduct=='all') ? "": this.selectedProduct ;
    this.ContentSearchService.SearchContent(this.searchSlug,this.page,this.limit,this.magazineId,this.dateFrom,this.dateTo,this.selectedProduct).subscribe((data)=>{
      this.putContentList = data['data'];  
      for(let content of this.putContentList){
        this.contentList.push(content);  
      } 
      this.page = data['page']+1;
    }); 
     
 

      // setTimeout(function(){
      //   this.loading1 = false;
      // },6000);

      setTimeout (() => {
        this.loading1 = false;
      }, 10000)
  } 

  spinnerHide(){
 
  }

  safeHtml(data){
    return this.RodmanCoreService.safeHtmlReplace(data)
  }

  bodyCharacterLength(data){
     return this.RodmanCoreService.bodyCharacterLength(data);
  }


  loadMoreData(){
    this.loading1 = true;
    this.loadMoreCheck =false;
    this.getSearchData();
  }

  getPageAds(){
    this.RodmanCoreService.getAllAdst(this.magazineId).subscribe((data =>{
      this.getAllAd = data;
      this.viewAdRender= 1;
    }))  

  }

  // Date Option
      onDateSelection(date: NgbDate) {
        if (!this.fromDate && !this.toDate) {
          this.fromDate = date;
        } else if (this.fromDate && !this.toDate && date.after(this.fromDate)) {
          this.toDate = date;
        } else {
          this.toDate = null;
          this.fromDate = date;
        }
      }

      isHovered(date: NgbDate) {
        return this.fromDate && !this.toDate && this.hoveredDate && date.after(this.fromDate) && date.before(this.hoveredDate);
      }

      isInside(date: NgbDate) {
        return date.after(this.fromDate) && date.before(this.toDate);
      }

      isRange(date: NgbDate) {
        return date.equals(this.fromDate) || date.equals(this.toDate) || this.isInside(date) || this.isHovered(date);
      }


}
