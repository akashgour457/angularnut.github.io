import { Component, OnInit,Input } from '@angular/core';
import { ContentDynamicViewComponent } from './content-dynamic-view.component';


@Component({
  selector: 'CoreLib-content-static-content',
  templateUrl: './content-static-content.component.html',
  styleUrls: ['./content-dynamic.component.css']
})
export class ContentStaticContentComponent extends ContentDynamicViewComponent {
  @Input()  ads:any;
  ngOnInit() {
  }

}
