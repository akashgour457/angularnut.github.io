import { Component, OnInit,Input } from '@angular/core';
import { ContentDynamicViewComponent } from './content-dynamic-view.component';

@Component({
  selector: 'CoreLib-content-webinars',
  templateUrl: './content-webinars.component.html',
  styleUrls: ['./content-dynamic.component.css']
})
export class ContentWebinarsComponent extends ContentDynamicViewComponent {
  @Input()  ads:any;
  ngOnInit() {
  }

}
