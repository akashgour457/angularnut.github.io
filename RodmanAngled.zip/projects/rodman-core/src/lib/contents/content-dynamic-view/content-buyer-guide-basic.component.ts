import { Component, OnInit,Input } from '@angular/core';
import { ContentDynamicViewComponent } from './content-dynamic-view.component';


@Component({
  selector: 'CoreLib-content-buyer-guide-basic',
  templateUrl: './content-buyer-guide-basic.component.html',
  styles: []
})
export class ContentBuyerGuideBasicComponent extends ContentDynamicViewComponent {
 @Input()  ads:any;

  ngOnInit() {
  }

}
