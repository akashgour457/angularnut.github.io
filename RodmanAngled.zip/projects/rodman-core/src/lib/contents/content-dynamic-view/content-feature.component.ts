import { Component, OnInit, Input, Output, EventEmitter  } from '@angular/core';
import { ContentDynamicViewComponent } from './content-dynamic-view.component';


@Component({
  selector: 'CoreLib-content-feature',
  templateUrl: './content-feature.component.html',
  styleUrls: ['./content-dynamic.component.css']
})
export class ContentFeatureComponent extends ContentDynamicViewComponent {
  @Input()  ads:any;
  ngOnInit() {
  }


}
