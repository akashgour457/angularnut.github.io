import { Component, OnInit,Input } from '@angular/core';
import { ContentDynamicViewComponent } from './content-dynamic-view.component';

@Component({
  selector: 'CoreLib-content-video',
  templateUrl: './content-video.component.html',
  styleUrls: ['./content-dynamic.component.css']
})
export class ContentVideoComponent extends ContentDynamicViewComponent implements OnInit {
  @Input()  ads:any;
  videoPath;

  ngOnInit() {
    // if(this.ContentInterface[0].video[0].link_title == 'YouTube'){

    // }else
     switch(this.ContentInterface[0].video[0].link_title){

      case 'YouTube':
        this.videoPath =  'https://www.youtube.com/embed/'+this.ContentInterface[0].video[0].link;
        break;
      case 'Vimeo':
        this.videoPath =  'https://player.vimeo.com/video/'+this.ContentInterface[0].video[0].link;
        break;
      case 'BrightCove':
        this.videoPath =  '//players.brightcove.net/1160438696001/SJaEAUSpl_default/index.html?videoId='+this.ContentInterface[0].video[0].link;
        break;
     default:
        this.videoPath =  'https://www.youtube.com/embed/'+this.ContentInterface[0].video[0].link;
        break;
        

     }
    

    this.videoPath =  this.videoURL(this.videoPath);
  }

  
  // photoURL(url)

  


}
