import { Component, OnInit,Input } from '@angular/core';
import { ContentDynamicViewComponent } from './content-dynamic-view.component';

@Component({
  selector: 'CoreLib-content-infographics',
  templateUrl: './content-infographics.component.html',
styles: [`
    .line{
      border-top: 1px solid;
    }
  `
]
})
export class ContentInfographicsComponent extends ContentDynamicViewComponent{
  @Input()  ads:any;
  ngOnInit() {
  }

}
