import { Component, OnInit ,Input } from '@angular/core';
import { ContentDynamicViewComponent } from './content-dynamic-view.component';


@Component({
  selector: 'CoreLib-content-default',
  templateUrl: './content-default.component.html',
  styleUrls: ['./content-dynamic.component.css']
})
export class ContentDefaultComponent extends ContentDynamicViewComponent {
  @Input()  ads:any;
  ngOnInit() {
  }

}
