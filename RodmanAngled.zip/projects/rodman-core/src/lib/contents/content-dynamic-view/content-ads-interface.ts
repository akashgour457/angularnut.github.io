export interface ContentAdsInterface {
    magazineId:string
}
