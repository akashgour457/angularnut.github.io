import { Component, OnInit ,Input} from '@angular/core';
import { ContentDynamicViewComponent } from './content-dynamic-view.component';


@Component({
  selector: 'CoreLib-content-formulary',
  templateUrl: './content-formulary.component.html',
  styleUrls: ['./content-dynamic.component.css']
})
export class ContentFormularyComponent extends ContentDynamicViewComponent {
  @Input()  ads:any;
  ngOnInit() {
  }

}
