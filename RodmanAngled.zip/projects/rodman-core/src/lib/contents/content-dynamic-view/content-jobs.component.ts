import { Component, OnInit,Input } from '@angular/core';
import { ContentDynamicViewComponent } from './content-dynamic-view.component';

@Component({
  selector: 'CoreLib-content-jobs',
  templateUrl: './content-jobs.component.html',
  styleUrls: ['./content-dynamic.component.css']
})
export class ContentJobsComponent extends ContentDynamicViewComponent {
  @Input()  ads:any;
  ngOnInit() {
  }

}
