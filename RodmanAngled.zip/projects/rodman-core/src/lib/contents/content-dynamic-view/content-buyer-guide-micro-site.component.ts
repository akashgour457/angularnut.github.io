import { Component, OnInit,Input } from '@angular/core';
import { ContentDynamicViewComponent } from './content-dynamic-view.component';

@Component({
  selector: 'CoreLib-content-buyer-guide-micro-site',
  templateUrl: './content-buyer-guide-micro-site.component.html',
  styles: []
})
export class ContentBuyerGuideMicroSiteComponent extends ContentDynamicViewComponent {
  @Input()  ads:any;
  ngOnInit() {
  }

}
