import { Component, OnInit } from '@angular/core';
import { ContentDynamicViewComponent } from './content-dynamic-view.component';


@Component({
  selector: 'CoreLib-content-white-paper',
  templateUrl: './content-white-paper.component.html',
  styles: [`h2{ background-color:#ccc; } .back-color{background-color: #ccc;}`]
})
export class ContentWhitePaperComponent extends ContentDynamicViewComponent  {
  data :any;
  ngOnInit() {
    // alert('sfdsf')
  }

}
