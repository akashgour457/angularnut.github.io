import { Component, Input, Output, EventEmitter } from '@angular/core';
import { ContentInterface } from './content-interface';
import { ContentAdsInterface } from './content-ads-interface'
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { RodmanCoreService } from '../../rodman-core.service'; 
import { Router } from '@angular/router'; 




@Component({
  selector: 'CoreLib-content-dynamic-view',
  template: ``,
  styleUrls: ['./content-dynamic.component.css']
})
export class ContentDynamicViewComponent {
  @Input() ContentInterface: ContentInterface[] = [];
  @Input() ContentAdsInterface: ContentAdsInterface;
  @Output() select = new EventEmitter();

  getAllAd:any=[];
  viewAdRender:number;

  constructor(public sanitizer: DomSanitizer,public RodmanCoreService:RodmanCoreService,public Router:Router) {
    // super(sanitizer,RodmanCoreService,Router);
   }

  ngOnInit() {
  }

  selectView(ContentInterface: ContentInterface,ContentAdsInterface:ContentAdsInterface) {
    this.select.emit(ContentInterface);

  }

  extractNameFromJson(obj){
    return this.RodmanCoreService.extractNameFromJson(obj);
  }

  videoURL(url) {
    return this.sanitizer.bypassSecurityTrustResourceUrl(url);
  }

  safeHtml(data){
    return this.RodmanCoreService.safeHtml(data);
  }  

  safeHtmlReplace(data){
    return this.RodmanCoreService.safeHtmlReplace(data);
  } 




}
