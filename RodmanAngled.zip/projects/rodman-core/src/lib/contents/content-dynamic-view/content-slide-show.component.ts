import { Component, OnInit,Input } from '@angular/core';
import { ContentDynamicViewComponent } from './content-dynamic-view.component';


@Component({
  selector: 'CoreLib-content-slide-show',
  templateUrl: './content-slide-show.component.html',
  styleUrls: ['./content-dynamic.component.css']
})
export class ContentSlideShowComponent extends ContentDynamicViewComponent {
  @Input()  ads:any;
  ngOnInit() {
  }

}
