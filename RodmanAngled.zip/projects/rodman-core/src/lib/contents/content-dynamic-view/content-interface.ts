export interface ContentInterface {
    status:string;
    data:any;
    message:any;
    video : any;
    magazine_id:any
    // id:string;
    // content_type_id:string ;
    // author_name:any;
    // primary_image:any;
    // title:any ;
    // summary: any;
    // body:any;
    // publish_date:any ;
    // uploaded_by:any;
    // firstName:any ;
    // lastName:any ;
    // viewUrl:any ;
    // short_tag:any ;
    // slug: any;
    // magazine_id:any;
    // RELATED_SEARCHES:any;
    // primary_image_main:any;
    // slider_image:any; 

}

