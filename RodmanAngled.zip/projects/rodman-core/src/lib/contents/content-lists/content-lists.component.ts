import { Component, OnInit } from '@angular/core';
import {ContentViewService} from '../content-view/content-view.service'; 
import { ContentInterface } from '../content-dynamic-view/content-interface';
import { NgbModule,NgbCarouselConfig , NgbCarousel, NgbSlideEvent, NgbSlideEventSource } from '@ng-bootstrap/ng-bootstrap';
import {  ContentBoxTabsService } from '../content-box-tabs/content-box-tabs.service';
import { Router ,NavigationEnd } from '@angular/router'; 

import { RodmanCoreService } from '../../rodman-core.service';

const contentDataView: ContentInterface[] = [
  { status:'Fail',  data:[],  message:'' ,    video : [],magazine_id:''},

];


@Component({
  selector: 'CoreLib-content-lists',
  templateUrl: './content-lists.component.html',
  styleUrls: ['./content-lists.component.css']
})
export class ContentListsComponent implements OnInit {
  contentPageUrl='/contents/view_breaking-news/2019-08-11/rye-may-stabilize-blood-sugar-levels-and-decrease-cardiovascular-disease-risk/';
  magazineId=1;
  contentData;
  page;
  ads:any=[];
  dataFetch: boolean = false;
  displayDefault = 0;
  contentDataView = contentDataView
  selectedContentView = contentDataView[0];
  loading=true;


  constructor( private ViewContentService:ContentViewService,config: NgbCarouselConfig,public ContentBoxTabService:ContentBoxTabsService,public RodmanCoreService:RodmanCoreService,public Router:Router) { 
    this.dataFetch = false;
  }

  ngOnInit() {
    this.viewData();
  }

  selectView(contentDataView: ContentInterface) {
    this.selectedContentView = contentDataView;
  }
  
  ngOnChanges(){     
      this.getads();
      // this.viewData();
  }

  safeHtml(data){
    return this.RodmanCoreService.safeHtml(data)
  }


  viewData(){
    if((this.dataFetch)==false){ 
      this.ViewContentService.getContentDetails(this.magazineId,this.contentPageUrl).subscribe((data)=>{
        this.dataFetch = true;
        this.contentData = data['data'];
        this.contentDataView[0] = data['data'];
        this.page = data['data'].slug;  
        this.displayDefault = 1;
        this.loading= false;
      }); 
    }
  }

  check(){
    this.dataFetch = false;
  }

  getads(){
      this.RodmanCoreService.getAllAdst(this.magazineId).subscribe((data =>{
        this.ads = data;
    }))
  }



  

}
