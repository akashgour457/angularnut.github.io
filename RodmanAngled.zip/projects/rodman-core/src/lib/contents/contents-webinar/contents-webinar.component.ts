import { Component, OnInit } from '@angular/core';
import { RodmanCoreService } from '../../rodman-core.service';
import { Event,NavigationEnd,Router,ActivatedRoute} from '@angular/router'; 
import { ListContentService} from '../list-content/list-content.service'

@Component({
  selector: 'CoreLib-contents-webinar',
  templateUrl: './contents-webinar.component.html',
  styleUrls: ['./contents-webinar.component.css']
})
export class ContentsWebinarComponent implements OnInit {
  currentURL : any ;
  contentType;
  magazineId;
  slugHeading;
  limit=10;
  page=0;
  listContentData;
  loading =true;
  getAllAd:any=[];
  viewAdRender:number;

  constructor(public ListContentService:ListContentService, public RodmanCoreService:RodmanCoreService,public Router:Router,public ActivatedRoute:ActivatedRoute) {

    Router.events.subscribe(event => {
      if (event instanceof NavigationEnd ) {
        this.currentURL = event.url; 
        if(this.currentURL=='/contents/list_webinars'){
          this.currentURL= '';
          this.contentType = '2542';
        }  
      }
    });


  }

  ngOnInit() {
    this.ActivatedRoute.data.subscribe(data => {
      this.magazineId=data.magazineId;
    });
    this.getContentData();
    this.getads();
  }

  getImage(imageId){
    return this.RodmanCoreService.displayImageUrl(imageId);
  }
  safeHtml(data){
    // return data.replace(/[^a-zA-Z0-9.()'"$@&!?:,]/g, "")
    return this.RodmanCoreService.safeHtmlReplace(data);

  }  

  getContentData(){ 
     this.ListContentService.getContent(this.currentURL,this.magazineId,this.limit,this.page,this.contentType).subscribe((data)=>{
      this.listContentData = data['data'];
      if(this.page==0){ 
        this.slugHeading = data['contentTypeName'];
      } 
      this.page = data['page']+1;
      this.loading =false;
    }); 
  }
  getads(){
    this.RodmanCoreService.getAllAdst(this.magazineId).subscribe((data =>{
      this.getAllAd = data;
      this.viewAdRender = 1;
    }))
  }
}
