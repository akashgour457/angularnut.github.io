import { Component, OnInit } from '@angular/core';
import { ListContentService } from '../list-content/list-content.service';
import { RodmanCoreService } from '../../rodman-core.service';
import { Router, RouterModule ,ActivatedRoute } from '@angular/router';

@Component({
  selector: 'CoreLib-content-glossary',
  templateUrl: './content-glossary.component.html',
  styleUrls: ['./content-glossary.component.css']
})
export class ContentGlossaryComponent implements OnInit {
  glossaryData:any=[];
  loading = true;
  magazineId;
  getAllAd:any=[];
  viewAdRender:number;
  current_letter =''; 

  constructor(public ActivatedRoute:ActivatedRoute, public Router:Router,private ListContentService: ListContentService,public RodmanCoreService:RodmanCoreService ) { 
  }

  ngOnInit() {
    this.ActivatedRoute.data.subscribe(data => {
      this.magazineId=data.magazineId;
    })
    this.ListContentService.getContent('glossary',this.magazineId,10,0,'').subscribe((data)=>{
      this.glossaryData = data['data'];     
        this.getads();
        this.loading =false;
    }); 
  }


  getads(){
    this.RodmanCoreService.getAllAdst(this.magazineId).subscribe((data =>{
      this.getAllAd = data;
      this.viewAdRender= 1;
      }))
  }

  matchCharacter(current,pre){
    if(current.charAt(0) != pre){
      this.current_letter = current.charAt(0);
      return true;
    }
    return false;
  }


}
