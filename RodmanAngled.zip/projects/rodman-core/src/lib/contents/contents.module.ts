import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ContentsRoutingModule } from './contents-routing.module';
import { ListContentComponent } from './list-content/list-content.component';
import { StaticContentComponent } from './static-content/static-content.component';
import { ContentViewComponent } from './content-view/content-view.component';
import { ContentDynamicViewComponent } from './content-dynamic-view/content-dynamic-view.component';
import { ContentInfographicsComponent } from './content-dynamic-view/content-infographics.component';
import { ContentSearchComponent } from './content-search/content-search.component';
import { ContentRelatedComponent } from './content-related/content-related.component';
import { ContentSuggestSlideShowComponent } from './content-suggest-slide-show/content-suggest-slide-show.component';
import { NgbModule ,NgbModal ,  NgbDatepickerModule} from '@ng-bootstrap/ng-bootstrap';
import { CarouselModule } from 'ngx-bootstrap';
import { ContentBoxTabsComponent } from './content-box-tabs/content-box-tabs.component';
import { AdsModule } from '../ads/ads.module';
import { UsersModule } from '../users/users.module';
import { SitesModule  } from '../sites/sites.module'
import { ContentDefaultComponent } from './content-dynamic-view/content-default.component';
import { ContentJobsComponent } from './content-dynamic-view/content-jobs.component';
import { ContentFeatureComponent } from './content-dynamic-view/content-feature.component';
import { ContentVideoComponent } from './content-dynamic-view/content-video.component';
import { ContentWebinarsComponent } from './content-dynamic-view/content-webinars.component';
import { ContentFormularyComponent } from './content-dynamic-view/content-formulary.component';
import { ContentBuyerGuideBasicComponent } from './content-dynamic-view/content-buyer-guide-basic.component';
import { ContentBuyerGuideMicroSiteComponent } from './content-dynamic-view/content-buyer-guide-micro-site.component';
import { ContentSlideShowComponent } from './content-dynamic-view/content-slide-show.component';
import { ContentStaticContentComponent } from './content-dynamic-view/content-static-content.component';

import { DfpModule } from 'ngx-dfp';
import { ContentWhitePaperComponent } from './content-dynamic-view/content-white-paper.component';
import { ContentNewsReleaseComponent } from './content-dynamic-view/content-news-release.component';
import { ContentCompanyRelatedComponent } from './content-company-related/content-company-related.component';
import { ContentRelatedContentListComponent } from './content-related-content-list/content-related-content-list.component';
import { ContentRelatedSearchesComponent } from './content-related-searches/content-related-searches.component';
import { ContentGlossaryComponent } from './content-glossary/content-glossary.component';
import { ContentIssueComponent } from './content-issue/content-issue.component';
import { ContentIssueSliderComponent } from './content-issue-slider/content-issue-slider.component';
import { ContentRssFeedsComponent } from './content-rss-feeds/content-rss-feeds.component';
import { ContentListsComponent } from './content-lists/content-lists.component';
import { ContentsWebinarComponent } from './contents-webinar/contents-webinar.component';
import { ContentMagazineIssueComponent } from './content-magazine-issue/content-magazine-issue.component';


@NgModule({
  declarations: [ListContentComponent,StaticContentComponent, ContentViewComponent, ContentDynamicViewComponent,  ContentInfographicsComponent, ContentSearchComponent, ContentRelatedComponent, ContentSuggestSlideShowComponent, ContentBoxTabsComponent, ContentDefaultComponent, ContentJobsComponent, ContentFeatureComponent, ContentVideoComponent, ContentWebinarsComponent, ContentFormularyComponent, ContentBuyerGuideBasicComponent, ContentBuyerGuideMicroSiteComponent, ContentSlideShowComponent, ContentStaticContentComponent, ContentWhitePaperComponent, ContentNewsReleaseComponent, ContentCompanyRelatedComponent, ContentRelatedContentListComponent, ContentRelatedSearchesComponent, ContentGlossaryComponent, ContentIssueComponent, ContentIssueSliderComponent, ContentRssFeedsComponent, ContentListsComponent, ContentsWebinarComponent, ContentMagazineIssueComponent],
  imports: [
    CommonModule,
    // FormsModule,
    ContentsRoutingModule,
    NgbModule,
    NgbDatepickerModule,
    NgbModule,
    CarouselModule.forRoot(),
    AdsModule ,
    SitesModule,
    UsersModule,
    DfpModule.forRoot({
      idleLoad: true,
      enableVideoAds: true,
      personalizedAds: true, // Request personalized ads by default
      singleRequestMode: true, // Only applies to initial refresh
      onSameNavigation: 'refresh',
      globalTargeting: {
        // food: ['NUT', 'HOME']
      }
    })   
  
  ],
  exports: [ListContentComponent,StaticContentComponent, ContentViewComponent, ContentDynamicViewComponent,  ContentInfographicsComponent, ContentSearchComponent, ContentRelatedComponent, ContentSuggestSlideShowComponent, ContentBoxTabsComponent, ContentDefaultComponent,ContentRelatedContentListComponent,ContentGlossaryComponent,ContentIssueComponent,ContentIssueSliderComponent,ContentRssFeedsComponent,ContentListsComponent,ContentWebinarsComponent,ContentMagazineIssueComponent],
  providers: [{ provide: NgbModule} ],
})
export class ContentsModule { }


