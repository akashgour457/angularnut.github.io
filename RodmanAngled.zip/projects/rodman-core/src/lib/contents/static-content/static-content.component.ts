import { Component, OnInit } from '@angular/core';
import { StaticContentService } from './static-content.service';
import { Router, ActivatedRoute ,NavigationEnd } from '@angular/router';
import { RodmanCoreService } from '../../rodman-core.service';


@Component({
  selector: 'CoreLib-static-content',
  templateUrl: './static-content.component.html',
  styleUrls: ['./static-content.component.css']
})
export class StaticContentComponent implements OnInit {
  limit=30;
  page=0;
  contentType='';
  magazineId;
  routeUrl;
  staticContentData;
  getAllAd:any=[];
  viewAdRender:number;
  loading=true;

  constructor(private StaticContentService:StaticContentService,private Router:Router,public ActivatedRoute:ActivatedRoute,public RodmanCoreService :RodmanCoreService ) {
    Router.events.subscribe(event => {
      if (event instanceof NavigationEnd ) {
        this.routeUrl = event.url;         
      }
    });

   }


  ngOnInit() {
    this.ActivatedRoute.data.subscribe(data => {
      this.magazineId=data.magazineId;
    });
    
    this.RodmanCoreService.getAllAdst(this.magazineId).subscribe((data =>{
      this.getAllAd = data;
      this.viewAdRender = 1;
   }))

    this.getStatic();

  }

  ngOnChanges(){  
    // this.getStatic();
  }

  safeHtml(data){
    return this.RodmanCoreService.safeHtml(data);
  }

  
  getStatic(){
    this.StaticContentService.getStaticContent(this.routeUrl,this.magazineId,this.limit,this.page,this.contentType).subscribe((data)=>{
      this.staticContentData = data['data'];
      this.loading=false;
    }); 

  }
}
