import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { throwError, from } from 'rxjs';
import { catchError } from 'rxjs/operators';
import * as configVar from '../../rodman-core.service';
import { RodmanCoreService } from '../../rodman-core.service';

@Injectable({
  providedIn: 'root'
})
export class StaticContentService {

  constructor(private HttpClient: HttpClient,private RodmanCoreService:RodmanCoreService ) { }

  getStaticContent(slug,magazineId,limit,page,contentType) {
    let slugs = slug.replace('/','');
    return this.HttpClient.post<any>(configVar.apiURL+'taxonomysController/getContentTaxonomys',{pageUrl:slugs,magazineId:magazineId,limit:limit,page:page,contentType:contentType}, configVar.httpOptions).pipe(
      catchError(this.RodmanCoreService.handleError)
    );
  }
}
