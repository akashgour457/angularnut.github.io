import { Component, OnInit,Input } from '@angular/core';
import { RodmanCoreService } from '../../rodman-core.service';
import { ListContentService } from '../list-content/list-content.service'
import { Router, NavigationEnd } from '@angular/router';


@Component({
  selector: 'CoreLib-content-related-content-list',
  inputs: ['routeUrl','magazineId','contentType'] ,
  templateUrl: './content-related-content-list.component.html',
  styleUrls: ['./content-related-content-list.component.css']
})
export class ContentRelatedContentListComponent implements OnInit {
  @Input() contentId:any;
  routeUrl;
  magazineId;
  listContentData=[]; 
  contentData:any;
  slugHeading;
  limit=10;
  page=0;
  contentType='';
  contentTaxonomy;
  taxonomyUrl;
  taxonomyUrlTo;
  loading=true;
  currentURL;
  staticUrl= '/';


  constructor(public Router:Router,private ListContentService: ListContentService,public RodmanCoreService:RodmanCoreService ) { 
    Router.events.subscribe(event => {
      if (event instanceof NavigationEnd ) {
        this.currentURL = event.url; 
      }
    });
  }
  ngOnInit() {
    if((this.magazineId ==1) ||  (this.magazineId ==5)){
      this.staticUrl = '/knowledge-center/'; 
    }
  }

  ngOnChanges(){  
    this.page=0;
    this.slugHeading;
    this.listContentData=[];
    this.getContentData();
  }
  
  getContentData(){ 
    
    // this.taxonomyUrl = this.routeUrl.split('/');  
    // this.taxonomyUrl = (this.taxonomyUrl[this.taxonomyUrl.length-1]);
    // let url =this.taxonomyUrl.split('_');  
    // this.taxonomyUrlTo = url[1];
    this.ListContentService.getContent(this.routeUrl,this.magazineId,this.limit,this.page,this.contentType).subscribe((data)=>{
      this.contentData = data['data'];
      if(this.page==0){ 
        this.slugHeading = data['contentTypeName'];
        // this.contentTaxonomy = data['CONTENT_TAXONOMYS'];
      } 
      this.page = data['page']+1;
      for(let content of this.contentData){
        this.listContentData.push(content);  
      } 
      this.loading =false;
    }); 
  }
  loadMoreData(){
    this.loading =true;
    this.getContentData();
  }

  safeHtml(data){
    return this.RodmanCoreService.safeHtmlReplace(data);
  }
  bodyCharacterLength(data){
    return this.RodmanCoreService.bodyCharacterLength(data);
  }

  getImage(imageId){
    return this.RodmanCoreService.displayImageUrl(imageId);
  }

  extractNameFromJson(data){
    return this.RodmanCoreService.extractNameFromJson(data);
  }

}
