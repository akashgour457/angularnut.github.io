import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { throwError, from } from 'rxjs';
import { catchError } from 'rxjs/operators';
import * as configVar from '../../rodman-core.service';
import { RodmanCoreService } from '../../rodman-core.service';

@Injectable({
  providedIn: 'root'
})
export class ContentViewService {
  constructor(private HttpClient: HttpClient,private RodmanCoreService:RodmanCoreService ) { }

    getContentDetails(magazineId,contentUrl) {
      // contentUrl ='/issues/2019-03-01/view_features/the-conductive-ink-and-materials-market-42752';
         return this.HttpClient.post<any>(configVar.apiURL+'taxonomysController/getViewContent',{magazineId:magazineId,contentUrl:contentUrl}, configVar.httpOptions).pipe(
       catchError(this.RodmanCoreService.handleError)
     );
   }

}   