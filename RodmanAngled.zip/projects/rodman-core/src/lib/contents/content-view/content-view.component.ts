import { Component, OnInit } from '@angular/core';
import {ContentViewService} from './content-view.service'; 
import { ContentInterface } from '../content-dynamic-view/content-interface';
import { NgbModule,NgbCarouselConfig , NgbCarousel, NgbSlideEvent, NgbSlideEventSource } from '@ng-bootstrap/ng-bootstrap';
import {  ContentBoxTabsService } from '../content-box-tabs/content-box-tabs.service';
import { Router ,NavigationEnd } from '@angular/router'; 
import { RodmanCoreService } from '../../rodman-core.service';

const contentDataView: ContentInterface[] = [
  { status:'Fail',  data:[],  message:'' ,    video : [],magazine_id:''},
];


@Component({
  selector: 'CoreLib-content-view',
  inputs:['magazineId','contentPageUrl'],
  templateUrl: './content-view.component.html',
  styleUrls: ['./content-view.component.css'],
  providers: [NgbModule,NgbCarouselConfig],
})
export class ContentViewComponent implements OnInit {
  contentPageUrl;
  magazineId;
  contentData;
  page;
  getAllAd:any=[];
  dataFetch: boolean = false;
  displayDefault = 0;
  contentDataView = contentDataView
  selectedContentView = contentDataView[0];
  loading=true;

  constructor( private ViewContentService:ContentViewService,config: NgbCarouselConfig,public ContentBoxTabService:ContentBoxTabsService,public RodmanCoreService:RodmanCoreService,public Router:Router) { 
    this.dataFetch = false;
  }

  ngOnInit() {
    // this.viewData();s
  }

  selectView(contentDataView: ContentInterface) {
    this.selectedContentView = contentDataView;
  }
  
  ngOnChanges(){     
      this.getads();
      this.viewData();
  } 

  viewData(){
    // if((this.dataFetch)==false){ 
      this.ViewContentService.getContentDetails(this.magazineId,this.contentPageUrl).subscribe((data)=>{
        this.dataFetch = true;
        this.contentData = data['data'];
        this.contentDataView[0] = data['data'];
        this.page = data['data'].slug;  
        this.displayDefault = 1;
        this.loading= false;
      }); 
    // }
  }

  check(){
    this.dataFetch = false;
  }

  getads(){
      this.RodmanCoreService.getAllAdst(this.magazineId).subscribe((data =>{
        this.getAllAd = data;
    }))
  }



  

}
