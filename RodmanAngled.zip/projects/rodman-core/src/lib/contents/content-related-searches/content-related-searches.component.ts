import { Input,Component, OnInit, ViewChild, ElementRef, EventEmitter, Output } from '@angular/core';
import { Router } from '@angular/router';


@Component({
  selector: 'CoreLib-content-related-searches',
  templateUrl: './content-related-searches.component.html',
  styleUrls: ['./content-related-searches.component.css']
})
export class ContentRelatedSearchesComponent implements OnInit {
  @Input() dataArray: any;
  constructor(public Router:Router) { }

  ngOnInit() {
  }

}
