import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute ,NavigationEnd } from '@angular/router';
import { RodmanCoreService } from '../../../../../rodman-core/src/lib/rodman-core.service';

@Component({
  selector: 'CoreLib-content-infographics',
  templateUrl: './content-infographics.component.html',
  styleUrls: ['./content-infographics.component.css']
})
export class ContentInfographicsComponent implements OnInit {
  currentURL : any ;
  contentType : any ;
  magazineId;
  getAllAd:any=[];
  viewAdRender:number;


  constructor(private router:Router,public RodmanCoreService:RodmanCoreService,public ActivatedRoute:ActivatedRoute) {
       router.events.subscribe(event => {        if (event instanceof NavigationEnd ) {
          this.currentURL = event.url; 
        }
      });


   }

  ngOnInit() {
    this.ActivatedRoute.data.subscribe(data => {
      this.magazineId=data.magazineId;
    })

    this.RodmanCoreService.getAllAdst(this.magazineId).subscribe((data =>{
      this.getAllAd = data;
      this.viewAdRender = 1;
  }))
  }


}