import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { throwError, from } from 'rxjs';
import { catchError } from 'rxjs/operators';
import * as configVar from '../../rodman-core.service';
import { RodmanCoreService } from '../../rodman-core.service';

@Injectable({
  providedIn: 'root'
})
export class ContentCompanyRelatedService {

  constructor(private HttpClient: HttpClient,private RodmanCoreService:RodmanCoreService ) { }

  getContentRelated(magazineId,limit,page,companyId,contentType) {
     return this.HttpClient.post<any>(configVar.apiURL+'taxonomysController/getContentReleated',{contentType:contentType,magazineId:magazineId,limit:limit,page:page,companyId:companyId}, configVar.httpOptions).pipe(
       catchError(this.RodmanCoreService.handleError)
     );
  }

}