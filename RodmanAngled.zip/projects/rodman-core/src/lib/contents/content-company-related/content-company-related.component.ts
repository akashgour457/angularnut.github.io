import { Component, OnInit } from '@angular/core';
import { Input, Output, EventEmitter } from '@angular/core';
import { ContentCompanyRelatedService } from './content-company-related.service';
import { RodmanCoreService } from '../../rodman-core.service';

@Component({
  selector: 'CoreLib-content-company-related',
  templateUrl: './content-company-related.component.html',
  styleUrls: ['./content-company-related.component.css']
})
export class ContentCompanyRelatedComponent implements OnInit {
  @Input() magazineId :any;
  @Input() companyId:any;
  @Input() contentType:any;
  page=0;
  limit=10;
  loading=true;
  relatedData:any;

  constructor(public ContentCompanyRelatedService:ContentCompanyRelatedService,public RodmanCoreService:RodmanCoreService) { 
  }

  ngOnInit() {    
    this.getData();
  }

  ngOnChanges(){
    // this.getData();
  }

  safeHtml(data){
    // return data.replace(/[^a-zA-Z0-9.()'"$@&!?:, ]/g, "")
    return this.RodmanCoreService.safeHtmlReplace(data);
  }

  getData(){
    this.ContentCompanyRelatedService.getContentRelated(this.magazineId,this.limit,this.page,this.companyId,this.contentType).subscribe((data)=>{
      this.relatedData=data['data'];
      this.loading=false;
    }); 

  }

}
