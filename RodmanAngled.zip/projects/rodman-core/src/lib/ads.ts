export interface Ads {
    header_1:any;
    content_right_1:any;
    content_right_2:any;
    content_right_3:any;
    footer_1:any;
    left_site_ad:any;
    right_site_ad:any;
}
