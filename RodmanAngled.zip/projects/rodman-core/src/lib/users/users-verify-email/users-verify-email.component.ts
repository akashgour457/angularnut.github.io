import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { FormGroup, FormBuilder,Validators,FormArray,FormControl,ValidatorFn } from  '@angular/forms';
import { UsersVerifyEmailService } from './users-verify-email.service';
import { BsModalService, BsModalRef ,ModalDirective} from 'ngx-bootstrap/modal';

@Component({
  selector: 'CoreLib-users-verify-email',
  inputs:['magazineId','passKey','email'],
  templateUrl: './users-verify-email.component.html',
  styleUrls: ['./users-verify-email.component.css']
})
export class UsersVerifyEmailComponent implements OnInit {
  magazineId;  passKey; email;
  bsModal: BsModalRef;
  isModalShown = true;
  userData:any;
  verifyForm: FormGroup;
  submitted: boolean;
  formData:any;
  mailing_list:any;

  id:any;
  object ={};
  message  = false;
  showMsgRegistration = false;
  cnfPasswordMessage: boolean =false ;
  newsLetterMessage =true ;
  checkedList:any;
  newsLetterFormArray: Array<any> = [];

  @ViewChild('autoShownModal', { static: false }) autoShownModal: ModalDirective;
  constructor(private formBuilder: FormBuilder,private UserVerifyEmailService: UsersVerifyEmailService,public Router:Router) {    

  }


  ngOnInit() {
    this.UserVerifyEmailService.verifyUser(this.magazineId,this.passKey,this.email).subscribe((data)=>{

      if(data.status =="success" && data.message =="Verification successfully" && data.registerStatus =="success" ){
        this.userData = data['data'];
        this.formData = data['formData'];
        this.mailing_list = data['SUBSCRIBE_MAILING_LIST'];
        this.isModalShown = true;
        this.id = data['data'].id;
      }else if(data.registerStatus =="IL"){
        this.message = true;
        // this.isModalShown = true;
        // this.userData = 'data ';
      }
     
    }); 
    


    this.verifyForm = this.formBuilder.group({
      magazineId:['',[Validators.required]],
      id:['',[Validators.required]],
      // id:111,
      firstName: ['',[Validators.required]],  
      lastName: ['',Validators.required],
      password: ['',Validators.required],
      cnfpassword: ['',Validators.required],
      formData:this.object,
      maling_list:this.formBuilder.array([],this.minSelectedCheckboxes(1)),
    },{validator: this.checkIfMatchingPasswords('password', 'cnfpassword')});
  }

  get verifyVal() { 
    return this.verifyForm.controls; 
  }

  createObjectOverView(key,value){
    if(value){
      this.object[key] = value;
    }else{
      delete this.object[key];
    }
  }

  showModal(): void {
    this.isModalShown = true;
  }
 
  hideModal(): void {
    this.autoShownModal.hide();
  }
 
  onHidden(): void {
    this.isModalShown = false;
  }

  onSubmit(){
    this.submitted = true
    if (this.verifyForm.invalid) {
      return;
    }
    this.UserVerifyEmailService.UserDeatils(this.verifyForm.value).subscribe((data)=>{
      if(data.status =="success" && data.message =="Data updated successfully" ){
         this.showMsgRegistration= true;
         setTimeout (() => {      
          this.Router.navigate(['/']);
         }, 5000);
      }
    }); 
  }
  
  // CheckBox Mapping For Newsletter
  onChangeNewsLetter(email: string, isChecked: boolean) {
    const newsLetterFormArray = <FormArray>this.verifyForm.controls.maling_list;
    if (isChecked) {
      newsLetterFormArray.push(new FormControl(email));
      this.newsLetterMessage = false; 
    } else {
      let index = newsLetterFormArray.controls.findIndex(x => x.value == email)
      newsLetterFormArray.removeAt(index);

      if(newsLetterFormArray.length){
        this.newsLetterMessage = false;
      }else{
        this.newsLetterMessage = true;
      }
    }
  }

  // Confirm Password Function 
  checkIfMatchingPasswords(passwordKey: string, passwordConfirmationKey: string) {
      return (group: FormGroup) => {
        let passwordInput = group.controls[passwordKey];
            let passwordConfirmationInput = group.controls[passwordConfirmationKey];
        if (passwordInput.value !== passwordConfirmationInput.value) {
          return passwordConfirmationInput.setErrors({notEquivalent: true})
        }
        else {
            return passwordConfirmationInput.setErrors(null);
        }
      }
    }

  //  Check Box Minimum One Select Validation
    minSelectedCheckboxes(min = 1) {
      const validator: ValidatorFn = (formArray: FormArray) => {
        const totalSelected = formArray.controls
          .map(control => control.value)
          .reduce((prev, next) => next ? prev + next : prev, 0); 
        return totalSelected >= min ? null : { required: true };
      };
 
      return validator;
    }
}

