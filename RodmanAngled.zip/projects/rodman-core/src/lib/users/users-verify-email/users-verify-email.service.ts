import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { RodmanCoreService } from '../../rodman-core.service';
import * as configVar from '../../rodman-core.service';

@Injectable({
  providedIn: 'root'
})
export class UsersVerifyEmailService {

  constructor(private HttpClient: HttpClient,private RodmanCoreService : RodmanCoreService ) { }

  UserDeatils(userData) {
    
    var data = {
      magazineId: userData.magazineId,
      id: userData.id,
      firstName: userData.firstName,
      lastName: userData.lastName,
      password: userData.password,
      formData: '',
      maling_list: ''
    }
    
    return this.HttpClient.post<any>(configVar.apiURL+'usersController/usersRegistration',data,configVar.httpOptions ).pipe(
      catchError(this.RodmanCoreService.handleError)
    );
  }



  verifyUser(magazineId,passKey,webUserName) {
    return this.HttpClient.post<any>(configVar.apiURL+'usersController/verification',{magazineId:magazineId,passKey:passKey,webUserName:webUserName},configVar.httpOptions ).pipe(
      catchError(this.RodmanCoreService.handleError)
    );
  }


}
