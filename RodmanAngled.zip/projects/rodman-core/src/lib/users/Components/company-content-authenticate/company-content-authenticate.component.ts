import { Component, OnInit } from '@angular/core';
import { Input, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { RodmanCoreService } from '../../../rodman-core.service';

@Component({
  selector: 'CoreLib-company-content-authenticate',
  templateUrl: './company-content-authenticate.component.html',
  styleUrls: ['./company-content-authenticate.component.css']
})
export class CompanyContentAuthenticateComponent implements OnInit {
  @Input() sendParentMessage: any;
  @Input() link: string;
  constructor(public Router:Router,public RodmanCoreService:RodmanCoreService) { }

  ngOnInit() {
  }

  downloadFile(filePath){
     var newWindow = window.open(filePath);

  }

}
