import { Component, OnInit } from '@angular/core';
import { Router, RouterModule ,ActivatedRoute} from '@angular/router';


@Component({
  selector: 'CoreLib-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {
message= false;
magazineId;
mymsg;
constructor(private ActivatedRoute: ActivatedRoute) { 

}

ngOnInit() {
  this.ActivatedRoute.data.subscribe(data => {
    this.magazineId=data.magazineId;
});

  if(localStorage.getItem('authDetails'+this.magazineId)){
    const data = JSON.parse(localStorage.getItem('authDetails'+this.magazineId));
    this.message =true;
  }else{
     
  }
}

}

