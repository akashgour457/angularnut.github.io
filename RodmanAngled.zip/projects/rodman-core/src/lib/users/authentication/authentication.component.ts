import { Component, OnInit , ViewEncapsulation,ElementRef } from '@angular/core';
import { Router, RouterModule } from '@angular/router';

import {NgbModal, ModalDismissReasons,NgbModalRef} from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormBuilder,Validators } from  '@angular/forms';
import { AuthenticationService } from './authentication.service';




@Component({
  selector: 'CoreLib-authentication',
  templateUrl: './authentication.component.html',
  styleUrls: ['./authentication.component.css'],
  inputs: [ 'magazineId', 'groupId','fieldId','formId'],
})

export class AuthenticationComponent implements OnInit {
  public privacyPolicy = "/privacy-policy"; 
  public termsConditions = "/terms-and-conditions/"; 
  public profile = "/profile"; 
  magazineId;
  groupId;
  fieldId;
  formId;
  modalOpen: boolean = true;
  showMsgRegistration: boolean = false;
  showMsgRegistrationFail: boolean = false;
  showMsgLoginSucess: boolean = false;
  showMsgLoginFail: boolean = false;
  loginMenuChange = false;
  submitted: boolean;
  loginForm: FormGroup;
  registerForm: FormGroup;
  closeResult: string;
  
  constructor(private modalService: NgbModal,private formBuilder: FormBuilder,private AuthenticationService: AuthenticationService,public Router:Router) {   }

  openLogin(login) {
      this.modalService.open(login, { centered: true }); 
  }

  openRegister(register) {
      this.modalService.open(register, { centered: true });
  }

  

  ngOnInit() {
     //Check Login User
    if(localStorage.getItem('authDetails'+this.magazineId)){
      const data = JSON.parse(localStorage.getItem('authDetails'+this.magazineId));
      this.loginMenuChange =true;
    }else{
       
    }
    
    //Registor Form
    this.registerForm = this.formBuilder.group({
      email: ['', [Validators.required,Validators.email]],     
      company_name: ['', Validators.required],
      weekly_enewsletter:['',Validators.required],
      special_promotions:['',Validators.required],
      group_id_company_name:['',Validators.required],
      field_id_company_name:['',Validators.required],
      form_id_company_name:['',Validators.required],
      magazineId:['',Validators.required],
      url:location.origin+'/user/verifyUser/',
      
    });
    
    // Login Form
    this.loginForm = this.formBuilder.group({
      email: ['',[Validators.required,Validators.email]],  
      password: ['',Validators.required],
      magazineId:  ['',Validators.required]
    });

  }
  
  //User Login  Function
  onSubmit() {
    this.submitted = true
    if (this.loginForm.invalid) {
      return;
    }
    this.AuthenticationService.userLogin(this.loginForm.value).subscribe((data)=>{
        if(data.status =="success" && data.message =="login successfully" ){
          localStorage.setItem('authDetails'+this.magazineId, JSON.stringify(data.data));
          this.showMsgLoginSucess= true;
          this.loginMenuChange =true;
          this.modalService.dismissAll(this.loginForm.value);
          this.Router.navigateByUrl(this.profile);   
          setTimeout (() => {      
            this.showMsgLoginSucess =false;
          }, 5000);          
        }else{
          this.showMsgLoginFail =true;
          setTimeout (() => {      
            this.showMsgLoginFail =false;
          }, 5000);          
        }
    }); 
  }
  // Validation Check Both Form
  get registerVal() { 
    return this.registerForm.controls; 
  }
  get loginVal() { 
    return this.loginForm.controls; 
  }

  // Registration User 
  signup(){
    this.submitted = true;   
    if (this.registerForm.invalid) {
      return;
    }
    this.AuthenticationService.userSignUp(this.registerForm.value).subscribe((data)=>{
      if(data.status =="success" && data.message =="You are almost registered" && data.registerStatus=="success" ){
         this.showMsgRegistration = true;       
         setTimeout (() => {    
          this.showMsgRegistration = false;  
          this.modalService.dismissAll(this.registerForm.value);
         }, 5000);  
      }
    }); 
  }

  // Logout Session
  logOut(){
    localStorage.clear();
    this.loginMenuChange =false;
    this.Router.navigateByUrl('');
  }


}