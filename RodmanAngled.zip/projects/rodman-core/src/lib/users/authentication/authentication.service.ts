import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import * as configVar from '../../rodman-core.service';
import { RodmanCoreService } from '../../rodman-core.service';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  errorData: {};
  

  constructor(private HttpClient: HttpClient,private RodmanCoreService:RodmanCoreService ) { }
  
  userSignUp(data) {
    //  Change Url For Register
    return this.HttpClient.post<any>(configVar.apiURL+'usersController/signUpNewsletter',data, configVar.httpOptions).pipe(
      catchError(this.RodmanCoreService.handleError)
    );
  }

  userLogin(data) {
    //  Change Url For Login
    return this.HttpClient.post<any>(configVar.apiURL+'usersController/userLogin',data, configVar.httpOptions).pipe(
      catchError(this.RodmanCoreService.handleError)
    );
  }
}
