import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { Router ,RouterModule } from '@angular/router';

// import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import  {  FormsModule,  ReactiveFormsModule  }  from  '@angular/forms';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { ModalModule } from 'ngx-bootstrap/modal';
import { CookieService } from 'ngx-cookie-service';
import {RodmanORMModule} from 'rodman-orm';


import { UsersRoutingModule } from './users-routing.module';
import { UsersVerifyEmailComponent } from './users-verify-email/users-verify-email.component';
import { UserProfileComponent } from './Components/user-profile/user-profile.component';
import { CompanyContentAuthenticateComponent } from './Components/company-content-authenticate/company-content-authenticate.component';
// import { AuthenticationComponent } from './authentication/authentication.component';



@NgModule({
  declarations: [ UsersVerifyEmailComponent, UserProfileComponent, CompanyContentAuthenticateComponent],
  imports: [
    CommonModule,
    UsersRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    NgbModule,
    ModalModule.forRoot(),
    RodmanORMModule,
    RouterModule
    
  ],
  providers: [CookieService],
  exports: [UsersVerifyEmailComponent,UserProfileComponent,CompanyContentAuthenticateComponent]
})
export class UsersModule { }
