import { NgModule } from '@angular/core';
import { RodmanCoreComponent } from './rodman-core.component';
import { HttpClientModule } from '@angular/common/http';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
// import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { RodmanCoreService} from './rodman-core.service';
import  {  FormsModule,  ReactiveFormsModule  }  from  '@angular/forms';
import { ModalModule } from 'ngx-bootstrap/modal';
import { CookieService } from 'ngx-cookie-service';
import { CarouselModule } from 'ngx-bootstrap';
// import { Ng2DeviceDetectorModule } from 'ng2-device-detector';
import { DfpModule } from 'ngx-dfp';






@NgModule({
  declarations: [RodmanCoreComponent],
  imports: [
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    NgbModule,
    // AngularFontAwesomeModule,
    ModalModule.forRoot(),
    CarouselModule.forRoot(),
    // Ng2DeviceDetectorModule.forRoot(),
    DfpModule.forRoot({
      idleLoad: true,
      enableVideoAds: true,
      personalizedAds: true, // Request personalized ads by default
      singleRequestMode: true, // Only applies to initial refresh
      onSameNavigation: 'refresh',
      globalTargeting: {
        // food: ['NUT', 'HOME']
      }
    })   
    
    
  ],
  exports: [RodmanCoreComponent,NgbModule,ModalModule,CarouselModule],
  providers: [{ provide: NgbModule},{provide:RodmanCoreService},{provide:CookieService}],
})
export class RodmanCoreModule { }


