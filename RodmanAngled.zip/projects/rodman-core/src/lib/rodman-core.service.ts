import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { throwError, from } from 'rxjs';
import { catchError ,map } from 'rxjs/operators';
import {Observable} from 'rxjs';
import { DomSanitizer} from '@angular/platform-browser';
import { Event,NavigationEnd,Router} from '@angular/router';    
import {Ads } from './ads';

'use strict';

export const apiURL='http://3.85.159.45:8042/';
export const httpOptions ={ headers: new HttpHeaders({'Content-Type': 'application/json','Authorization': 'Basic YWRtaW46YWRtaW5AMTIz'}) };  
export const  magazineNameDetails =  { 
                              'NUT':{ id:'1'  ,name:'Nutraceuticals world'} , 
                              'CW' :{ id:'5'  ,name:'Coating World'},
                              'MPO':{ id:'6'  ,name:'Medical Product Outsourcing'},
                              'CP' :{ id:'7'  ,name:'Contract Pharma'}, 
                              'BP' :{ id:'8'  ,name:'Beauty Packaging'},
                              'HAP':{ id:'9'  ,name:'Happi'},
                              'INK':{ id:'10' ,name:'Ink World'},
                              'LNW':{ id:'11' ,name:'Label & Narrow Web'},
                              'NON':{ id:'13' ,name:'Nonwovens Industry'},                
                              'ODT':{ id:'14' ,name:'Orthopedic Design & Technology'}, 
                              'PEN':{ id:'15' ,name:'Printed Electronics Now'},               
                            };
export const  magazineIds =  { 
                                  '1' :{ id:'NUT' ,name:'Nutraceuticals world'} , 
                                  '5' :{ id:'CW'  ,name:'Coating World'},
                                  '6' :{ id:'MPO' ,name:'Medical Product Outsourcing'},
                                  '7' :{ id:'CP'  ,name:'Contract Pharma'}, 
                                  '8' :{ id:'BP'  ,name:'Beauty Packaging'},
                                  '9' :{ id:'HAP' ,name:'Happi'},
                                  '10':{ id:'INK' ,name:'Ink World'},
                                  '11':{ id:'LNW' ,name:'Label & Narrow Web'},
                                  '13':{ id:'NON' ,name:'Nonwovens Industry'},                
                                  '14':{ id:'ODT' ,name:'Orthopedic Design & Technology'}, 
                                  '15':{ id:'PEN' ,name:'Printed Electronics Now'},               
                                };

export const IMAGE_DOMAIN  = "http://dev.rodpub.com/images/";
export const DEFAULT_IMAGE = "http://kaverisias.com/wp-content/uploads/2018/01/catalog-default-img.gif";                    

@Injectable({
  providedIn: 'root'
})

export class RodmanCoreService {
  errorData: {};
  currentURL;
  getAllAdsData; 
  collectoionAds:any=[]; 
  finalArray :any=[];

  constructor(public HttpClient: HttpClient,public sanitizer: DomSanitizer,public Router:Router){
    Router.events.subscribe(event => {
      if (event instanceof NavigationEnd ) {
        this.currentURL = event.url; 
      }
    });
  }



  displayImageUrl(imageId) {
    imageId = imageId.toString();
    let folderName = imageId.substring(0, 3); 
    let imageName  = imageId.substring(3); 
    return (imageId!='0') ? IMAGE_DOMAIN+folderName+"/"+imageName+'_main.jpg' : DEFAULT_IMAGE;   
  }

  displayImageThumbURL(imageId) {
    imageId = imageId.toString();
    let folderName = imageId.substring(0, 3); 
    let imageName  = imageId.substring(3); 
    return (imageId!='0') ? IMAGE_DOMAIN+folderName+"/"+imageName+'_thumb.jpg' : DEFAULT_IMAGE;   
  }
        

  returnUrl(){
    return this.currentURL;
  } 

  getAllAdst(magazineId){
    return this.HttpClient.post<any>(apiURL+'adsController/getAds',{magazineId:magazineId,pageUrl:this.currentURL},httpOptions);   
  }


  
  getAdcode(str){
    str = str.replace(/\'/g,'');
    str = str.replace(/\\/g,'');
    var firstIndex = str.indexOf("script") + 10;
    var lastIndex = str.indexOf("/script>");
    str = str.substring(firstIndex,lastIndex);
    if(str.indexOf('defineSlot') < 0)
        return false;
    var slot = str.substring(str.indexOf("defineSlot(")+11,  str.indexOf(").addService"));
    var slotvalue = slot.split(',')[0]
    var code = {
        slot: slotvalue,
        sizes: str.substring( str.lastIndexOf("[[")+1,  str.lastIndexOf("]]")+1 ),
        key: str.substring( str.lastIndexOf('setTargeting("')+14,  str.lastIndexOf('",') ),
        value : str.substring( str.lastIndexOf('",[')+4,  str.lastIndexOf('])') )
    }
    return code
}

  safeHtml(data) {
    return this.sanitizer.bypassSecurityTrustHtml(data);
  } 

  safeHtmlReplace(data){
    return data.replace(/[^a-zA-Z0-9.()'"$@&!?:, ]/g, "").replace('&amp;',' & ').replace('&amp',' & ').replace("\'","'");    
  }

  bodyCharacterLength(data){
    data = data.replace(/<(.|\n)*?>/g, '').substring(0, 200);
    return  data;
  }

  extractNameFromJson(obj){
    if (/^[\],:{}\s]*$/.test(obj.replace(/\\["\\\/bfnrtu]/g, '@').
    replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, ']').
    replace(/(?:^|:|,)(?:\s*\[)+/g, ''))) {    
      obj = JSON.parse(obj);
      return (obj.name) ? 'By '+obj.name +' '+ obj.title + ' .'  : '';    
    }else{
      return (obj) ? "By "+obj: '  ' ; 
    }


  }
  handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      console.error(`Backend returned code ${error.status}, ` + `body was: ${error.error}`);
    }
    // return an observable with a user-facing error message
    this.errorData = {
      errorTitle: 'Oops! Request for document failed',
      errorDesc: 'Something bad happened. Please try again later.'
    };
    return throwError(this.errorData);
  }
}
