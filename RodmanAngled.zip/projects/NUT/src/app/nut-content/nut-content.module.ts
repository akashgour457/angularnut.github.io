import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NutContentRoutingModule } from './nut-content-routing.module';
// import { ContentViewComponent } from './content-view/content-view.component';
import { ContentListComponent } from './content-list/content-list.component';
import { ContentsModule,HomeModule, SitesModule,AdsModule,TaxonomiesModule} from 'rodman-core';
import { DfpModule } from 'ngx-dfp';



@NgModule({
  declarations: [ ContentListComponent],
  imports: [
    CommonModule,
    NutContentRoutingModule,
    TaxonomiesModule,
    HomeModule,
    SitesModule,
    ContentsModule,
    CommonModule,    
    AdsModule,
    DfpModule.forRoot({
      idleLoad: true,
      enableVideoAds: true,
      personalizedAds: true, // Request personalized ads by default
      singleRequestMode: true, // Only applies to initial refresh
      onSameNavigation: 'refresh',
      globalTargeting: {
        // food: ['NUT', 'HOME']
      }
    })  
 
  ]
})
export class NutContentModule { }
