import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'NUT-user-mail-verify',
  templateUrl: './user-mail-verify.component.html',
  styleUrls: ['./user-mail-verify.component.css']
})
export class UserMailVerifyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
