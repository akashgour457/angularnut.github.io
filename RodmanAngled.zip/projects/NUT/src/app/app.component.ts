import { Component ,  OnInit} from '@angular/core';
import { Router, NavigationEnd,ActivatedRoute } from '@angular/router';
import { environment } from '../environments/environment';

@Component({
  selector: 'NUT-root',
  templateUrl: './app.component.html',
  styles: []
})
export class AppComponent implements OnInit {
  title = 'NUT'; 
  magazineId ;
  magazineName;
  currentURL;
  
  constructor (public Router : Router ,public ActivatedRoute:ActivatedRoute){
    Router.events.subscribe(event => {
      if (event instanceof NavigationEnd ) {
        this.currentURL = event.url; 
      }
    });

    Router.events.subscribe((ev) => {
    });
    this.magazineId= environment.magazineId;
    this.magazineName = environment.magazineName;
  }

  ngOnInit() {
    this.ActivatedRoute.url.subscribe(url =>{ 
      this.currentURL = url[0].path;
    });
  }

  
  ngOnChanges (){    
  }


}
