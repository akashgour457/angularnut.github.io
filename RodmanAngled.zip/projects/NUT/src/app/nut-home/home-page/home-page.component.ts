import { Component, OnInit } from '@angular/core';
import { environment} from '../../../environments/environment';
import { RodmanCoreService } from '../../../../../rodman-core/src/lib/rodman-core.service';

@Component({
  selector: 'NUT-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.css']
})
export class HomePageComponent implements OnInit {
  magazineId;
  magazineName;
  homeBoxId;
  viewAdRender:number;
  getAllAd:any=[];
  
  constructor(public RodmanCoreService:RodmanCoreService) { 
    this.magazineId = environment.magazineId;
    this.homeBoxId = environment.homeBoxId;
    this.magazineName = environment.magazineName;
    this.RodmanCoreService.getAllAdst(this.magazineId).subscribe((data =>{
      this.getAllAd = data;
      this.viewAdRender = 1;
   }))

  }

  ngOnInit() {
  }

}
