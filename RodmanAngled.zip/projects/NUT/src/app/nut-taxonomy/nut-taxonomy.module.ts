import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NutTaxonomyRoutingModule } from './nut-taxonomy-routing.module';
import { TaxonomyListComponent } from './taxonomy-list/taxonomy-list.component';
import { ContentsModule,HomeModule, SitesModule,AdsModule,TaxonomiesModule} from 'rodman-core';
import { DfpModule } from 'ngx-dfp';


@NgModule({
  declarations: [TaxonomyListComponent],
  imports: [
    CommonModule,
    NutTaxonomyRoutingModule, ContentsModule,HomeModule, SitesModule,AdsModule,TaxonomiesModule,
    DfpModule.forRoot({
      idleLoad: true,
      enableVideoAds: true,
      personalizedAds: true, // Request personalized ads by default
      singleRequestMode: true, // Only applies to initial refresh
      onSameNavigation: 'refresh',
      globalTargeting: {
        // food: ['NUT', 'HOME']
      }
    }) 

  ]
})
export class NutTaxonomyModule { }
