import { Component, OnInit } from '@angular/core';
import { Router ,NavigationEnd } from '@angular/router'; 
import { environment}  from '../../../environments/environment';
import { RodmanCoreService } from '../../../../../rodman-core/src/lib/rodman-core.service';
 

@Component({
  selector: 'cw-cw-content-list',
  templateUrl: './cw-content-list.component.html',
  styleUrls: ['./cw-content-list.component.css']
})
export class CwContentListComponent implements OnInit {
  magazineId;
  TabOne; 
  TabTwo;
  currentURL : any ;
  contentType;
  getAllAd:any=[];
  viewAdRender:number;

  constructor(private router:Router,public RodmanCoreService:RodmanCoreService) {
    this.magazineId=environment.magazineId;
    this.TabOne = environment.TabOne;
    this.TabTwo = environment.TabTwo;
       router.events.subscribe(event => {
        if (event instanceof NavigationEnd ) {
          this.currentURL = event.url; 

          if(this.currentURL=='/contents/list_webinars'){
            this.currentURL= '';
            this.contentType = '2542';
          }else if(this.currentURL=='/research'){
            this.currentURL= '';
            this.contentType = '2499,2488,2557';
          }          
        }
      });

      this.RodmanCoreService.getAllAdst(this.magazineId).subscribe((data =>{
        this.getAllAd = data;
        this.viewAdRender = 1;
     }))

      
   }

  ngOnInit() {
    
  }

}