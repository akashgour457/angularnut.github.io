import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CwContentRoutingModule } from './cw-content-routing.module';
import { CwContentListComponent } from './cw-content-list/cw-content-list.component';
import { ContentsModule ,HomeModule,SitesModule,AdsModule,HeapsModule} from 'rodman-core';
import { DfpModule } from 'ngx-dfp';


@NgModule({
  declarations: [ CwContentListComponent ],
  imports: [
    CommonModule,
    CwContentRoutingModule,
    ContentsModule,
    HomeModule,
    SitesModule,
    AdsModule,
    HeapsModule,    
    DfpModule.forRoot({
      idleLoad: true,
      enableVideoAds: true,
      personalizedAds: true, // Request personalized ads by default
      singleRequestMode: true, // Only applies to initial refresh
      onSameNavigation: 'refresh',
      globalTargeting: {
        // food: ['NUT', 'HOME']
      }
    })  

  ]
})
export class CwContentModule { }
