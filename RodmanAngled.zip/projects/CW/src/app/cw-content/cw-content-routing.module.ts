import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CwContentListComponent } from './cw-content-list/cw-content-list.component';



const routes: Routes = [
  { path : "", component: CwContentListComponent  },
  { path : ":any", component: CwContentListComponent  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CwContentRoutingModule { }
