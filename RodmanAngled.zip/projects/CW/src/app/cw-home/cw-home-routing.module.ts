import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CwHomePageComponent } from './cw-home-page/cw-home-page.component';



const routes: Routes = [
  {path:"",component:CwHomePageComponent},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CwHomeRoutingModule { }
