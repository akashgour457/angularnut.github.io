import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CwHomeRoutingModule } from './cw-home-routing.module';
import { CwHomePageComponent } from './cw-home-page/cw-home-page.component';
import { HttpClientModule } from '@angular/common/http';
import {HomeModule,SitesModule,ContentsModule,AdsModule} from 'rodman-core';
import { DfpModule } from 'ngx-dfp';



@NgModule({
  declarations: [CwHomePageComponent],
  imports: [
    CommonModule,
    HttpClientModule,
    CwHomeRoutingModule,HomeModule,SitesModule,ContentsModule,AdsModule,
    DfpModule.forRoot({
      idleLoad: true,
      enableVideoAds: true,
      personalizedAds: true, // Request personalized ads by default
      singleRequestMode: true, // Only applies to initial refresh
      onSameNavigation: 'refresh',
      globalTargeting: {
      }
    })  
  ]
})
export class CwHomeModule { }
