import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CwUserRoutingModule } from './cw-user-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    CwUserRoutingModule
  ]
})
export class CwUserModule { }
