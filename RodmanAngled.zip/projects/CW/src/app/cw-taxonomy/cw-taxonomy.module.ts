import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CwTaxonomyRoutingModule } from './cw-taxonomy-routing.module';
import { CwTaxonomyListComponent } from './cw-taxonomy-list/cw-taxonomy-list.component';
import { ContentsModule ,AdsModule ,TaxonomiesModule } from 'rodman-core';
import { DfpModule } from 'ngx-dfp';


@NgModule({
  declarations: [CwTaxonomyListComponent],
  imports: [
    CommonModule,
    CwTaxonomyRoutingModule,
    TaxonomiesModule,
    ContentsModule,
    AdsModule,
    DfpModule.forRoot({
      idleLoad: true,
      enableVideoAds: true,
      personalizedAds: true, // Request personalized ads by default
      singleRequestMode: true, // Only applies to initial refresh
      onSameNavigation: 'refresh',
      globalTargeting: {
        // food: ['NUT', 'HOME']
      }
    })  
  ]
})
export class CwTaxonomyModule { }
