import { Component } from '@angular/core';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { Router, NavigationEnd } from '@angular/router';

@Component({
  selector: 'odt-root',
  template: `<CoreLib-header magazineId="14" magazineName="ODT" menuId='90' groupId='77' fieldId='329' formId='66'></CoreLib-header>
  <router-outlet></router-outlet><CoreLib-footer magazineId="14" magazineName="ODT"></CoreLib-footer>`,
  styles: []
})
export class AppComponent {
  title = 'ODT';
  constructor (private spinnerService: Ng4LoadingSpinnerService,private Router : Router){

    this.Router.events.subscribe((ev) => {
      if (ev instanceof NavigationEnd) { 
        // this.spinner();
      }
    });
  }
  spinner(){
    this.spinnerService.show();
    setTimeout(()=>this.spinnerService.hide(),6000)
  }
}


// <ng4-loading-spinner></ng4-loading-spinner>