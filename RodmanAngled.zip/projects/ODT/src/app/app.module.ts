import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';
import { ContentTopCompanyComponent } from '../../src/app/content/content-top-company/content-top-company.component';

// Rodman Core Import
  import {HomeModule,SitesModule,ContentsModule,UsersModule,TaxonomiesModule,AdsModule,DirectorySectionModule,HeapsModule} from 'rodman-core';
  import { DfpModule } from 'ngx-dfp';
  import { NotFoundComponent } from '../../../rodman-core/src/lib/sites/components/not-found/not-found.component';
  import { UserProfileComponent } from '../../../rodman-core/src/lib/users/Components/user-profile/user-profile.component';
  import { StaticContentComponent } from "../../../rodman-core/src/lib/contents/static-content/static-content.component";
  import { ContentSearchComponent } from '../../../rodman-core/src/lib/contents/content-search/content-search.component';
  import { ContentIssueComponent } from "../../../rodman-core/src/lib/contents/content-issue/content-issue.component";
  import { ContentRssFeedsComponent } from "../../../rodman-core/src/lib/contents/content-rss-feeds/content-rss-feeds.component";
  import { DirectoryHomePageComponent} from "../../../rodman-core/src/lib/directory-section/directory-home-page/directory-home-page.component";
  import { ContentInfographicsComponent } from "../../../rodman-core/src/lib/contents/content-infographics/content-infographics.component";
  import { ContentsWebinarComponent } from '../../../rodman-core/src/lib/contents/contents-webinar/contents-webinar.component';


// import { ViewContentComponent } from './view-content/view-content.component';
import { UserMailVerifyComponent } from './user/component/user-mail-verify/user-mail-verify.component';
import { ContentViewComponent } from './content/content-view/content-view.component';
import { from } from 'rxjs';





@NgModule({
  declarations: [
    ContentTopCompanyComponent,
    AppComponent,
    NotFoundComponent,
    ContentSearchComponent,
    UserProfileComponent,    
    StaticContentComponent,
    UserMailVerifyComponent,
    ContentViewComponent,
    ContentIssueComponent,
    DirectoryHomePageComponent,
    ContentRssFeedsComponent,
    ContentInfographicsComponent,
    ContentsWebinarComponent,    
    // TopCompanyHomePageComponent,
  ],
  imports: [
    Ng4LoadingSpinnerModule.forRoot(),
    BrowserModule,
    AppRoutingModule,
    DirectorySectionModule,
    HttpClientModule,
    AngularFontAwesomeModule,
    HomeModule,
    SitesModule,
    UsersModule,
    TaxonomiesModule,
    ContentsModule,
    AdsModule,    
    HeapsModule,
    DfpModule.forRoot({
      idleLoad: true,
      enableVideoAds: true,
      personalizedAds: true, // Request personalized ads by default
      singleRequestMode: true, // Only applies to initial refresh
      onSameNavigation: 'refresh',
      globalTargeting: {
        // food: ['NUT', 'HOME']
      }
    })  
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
