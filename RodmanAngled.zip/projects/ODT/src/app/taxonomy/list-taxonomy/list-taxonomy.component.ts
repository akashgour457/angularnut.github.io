import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router'; 
import{ environment } from '../../../environments/environment';
import { RodmanCoreService } from '../../../../../rodman-core/src/lib/rodman-core.service';

@Component({
  selector: 'odt-list-taxonomy',
  templateUrl: './list-taxonomy.component.html',
  styleUrls: ['./list-taxonomy.component.css']
})
export class ListTaxonomyComponent implements OnInit {
  public magazineId;
  currentURL : any ;
  getAllAd:any=[];
  viewAdRender:number;
  constructor(private router:Router,public RodmanCoreService:RodmanCoreService) {
       this.magazineId = environment.magazineId;   
       router.events.subscribe(event => {
        if (event instanceof NavigationEnd ) {
          this.currentURL = event.url; 
        }
      });
  
      this.RodmanCoreService.getAllAdst(this.magazineId).subscribe((data =>{
        this.getAllAd = data;
        this.viewAdRender = 1;
     }))
   }

  ngOnInit() {    
  }


}

