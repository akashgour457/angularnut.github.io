import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import {HomeModule} from 'rodman-core';
import {SitesModule} from 'rodman-core';
import {ContentsModule,AdsModule} from 'rodman-core';
import { DfpModule } from 'ngx-dfp';

import { ODTHomeRoutingModule } from './odt-home-routing.module';
import { HomePageComponent } from './components/home-page/home-page.component';
import { FeaturedContentComponent } from './components/featured-content/featured-content.component';


@NgModule({
  declarations: [HomePageComponent, FeaturedContentComponent],
  imports: [
    CommonModule,
    ODTHomeRoutingModule,
    HomeModule,
    SitesModule,
    HttpClientModule,
    ContentsModule,
    AdsModule,
    DfpModule.forRoot({
      idleLoad: true,
      enableVideoAds: true,
      personalizedAds: true, // Request personalized ads by default
      singleRequestMode: true, // Only applies to initial refresh
      onSameNavigation: 'refresh',
      globalTargeting: {
        // food: ['NUT', 'HOME']
      }
    })  
  ]
})
export class ODTHomeModule { }
