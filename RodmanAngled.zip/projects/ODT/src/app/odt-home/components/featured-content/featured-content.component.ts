import { Component, OnInit } from '@angular/core';
import {Router, ActivatedRoute} from "@angular/router";
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'odt-featured-content',
  templateUrl: './featured-content.component.html',
  styleUrls: ['./featured-content.component.css']
})
export class FeaturedContentComponent implements OnInit {

  slug:any;
  url: any;
  constructor(public HttpClient: HttpClient ,private  ActivatedRoute:ActivatedRoute , private Router: Router) {
    this.ActivatedRoute.params.subscribe(params => {
      this.url = this.Router.url;
      this.url = this.url.split('/');
      this.url = this.url.slice(1);
    });
  }

  ngOnInit() {
  }

}
