import { Component, OnInit } from '@angular/core';
import { Router ,NavigationEnd } from '@angular/router'; 
import { environment}  from '../../../environments/environment';
import { RodmanCoreService } from '../../../../../rodman-core/src/lib/rodman-core.service';


@Component({
  selector: 'odt-list-content',
  templateUrl: './list-content.component.html',
  styleUrls: ['./list-content.component.css']
})
export class ListContentComponent implements OnInit {
  magazineId;
  currentURL : any ;
  contentType;
  getAllAd:any=[];
  viewAdRender:number;

  constructor(private router:Router,public RodmanCoreService:RodmanCoreService) {
    this.magazineId=environment.magazineId;
       router.events.subscribe(event => {
        if (event instanceof NavigationEnd ) {
          this.currentURL = event.url; 

          if(this.currentURL=='/contents/list_webinars'){
            this.currentURL= '';
            this.contentType = '2542';
          }          
        }
      });

      this.RodmanCoreService.getAllAdst(this.magazineId).subscribe((data =>{
        this.getAllAd = data;
        this.viewAdRender = 1;
     }))

      
   }

  ngOnInit() {
    
  }

}
