import { Component, OnInit } from '@angular/core';
import { Router ,NavigationEnd } from '@angular/router'; 
import { environment } from '../../../environments/environment';

@Component({ 
  selector: 'odt-content-top-company',
  templateUrl: './content-top-company.component.html',
  styleUrls: ['./content-top-company.component.css']
})
export class ContentTopCompanyComponent implements OnInit {

  contentPageUrl : any ;
  public magazineId :any;
  constructor(private router:Router) {
    this.magazineId = environment.magazineId ;
       router.events.subscribe(event => {
        if (event instanceof NavigationEnd ) {
          this.contentPageUrl = event.url;         
        }
      });
   }
  ngOnInit() {
  }

}
