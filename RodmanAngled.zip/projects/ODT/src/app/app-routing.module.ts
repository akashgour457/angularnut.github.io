import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
// import { ViewContentComponent } from './view-content/view-content.component';
import { environment } from '../environments/environment';
import { UserMailVerifyComponent } from './user/component/user-mail-verify/user-mail-verify.component';
import { ContentViewComponent } from './content/content-view/content-view.component';
import { ContentTopCompanyComponent } from '../../src/app/content/content-top-company/content-top-company.component';


// Rodman Core Import
 import { ContentSearchComponent } from '../../../rodman-core/src/lib/contents/content-search/content-search.component';
 import { NotFoundComponent } from '../../../rodman-core/src/lib/sites/components/not-found/not-found.component';
 import { UserProfileComponent } from '../../../rodman-core/src/lib/users/Components/user-profile/user-profile.component';
 import { StaticContentComponent } from "../../../rodman-core/src/lib/contents/static-content/static-content.component";
 import { ContentIssueComponent } from "../../../rodman-core/src/lib/contents/content-issue/content-issue.component";
 import { ContentRssFeedsComponent } from "../../../rodman-core/src/lib/contents/content-rss-feeds/content-rss-feeds.component";
 import { DirectoryHomePageComponent} from "../../../rodman-core/src/lib/directory-section/directory-home-page/directory-home-page.component";
 import { ContentInfographicsComponent } from "../../../rodman-core/src/lib/contents/content-infographics/content-infographics.component";
 import { ContentsWebinarComponent } from '../../../rodman-core/src/lib/contents/contents-webinar/contents-webinar.component';



const routes: Routes = [
  {path: "", pathMatch: 'full' , loadChildren: () =>import('./odt-home/odt-home.module').then (m=>m.ODTHomeModule)},
// Search Content 
   {path:  'contents/list_webinars', component:ContentsWebinarComponent,data: {magazineId: environment.magazineId }},
   {path:  'contents/list_infographics', component:ContentInfographicsComponent,data: {magazineId: environment.magazineId }},  
   {path:  'contents/list_industry-events', component:ContentInfographicsComponent,data: {magazineId: environment.magazineId }},

   {path:  'contents/list_ebook', component:NotFoundComponent},

   {path:  'contents/searchcontent/:any/:slug', component:ContentSearchComponent,data: {magazineId: environment.magazineId }},
   {path:  'contents/searchcontent/:any', component:ContentSearchComponent,data: {magazineId: environment.magazineId }},
//View Page Content  
  {path:  'contents/:any/:any/:any', component:ContentViewComponent},
  {path:  'issues/:any/:any/:any', component:ContentViewComponent}, 

//Taxonomy
  {path: 'departments',loadChildren: () =>import('./taxonomy/taxonomy.module').then (m=>m.TaxonomyModule)},
  {path: 'departments/:any',loadChildren: () =>import('./taxonomy/taxonomy.module').then (m=>m.TaxonomyModule)},
  
  {path: 'news',loadChildren: () =>import('./taxonomy/taxonomy.module').then (m=>m.TaxonomyModule)},
  {path: 'news/:any',loadChildren: () =>import('./taxonomy/taxonomy.module').then (m=>m.TaxonomyModule)},

  {path: 'markets',loadChildren: () =>import('./taxonomy/taxonomy.module').then (m=>m.TaxonomyModule)},  
  {path: 'markets/:any',loadChildren: () =>import('./taxonomy/taxonomy.module').then (m=>m.TaxonomyModule)},

  {path: 'manufacturing', loadChildren: () =>import('./taxonomy/taxonomy.module').then (m=>m.TaxonomyModule)},
  {path: 'manufacturing/:any', loadChildren: () =>import('./taxonomy/taxonomy.module').then (m=>m.TaxonomyModule)},

  {path: 'live-from-shows', loadChildren: () =>import('./taxonomy/taxonomy.module').then (m=>m.TaxonomyModule)},

// Contents
  {path: 'contents/2539', component : NotFoundComponent},
  {path: 'contents/2487',component : NotFoundComponent},
  {path: 'contents/:any', loadChildren: () =>import('./content/content.module').then (m=>m.ContentModule)}, 

//Static Content
  // {path: 'profile',component : UserProfileComponent},
  {path: 'profile',component : UserProfileComponent,data: {magazineId: environment.magazineId }},
  // {path: 'user/verifyUser/:token/:email',component:UserVerifyComponent},
  {path: 'user/verifyUser/:token/:email',component:UserMailVerifyComponent,},

//View Page Content
//BuyerGuide  
  {path:  'buyersguide',component : DirectoryHomePageComponent,data: {magazineId: environment.magazineId }},
  {path:  'buyersguide/all_companies',component : DirectoryHomePageComponent,data: {magazineId: environment.magazineId }},
// OtherCase 
  {path: 'subscribe-now',component : StaticContentComponent,data: {magazineId: environment.magazineId }},
  {path: 'advertise-with-us',component : StaticContentComponent,data: {magazineId: environment.magazineId }},
  {path: 'enewsletter-archive',component : StaticContentComponent,data: {magazineId: environment.magazineId }},
  {path: 'staff',component : StaticContentComponent,data: {magazineId: environment.magazineId }},
  {path: 'editorial-guidelines',component : StaticContentComponent,data: {magazineId: environment.magazineId }},
  {path: 'terms-and-conditions',component : StaticContentComponent,data: {magazineId: environment.magazineId }},
  {path: 'privacy-policy',component : StaticContentComponent,data: {magazineId: environment.magazineId }},
  {path: 'about-us', component : StaticContentComponent,data: {magazineId: environment.magazineId }},
  {path: 'contact-us', component : StaticContentComponent,data: {magazineId: environment.magazineId }},

//Rss
  {path: 'rssfeeds', component : ContentRssFeedsComponent,data: {magazineId: environment.magazineId }},
  // {path: 'heaps/view/:any',component : NotFoundComponent},
  // {path: 'echo Magazine::latestIssueURL()',      redirectTo: 'issue',      pathMatch: 'full'    },
  {path:  'issues/:slug',component : ContentIssueComponent,data: {magazineId: environment.magazineId }},
  {path:  'heaps/view/:any',component : ContentTopCompanyComponent,data: {magazineId: environment.magazineId }},
  {path:  'heaps/view/:any/:any',component : ContentTopCompanyComponent,data: {magazineId: environment.magazineId }},
  {path:  'heaps/view/:any/:any/:any',component : ContentTopCompanyComponent,data: {magazineId: environment.magazineId }},
  {path: "**", component : NotFoundComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
