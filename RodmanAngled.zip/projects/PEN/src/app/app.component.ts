import { Component ,OnInit } from '@angular/core';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { Router, NavigationEnd,ActivatedRoute } from '@angular/router';
import { environment } from '../environments/environment';

@Component({
  selector: 'pen-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'PEN';
  magazineId ;
  magazineName;
  currentURL;
  
  constructor (public spinnerService: Ng4LoadingSpinnerService,public Router : Router ,public ActivatedRoute:ActivatedRoute){
    Router.events.subscribe(event => {
      if (event instanceof NavigationEnd ) {
        this.currentURL = event.url; 
      }
    });

    Router.events.subscribe((ev) => {
        this.spinner();
    });
    this.magazineId= environment.magazineId;
    this.magazineName = environment.magazineName;
  }

  ngOnInit() {
    this.ActivatedRoute.url.subscribe(url =>{ 
      this.currentURL = url[0].path;

    });
  }

  
  ngOnChanges (){
    
  }
 
  spinner(){
    
    this.spinnerService.show();
    setTimeout(()=>this.spinnerService.hide(),3000)
  }


}
