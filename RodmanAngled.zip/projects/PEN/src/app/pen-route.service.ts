import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, CanActivateChild, Router, ActivatedRoute } from '@angular/router'; 
import { Event,NavigationEnd} from '@angular/router';       

@Injectable({
  providedIn: 'root'
})
export class PenRouteService  implements CanActivate, CanActivateChild  {
  currentURL:any;
  caseVariable:any;
  cases:any;
  contentType:any;
  constructor(private router: Router,private ActivatedRoute : ActivatedRoute) {
  }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
      this.router.events.subscribe((event: Event) => {
        if (event instanceof NavigationEnd ) {
          this.currentURL = event.url;
          this.currentURL = this.currentURL.split("/");
          this.currentURL = this.currentURL.slice(1);
          this.caseVariable = this.currentURL.join('/');

        }
      });
      return true;
    }


    canActivateChild(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
      return this.canActivate(route, state);
    }

    getCurrentRoute(){
        this.router.events.subscribe(event => {
            if (event instanceof NavigationEnd ) {
               return this.currentURL = event.url;             
            }
          });
          return true;
    }


}
