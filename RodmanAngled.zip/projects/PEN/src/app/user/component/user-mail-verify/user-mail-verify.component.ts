import { Component, OnInit } from '@angular/core';
import { Router, RouterModule ,ActivatedRoute} from '@angular/router';
import { environment } from '../../../../environments/environment'



@Component({
  selector: 'pen-user-mail-verify',
  templateUrl: './user-mail-verify.component.html',
  styleUrls: ['./user-mail-verify.component.css']
})
export class UserMailVerifyComponent implements OnInit {
  token;
  email;
  magazineId;
  constructor( private ActivatedRoute: ActivatedRoute) {
      this.ActivatedRoute.params.subscribe(params => {
          this.token = params['token']; 
          this.email = params['email']; 
      });
      this.magazineId =  environment.magazineId;  
   }

  ngOnInit() {
  }

}
