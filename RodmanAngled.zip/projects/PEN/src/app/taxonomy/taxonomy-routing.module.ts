import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListTaxonomyComponent } from './list-taxonomy/list-taxonomy.component';

const routes: Routes = [
  { path : "", component: ListTaxonomyComponent  },
  { path : ":any", component: ListTaxonomyComponent  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TaxonomyRoutingModule { }
