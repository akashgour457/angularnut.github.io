import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute ,NavigationEnd } from '@angular/router';
import { environment} from '../../../environments/environment';
import { RodmanCoreService } from '../../../../../rodman-core/src/lib/rodman-core.service';

@Component({
  selector: 'pen-content-infograpic',
  templateUrl: './content-infograpic.component.html',
  styleUrls: ['./content-infograpic.component.css']
})
export class ContentInfograpicComponent implements OnInit {
  currentURL : any ;
  contentType : any ;
  magazineId;
  getAllAd:any=[];
  viewAdRender:number;


  constructor(private router:Router,public RodmanCoreService:RodmanCoreService) {
       this.magazineId = environment.magazineId;
       router.events.subscribe(event => {
        if (event instanceof NavigationEnd ) {
          this.currentURL = event.url; 
        }
      });

      this.RodmanCoreService.getAllAdst(this.magazineId).subscribe((data =>{
        this.getAllAd = data;
        this.viewAdRender = 1;
    }))
   }

  ngOnInit() {
  }


}