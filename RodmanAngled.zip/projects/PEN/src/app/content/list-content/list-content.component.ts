import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute ,NavigationEnd } from '@angular/router';
import { environment} from '../../../environments/environment';
import { RodmanCoreService } from '../../../../../rodman-core/src/lib/rodman-core.service';


@Component({
  selector: 'pen-list-content',
  templateUrl: './list-content.component.html',
  styleUrls: ['./list-content.component.css']
})
export class ListContentComponent implements OnInit {
  currentURL : any ;
  contentType : any ;
  magazineId;
  getAllAd:any=[];
  viewAdRender:number;


  constructor(private router:Router,public RodmanCoreService:RodmanCoreService) {
       this.magazineId = environment.magazineId;
       router.events.subscribe(event => {
        if (event instanceof NavigationEnd ) {
          this.currentURL = event.url; 
          if(this.currentURL=='/resources'){
              this.currentURL= '';
              this.contentType = '2539,2559,2720,2585,2698,2557';
          }else if(this.currentURL=='/contents/list_webinars'){
              this.currentURL= '';
              this.contentType = '2542';
          }

          // this.RodmanCoreService.getAllAdst(this.magazineId).subscribe((data =>{
          //    this.getAllAd = data;
          //    this.viewAdRender = 1;
          // }))
        }
      });

      this.RodmanCoreService.getAllAdst(this.magazineId).subscribe((data =>{
        this.getAllAd = data;
        this.viewAdRender = 1;
    }))
   }

  ngOnInit() {
  }


}
