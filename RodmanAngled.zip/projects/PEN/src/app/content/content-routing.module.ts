import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListContentComponent } from './list-content/list-content.component';


const routes: Routes = [
  { path : "", component: ListContentComponent  },
  { path : ":any", component: ListContentComponent  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ContentRoutingModule { }
