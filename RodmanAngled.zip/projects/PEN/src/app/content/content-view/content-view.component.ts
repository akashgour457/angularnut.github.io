import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'pen-content-view',
  templateUrl: './content-view.component.html',
  styleUrls: ['./content-view.component.css']
})
export class ContentViewComponent implements OnInit {

  contentPageUrl : any ;
  public magazineId = environment.magazineId;
  constructor(private router: Router, private activatedRoute: ActivatedRoute) {
    this.magazineId = environment.magazineId ;
       router.events.subscribe(event => {
        if (event instanceof NavigationEnd ) {
          this.contentPageUrl = event.url;         
        }
      });
  }


  ngOnInit() {

  }

}
