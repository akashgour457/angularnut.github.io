import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'pen-featured-content',
  templateUrl: './featured-content.component.html',
  styles: []
})
export class FeaturedContentComponent implements OnInit {

  constructor() {   
  }

  ngOnInit() {
  }

}
