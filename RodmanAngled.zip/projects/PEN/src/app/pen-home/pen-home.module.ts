import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';

import {HomeModule} from 'rodman-core';
import {SitesModule} from 'rodman-core';
import {ContentsModule,AdsModule} from 'rodman-core';
import { DfpModule } from 'ngx-dfp';


import { PENHomeRoutingModule } from './pen-home-routing.module';
import { FeaturedContentComponent } from './components/featured-content/featured-content.component';
import { HomePageComponent } from './components/home-page/home-page.component';



@NgModule({
  declarations: [FeaturedContentComponent, HomePageComponent],
  imports: [
    CommonModule,
    PENHomeRoutingModule,
    HomeModule,
    SitesModule,
    HttpClientModule,
    ContentsModule,
    AdsModule,
    DfpModule.forRoot({
      idleLoad: true,
      enableVideoAds: true,
      personalizedAds: true, // Request personalized ads by default
      singleRequestMode: true, // Only applies to initial refresh
      onSameNavigation: 'refresh',
      globalTargeting: {
        // food: ['NUT', 'HOME']
      }
    })  

    
  ]
})
export class PENHomeModule { }
