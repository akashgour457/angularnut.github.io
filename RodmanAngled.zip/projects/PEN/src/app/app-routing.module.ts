import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
// import { ViewContentComponent } from './view-content/view-content.component';
import { environment } from '../environments/environment';
import { UserMailVerifyComponent } from './user/component/user-mail-verify/user-mail-verify.component';
import { ContentViewComponent } from './content/content-view/content-view.component';




// Rodman Core Import
import { ContentSearchComponent } from '../../../rodman-core/src/lib/contents/content-search/content-search.component';
import { NotFoundComponent } from '../../../rodman-core/src/lib/sites/components/not-found/not-found.component';
import { UserProfileComponent } from '../../../rodman-core/src/lib/users/Components/user-profile/user-profile.component';
import { StaticContentComponent } from "../../../rodman-core/src/lib/contents/static-content/static-content.component";
import { ContentGlossaryComponent } from "../../../rodman-core/src/lib/contents/content-glossary/content-glossary.component";
import { ContentIssueComponent } from "../../../rodman-core/src/lib/contents/content-issue/content-issue.component";
import { ContentRssFeedsComponent } from "../../../rodman-core/src/lib/contents/content-rss-feeds/content-rss-feeds.component";
import { DirectoryHomePageComponent } from "../../../rodman-core/src/lib/directory-section/directory-home-page/directory-home-page.component";
// import { ContentInfograpicComponent } from '../app//content/content-infograpic/content-infograpic.component';
import { ContentInfographicsComponent } from "../../../rodman-core/src/lib/contents/content-infographics/content-infographics.component";
import{ ContentsWebinarComponent } from '../../../rodman-core/src/lib/contents/contents-webinar/contents-webinar.component'



// import { UsersVerifyEmailComponent } from '../../../rodman-core/src/lib/users/users-verify-email/users-verify-email.component';



const routes: Routes = [
  {path: "", pathMatch: 'full' , loadChildren: () =>import('./pen-home/pen-home.module').then (m=>m.PENHomeModule)},

// Search Content 
  {path:  'contents/list_webinars', component:ContentsWebinarComponent,data: {magazineId: environment.magazineId }},
  {path:  'contents/list_infographics', component:ContentInfographicsComponent,data: {magazineId: environment.magazineId }},  
  {path:  'contents/list_industry-events', component:ContentInfographicsComponent,data: {magazineId: environment.magazineId }},
  {path:  'contents/list_ebook', component:NotFoundComponent},

  {path:  'contents/searchcontent/:any/:slug', component:ContentSearchComponent,data: {magazineId: environment.magazineId }},
  {path:  'contents/searchcontent/:any', component:ContentSearchComponent,data: {magazineId: environment.magazineId }},
  {path:  'contents/searchcontent', component:ContentSearchComponent,data: {magazineId: environment.magazineId }},

//View Page Content  
  {path:  'contents/:any/:any/:any', component:ContentViewComponent,data: {magazineId: environment.magazineId }},
  {path:  'issues/:any/:any/:any', component:ContentViewComponent,data: {magazineId: environment.magazineId }}, 


//Taxonomy
  {path:  'formulary/:any', loadChildren: () =>import('./taxonomy/taxonomy.module').then (m=>m.TaxonomyModule)},
  {path:  'news/:any', loadChildren: () =>import('./taxonomy/taxonomy.module').then (m=>m.TaxonomyModule)},
  
  {path:  'printed-electronics', loadChildren: () =>import('./taxonomy/taxonomy.module').then (m=>m.TaxonomyModule)},
  {path:  'printed-electronics/:any', loadChildren: () =>import('./taxonomy/taxonomy.module').then (m=>m.TaxonomyModule)},

  {path:  'raw-materials', loadChildren: () =>import('./taxonomy/taxonomy.module').then (m=>m.TaxonomyModule)},
  {path:  'raw-materials/:any', loadChildren: () =>import('./taxonomy/taxonomy.module').then (m=>m.TaxonomyModule)},

  {path:  'equipment', loadChildren: () =>import('./taxonomy/taxonomy.module').then (m=>m.TaxonomyModule)},
  {path:  'equipment-and-services/:any', loadChildren: () =>import('./taxonomy/taxonomy.module').then (m=>m.TaxonomyModule)},
  {path:  'equipment/:any', loadChildren: () =>import('./taxonomy/taxonomy.module').then (m=>m.TaxonomyModule)},

  {path:  'services', loadChildren: () =>import('./taxonomy/taxonomy.module').then (m=>m.TaxonomyModule)},
  {path:  'services/:any', loadChildren: () =>import('./taxonomy/taxonomy.module').then (m=>m.TaxonomyModule)},

  {path:  'columns/:any', loadChildren: () =>import('./taxonomy/taxonomy.module').then (m=>m.TaxonomyModule)},
  {path:  'knowledge-base/:any', loadChildren: () =>import('./taxonomy/taxonomy.module').then (m=>m.TaxonomyModule)},
  {path:  'salary-survey/:any', loadChildren: () =>import('./taxonomy/taxonomy.module').then (m=>m.TaxonomyModule)},
  {path:  'breaking-news/:any', loadChildren: () =>import('./taxonomy/taxonomy.module').then (m=>m.TaxonomyModule)},
  {path:  'live-from-shows', loadChildren: () =>import('./taxonomy/taxonomy.module').then (m=>m.TaxonomyModule)},
  

//Contents

  {path:  'glossary', component:ContentGlossaryComponent,data: {magazineId: environment.magazineId }},
  {path:  'contents/:any', loadChildren: () =>import('./content/content.module').then (m=>m.ContentModule)}, 
  
  {path:'resources',loadChildren: () =>import('./content/content.module').then (m=>m.ContentModule)}, 
  {path: 'profile',component : UserProfileComponent,data: {magazineId: environment.magazineId }},
  {path: 'user/verifyUser/:token/:email',component:UserMailVerifyComponent},



//Undefined Or Want Diffrent Api Or Pages 
  // BuyerGuide Case 
    // {path:  'buyersguide/profile/:company/:slug',component: BuyerGuideCompanyContentViewComponent,data: {magazineId: environment.magazineId }},
    {path:  'buyersguide',component : DirectoryHomePageComponent,data: {magazineId: environment.magazineId }},
    {path:  'buyersguide/all_companies',component : DirectoryHomePageComponent,data: {magazineId: environment.magazineId }},


// OtherCase Static Content
  {path: 'subscribe-now', component : StaticContentComponent,data: {magazineId: environment.magazineId }},
  {path: 'advertise-with-us',component : StaticContentComponent,data: {magazineId: environment.magazineId }},
  {path: 'enewsletter-archive',component : StaticContentComponent,data: {magazineId: environment.magazineId }},
  {path: 'staff',component : StaticContentComponent,data: {magazineId: environment.magazineId }},
  {path: 'editorial-guidelines',component : StaticContentComponent,data: {magazineId: environment.magazineId }},
  {path: 'terms-and-conditions',component : StaticContentComponent,data: {magazineId: environment.magazineId }},
  {path: 'privacy-policy',component : StaticContentComponent,data: {magazineId: environment.magazineId }},
    // static Footer Link
    {path: 'about-us', component : StaticContentComponent,data: {magazineId: environment.magazineId }},
    {path: 'contact-us', component : StaticContentComponent,data: {magazineId: environment.magazineId }},

//Rss
  {path: 'rssfeeds', component : ContentRssFeedsComponent,data: {magazineId: environment.magazineId }},

  // {path: 'echo Magazine::latestIssueURL()',      redirectTo: 'issue',      pathMatch: 'full'    },
  // {path:  'issues',component : ContentIssueComponent,data: {magazineId: environment.magazineId }},
  {path:  'issues/:slug',component : ContentIssueComponent,data: {magazineId: environment.magazineId }},
  {path:  "**", component : NotFoundComponent},


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
