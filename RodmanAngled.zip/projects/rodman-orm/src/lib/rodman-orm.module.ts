import { NgModule } from '@angular/core';
import { RodmanORMComponent } from './rodman-orm.component';



@NgModule({
  declarations: [RodmanORMComponent],
  imports: [
  ],
  exports: [RodmanORMComponent]
})
export class RodmanORMModule { }
