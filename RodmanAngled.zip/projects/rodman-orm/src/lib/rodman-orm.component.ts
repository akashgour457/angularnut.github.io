import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'RodmanORM-RodmanORM',
  template: `
    <p>
      rodman-orm works!
    </p>
  `,
  styles: []
})
export class RodmanORMComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
