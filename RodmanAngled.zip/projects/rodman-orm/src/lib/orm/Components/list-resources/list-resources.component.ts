import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'RodmanORM-list-resources',
  templateUrl: './list-resources.component.html',
  styleUrls: ['./list-resources.component.css']
})
export class ListResourcesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
