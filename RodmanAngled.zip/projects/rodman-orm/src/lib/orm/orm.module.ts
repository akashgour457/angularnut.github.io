import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';

import { OrmRoutingModule } from './orm-routing.module';
import { ListResourcesComponent } from './Components/list-resources/list-resources.component';


@NgModule({
  declarations: [ListResourcesComponent],
  imports: [
    CommonModule,
    OrmRoutingModule,
    HttpClientModule
  ]
})
export class OrmModule { }
